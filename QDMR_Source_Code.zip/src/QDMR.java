import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.DecimalFormat;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.UIManager;

/**
 *
 * @author  __USER__
 */
public class QDMR extends javax.swing.JFrame {
	/**
	 * Ԥ����ȫ�ֱ���
	 */

	private static final long serialVersionUID = 1L;
	String InputfilePath = null; //�����������ݵľ���·��
	String InputFileName = null;
	String Separator = "\t|\\s+\t|\t\\s+|\\s+"; //Ԥ����ָ���
	int SampleNum = 0; //Ԥ����������Ŀ��Ĭ�������Ϊ����-5���û��޸ĺ󽫸��´�ֵ��
	int UserDataRowNum = 0; //Ԥ�����û���������
	int ColumnNum = 0; //�û�������������
	int DMRNum = 0; //����׻�������ĸ���
	int NDMRNum = 0; //�ǲ���׻�������ĸ���
	boolean FirstLineIsColumnName = false; //�û�ѡ���һ��Ϊ����ֵ��Ĭ�ϲ�ѡ
	double MaxMethylationLevel = 100; //��¼�û�ѡ��ļ׻������ֵ
	int SampleStartColumn = 5; //��¼�û����������׻������ݿ�ʼ���У�Ĭ��Ϊ������
	int SpeciesNum = 1; //���֣�Ĭ��ѡ��ڶ���hg18����ʼΪ0��
	int ChromsomeColumn = 1; //Ⱦɫ���У�Ĭ��ѡ��ڶ��У���ʼΪ0��
	int RegionStartColumn = 2; //��ʼλ�㣺Ĭ��ѡ������У���ʼΪ0��
	int RegionEndColumn = 3; //��ֹλ�㣺Ĭ��ѡ������У���ʼΪ0��
	int SDcolumn=7;          //SD�У�Ĭ�ϵ�8��

	DecimalFormat VF = new DecimalFormat("0.000"); //������������ݵ���Ч����
	DecimalFormat VF1 = new DecimalFormat("0.0");

	/** Creates new form  QDMR*/
	public QDMR() {
		Toolkit kit = Toolkit.getDefaultToolkit();
		Dimension screenSize = kit.getScreenSize(); //ȡ���û���Ļ��С��Ϣ
		int screenWidth = screenSize.width;
		setLocation(screenWidth / 2 - 465, 0); //�����������Ͻǵ�λ��
		setTitle("QDMR");
		Image image = kit.getImage(getClass().getResource("/images/logo.png"));
		setIconImage(image);
		initComponents();
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jSplitPane1 = new javax.swing.JSplitPane();
		jPanel1 = new javax.swing.JPanel();
		DataInput = new javax.swing.JButton();
		CanculateEntropy = new javax.swing.JButton();
		jLabelLogo = new javax.swing.JLabel();
		IdentityDMR = new javax.swing.JButton();
		jButtonSpecificity = new javax.swing.JButton();
		jLabel2 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		jLabel4 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jButtonAllResults = new javax.swing.JButton();
		jPanel2 = new javax.swing.JPanel();
		jSplitPane2 = new javax.swing.JSplitPane();
		jScrollPane2 = new javax.swing.JScrollPane();
		jTextArea1 = new javax.swing.JTextArea();
		jSplitPane3 = new javax.swing.JSplitPane();
		jTabbedPaneTestView = new javax.swing.JTabbedPane();
		UserDataTablePanel = new javax.swing.JScrollPane();
		UserDataTable = new javax.swing.JTable();
		EntropyPanel = new javax.swing.JScrollPane();
		EntropyDataTable = new javax.swing.JTable();
		jScrollPane1 = new javax.swing.JScrollPane();
		jTableDMR = new javax.swing.JTable();
		jScrollPane4 = new javax.swing.JScrollPane();
		jTableNDMR = new javax.swing.JTable();
		jScrollPane5 = new javax.swing.JScrollPane();
		jTableSpecificity = new javax.swing.JTable();
		jPanel_Test = new javax.swing.JPanel();
		jSplitPane4 = new javax.swing.JSplitPane();
		jPanel3 = new javax.swing.JPanel();
		jLabel6 = new javax.swing.JLabel();
		jLabelSampleNum = new javax.swing.JLabel();
		jLabelThresholdDMR = new javax.swing.JLabel();
		jLabelSampleNum1 = new javax.swing.JLabel();
		jLabelDMRNum = new javax.swing.JLabel();
		jLabelDMRNum1 = new javax.swing.JLabel();
		jLabelSampleNum2 = new javax.swing.JLabel();
		jLabelNDMRNum = new javax.swing.JLabel();
		jLabelNDMRNum1 = new javax.swing.JLabel();
		jLabelSampleNuma = new javax.swing.JLabel();
		jLabelThreDMR = new javax.swing.JLabel();
		jPanel4 = new javax.swing.JPanel();
		jLabel7 = new javax.swing.JLabel();
		jButtonDMRDistribution = new javax.swing.JButton();
		jComboBoxspecies = new javax.swing.JComboBox();
		jLabelspecies = new javax.swing.JLabel();
		jLabelchrom = new javax.swing.JLabel();
		jComboBoxchrom = new javax.swing.JComboBox();
		jLabelstart = new javax.swing.JLabel();
		jComboBoxstart = new javax.swing.JComboBox();
		jLabelend = new javax.swing.JLabel();
		jComboBoxend = new javax.swing.JComboBox();
		jLabelendPlotOrientation = new javax.swing.JLabel();
		jComboBoxPlot = new javax.swing.JComboBox();
		jPanelViewDMRs = new javax.swing.JPanel();
		jScrollPane3 = new javax.swing.JScrollPane();
		jTextAreaGuide = new javax.swing.JTextArea();
		jLabel1 = new javax.swing.JLabel();
		menuBar = new javax.swing.JMenuBar();
		fileMenu = new javax.swing.JMenu();
		openMenuItem = new javax.swing.JMenuItem();
		jSeparator2 = new javax.swing.JSeparator();
		saveMenuItem = new javax.swing.JMenuItem();
		saveAsMenuItem = new javax.swing.JMenuItem();
		jSeparator1 = new javax.swing.JSeparator();
		InputMenuItem = new javax.swing.JMenuItem();
		ExportMenuItem = new javax.swing.JMenuItem();
		jSeparator3 = new javax.swing.JSeparator();
		exitMenuItem = new javax.swing.JMenuItem();
		editMenu = new javax.swing.JMenu();
		cutMenuItem = new javax.swing.JMenuItem();
		copyMenuItem = new javax.swing.JMenuItem();
		pasteMenuItem = new javax.swing.JMenuItem();
		deleteMenuItem = new javax.swing.JMenuItem();
		helpMenu = new javax.swing.JMenu();
		contentsMenuItem = new javax.swing.JMenuItem();
		aboutMenuItem = new javax.swing.JMenuItem();
		jProgressBar = new javax.swing.JProgressBar();
		menuBar1 = new javax.swing.JMenuBar();
		fileMenu1 = new javax.swing.JMenu();
		jSeparator4 = new javax.swing.JSeparator();
		jSeparator5 = new javax.swing.JSeparator();
		InputMenuItem1 = new javax.swing.JMenuItem();
		jMenuExport = new javax.swing.JMenu();
		jMenuItemExportEntropy = new javax.swing.JMenuItem();
		jMenuItemExportDMR = new javax.swing.JMenuItem();
		jMenuItemExportNDMR = new javax.swing.JMenuItem();
		jMenuItemExportIDMR = new javax.swing.JMenuItem();
		jMenuItemStatistics = new javax.swing.JMenuItem();
		jMenuItemAllTables = new javax.swing.JMenuItem();
		jSeparator6 = new javax.swing.JSeparator();
		exitMenuItem1 = new javax.swing.JMenuItem();
		editMenu1 = new javax.swing.JMenu();
		CanculateEntropyMenuItem = new javax.swing.JMenuItem();
		IdentifyDMRsMenuItem = new javax.swing.JMenuItem();
		jMenuItemSpecificity = new javax.swing.JMenuItem();
		jSeparator8 = new javax.swing.JSeparator();
		jMenuItemThreshold = new javax.swing.JMenuItem();
		OnlineServiceMenuItem = new javax.swing.JMenuItem();
		helpMenu1 = new javax.swing.JMenu();
		jMenuItemOnline = new javax.swing.JMenuItem();
		contentsMenuItem1 = new javax.swing.JMenuItem();
		aboutMenuItem1 = new javax.swing.JMenuItem();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jSplitPane1.setDividerSize(10);

		jPanel1.setFont(new java.awt.Font("Arial", 0, 12));

		DataInput.setFont(new java.awt.Font("Arial", 1, 12));
		DataInput.setText("Import Data");
		DataInput.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				DataInputActionPerformed(evt);
			}
		});

		CanculateEntropy.setFont(new java.awt.Font("Arial", 1, 12));
		CanculateEntropy.setText("Quantify Difference");
		CanculateEntropy.setEnabled(false);
		CanculateEntropy.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				try {
					CanculateEntropyMouseClicked(evt);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		jLabelLogo.setFont(new java.awt.Font("Arial", 0, 3));
		jLabelLogo.setForeground(new java.awt.Color(0, 0, 255));
		jLabelLogo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabelLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/QDMRlogo.png"))); // NOI18N
		jLabelLogo.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				try {
					jLabelLogoMouseClicked(evt);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (URISyntaxException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			public void mouseEntered(java.awt.event.MouseEvent evt) {
				jLabelLogoMouseEntered(evt);
			}
		});

		IdentityDMR.setFont(new java.awt.Font("Arial", 1, 12));
		IdentityDMR.setText("Identify DMRs");
		IdentityDMR.setEnabled(false);
		IdentityDMR.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				IdentityDMRMouseClicked(evt);
			}
		});

		jButtonSpecificity.setFont(new java.awt.Font("Arial", 1, 12));
		jButtonSpecificity.setText("Measure Specificity");
		jButtonSpecificity.setEnabled(false);
		jButtonSpecificity.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				try {
					jButtonSpecificityMouseClicked(evt);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		jLabel2.setFont(new java.awt.Font("Arial", 0, 12));
		jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/Arrow.png"))); // NOI18N

		jLabel3.setFont(new java.awt.Font("Arial", 0, 12));
		jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/Arrow.png"))); // NOI18N

		jLabel4.setFont(new java.awt.Font("Arial", 0, 12));
		jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/Arrow.png"))); // NOI18N

		jLabel5.setFont(new java.awt.Font("Arial", 0, 12));
		jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/Arrow.png"))); // NOI18N

		jButtonAllResults.setFont(new java.awt.Font("Arial", 1, 12));
		jButtonAllResults.setText("Export All Results");
		jButtonAllResults.setEnabled(false);
		jButtonAllResults.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				try {
					jButtonAllResultsMouseClicked(evt);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		jButtonAllResults
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						jButtonAllResultsActionPerformed(evt);
					}
				});

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout.createSequentialGroup().addGap(
										61, 61, 61).addComponent(jLabel2)
										.addContainerGap(66, Short.MAX_VALUE))
						.addGroup(
								jPanel1Layout.createSequentialGroup().addGap(
										61, 61, 61).addComponent(jLabel3)
										.addContainerGap(66, Short.MAX_VALUE))
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(
												jButtonAllResults,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												145, Short.MAX_VALUE)
										.addContainerGap())
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(jButtonSpecificity)
										.addContainerGap(
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE))
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																IdentityDMR,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																145,
																Short.MAX_VALUE)
														.addComponent(
																jLabelLogo,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																145,
																Short.MAX_VALUE)
														.addComponent(
																CanculateEntropy,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																145,
																Short.MAX_VALUE)
														.addComponent(
																DataInput,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																145,
																Short.MAX_VALUE))
										.addContainerGap()).addGroup(
								jPanel1Layout.createSequentialGroup().addGap(
										63, 63, 63).addComponent(jLabel4)
										.addContainerGap(64, Short.MAX_VALUE))
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel1Layout.createSequentialGroup()
										.addContainerGap(64, Short.MAX_VALUE)
										.addComponent(jLabel5).addGap(63, 63,
												63)));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addGap(22, 22, 22)
										.addComponent(
												jLabelLogo,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												58,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(31, 31, 31)
										.addComponent(DataInput)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(jLabel2)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(CanculateEntropy)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(jLabel3)
										.addGap(12, 12, 12)
										.addComponent(IdentityDMR)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(jLabel4)
										.addGap(14, 14, 14)
										.addComponent(jButtonSpecificity)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(jLabel5).addGap(10, 10,
												10).addComponent(
												jButtonAllResults)
										.addContainerGap(151, Short.MAX_VALUE)));

		jSplitPane1.setLeftComponent(jPanel1);

		jSplitPane2.setDividerLocation(470);
		jSplitPane2.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
		jSplitPane2.setResizeWeight(0.3);
		jSplitPane2.setOneTouchExpandable(true);

		jScrollPane2.setBorder(javax.swing.BorderFactory.createTitledBorder(
				null, "Information",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
				javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Arial", 1, 12),
				new java.awt.Color(0, 0, 255)));

		jTextArea1.setColumns(20);
		jTextArea1.setRows(5);
		jScrollPane2.setViewportView(jTextArea1);

		jSplitPane2.setRightComponent(jScrollPane2);

		jSplitPane3.setDividerLocation(420);
		jSplitPane3.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
		jSplitPane3.setOneTouchExpandable(true);

		jTabbedPaneTestView.setBorder(javax.swing.BorderFactory
				.createTitledBorder(null, "Data Tables",
						javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
						javax.swing.border.TitledBorder.DEFAULT_POSITION,
						new java.awt.Font("Arial", 1, 12), new java.awt.Color(
								0, 0, 204)));
		jTabbedPaneTestView.setForeground(new java.awt.Color(0, 0, 255));
		jTabbedPaneTestView.setFont(new java.awt.Font("Arial", 1, 12));
		jTabbedPaneTestView.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				jTabbedPaneTestViewMouseClicked(evt);
			}
		});

		UserDataTablePanel.setBorder(javax.swing.BorderFactory
				.createEtchedBorder());
		UserDataTablePanel.setFont(new java.awt.Font("Arial", 0, 12));

		UserDataTable.setFont(new java.awt.Font("Arial", 0, 12));
		UserDataTable
				.setModel(new javax.swing.table.DefaultTableModel(
						new Object[][] {
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null } }, new String[] {
								"RegionID", "Chromosome", "RegionStart",
								"RegionEnd", "Me_Sample1", "Me_Sample2",
								"Me_Sample3", "Me_Sample4", "More..." }));
		UserDataTable.setSelectionBackground(new java.awt.Color(0, 153, 255));
		UserDataTablePanel.setViewportView(UserDataTable);

		jTabbedPaneTestView.addTab("Methylation Data", UserDataTablePanel);

		EntropyPanel.setBackground(new java.awt.Color(255, 255, 255));
		EntropyPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
		EntropyPanel.setFont(new java.awt.Font("Arial", 0, 12));

		EntropyDataTable.setFont(new java.awt.Font("Arial", 0, 12));
		EntropyDataTable
				.setModel(new javax.swing.table.DefaultTableModel(
						new Object[][] {
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null } }, new String[] {
								"RegionID", "Chromosome", "RegionStart",
								"RegionEnd", "Entropy", "Me_Sample1",
								"Me_Sample2", "Me_Sample3", "More..." }));
		EntropyDataTable
				.setSelectionBackground(new java.awt.Color(0, 153, 255));
		EntropyPanel.setViewportView(EntropyDataTable);

		jTabbedPaneTestView.addTab("Entropy", EntropyPanel);

		jTableDMR.setFont(new java.awt.Font("Arial", 0, 12));
		jTableDMR
				.setModel(new javax.swing.table.DefaultTableModel(
						new Object[][] {
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null } }, new String[] {
								"RegionID", "Chromosome", "RegionStart",
								"RegionEnd", "Entropy", "Me_Sample1",
								"Me_Sample2", "Me_Sample3", "More..." }));
		jTableDMR.setSelectionBackground(new java.awt.Color(0, 153, 255));
		jScrollPane1.setViewportView(jTableDMR);

		jTabbedPaneTestView.addTab("DMRs", jScrollPane1);

		jTableNDMR.setFont(new java.awt.Font("Arial", 0, 12));
		jTableNDMR
				.setModel(new javax.swing.table.DefaultTableModel(
						new Object[][] {
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null } }, new String[] {
								"RegionID", "Chromosome", "RegionStart",
								"RegionEnd", "Entropy", "Me_Sample1",
								"Me_Sample2", "Me_Sample3", "More..." }));
		jTableNDMR.setSelectionBackground(new java.awt.Color(0, 153, 255));
		jScrollPane4.setViewportView(jTableNDMR);

		jTabbedPaneTestView.addTab("N-DMRs", jScrollPane4);

		jTableSpecificity.setFont(new java.awt.Font("Arial", 0, 12));
		jTableSpecificity
				.setModel(new javax.swing.table.DefaultTableModel(
						new Object[][] {
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null },
								{ null, null, null, null, null, null, null,
										null, null } }, new String[] {
								"RegionID", "Chromosome", "RegionStart",
								"RegionEnd", "Entropy", "CS_Sample1",
								"CS_Sample2", "CS_Sample3", "More..." }));
		jTableSpecificity
				.setSelectionBackground(new java.awt.Color(0, 153, 255));
		jScrollPane5.setViewportView(jTableSpecificity);

		jTabbedPaneTestView.addTab("DMRs Specificity", jScrollPane5);

		jSplitPane4.setDividerLocation(300);

		jLabel6.setFont(new java.awt.Font("Arial", 1, 12));
		jLabel6.setText("Statistics of regions");

		jLabelSampleNum.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelSampleNum.setText("The Number of Samples is : ");

		jLabelThresholdDMR.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelThresholdDMR.setText("The Threshold for DMR is :  ");

		jLabelSampleNum1.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelSampleNum1.setText("The Number of DMRs is : ");

		jLabelDMRNum.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelDMRNum.setText("           ");

		jLabelDMRNum1.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelDMRNum1.setText("           ");

		jLabelSampleNum2.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelSampleNum2.setText("The Number of N-DMRs is : ");

		jLabelNDMRNum.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelNDMRNum.setText("           ");

		jLabelNDMRNum1.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelNDMRNum1.setText("           ");

		jLabelSampleNuma.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelSampleNuma.setText("           ");

		jLabelThreDMR.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelThreDMR.setText("           ");

		javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(
				jPanel3);
		jPanel3.setLayout(jPanel3Layout);
		jPanel3Layout
				.setHorizontalGroup(jPanel3Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel3Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel3Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel3Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabelSampleNum2,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								182,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								jLabelSampleNum1,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								182,
																								javax.swing.GroupLayout.PREFERRED_SIZE))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel3Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabelDMRNum,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								45,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								jLabelNDMRNum))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel3Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabelDMRNum1)
																						.addComponent(
																								jLabelNDMRNum1)))
														.addGroup(
																jPanel3Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel3Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabelThresholdDMR,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								180,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								jLabelSampleNum,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								180,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								jLabel6,
																								javax.swing.GroupLayout.Alignment.TRAILING,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								126,
																								javax.swing.GroupLayout.PREFERRED_SIZE))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel3Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabelThreDMR)
																						.addComponent(
																								jLabelSampleNuma))))
										.addContainerGap(17, Short.MAX_VALUE)));
		jPanel3Layout
				.setVerticalGroup(jPanel3Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel3Layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(jLabel6)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel3Layout
																		.createSequentialGroup()
																		.addGap(
																				42,
																				42,
																				42)
																		.addComponent(
																				jLabelDMRNum1)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jLabelNDMRNum1))
														.addGroup(
																jPanel3Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel3Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jLabelSampleNum)
																						.addComponent(
																								jLabelSampleNuma))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel3Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jLabelThresholdDMR)
																						.addComponent(
																								jLabelThreDMR))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel3Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jLabelSampleNum1)
																						.addComponent(
																								jLabelDMRNum))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel3Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jLabelSampleNum2)
																						.addComponent(
																								jLabelNDMRNum))))
										.addContainerGap(248, Short.MAX_VALUE)));

		jSplitPane4.setLeftComponent(jPanel3);

		jLabel7.setFont(new java.awt.Font("Arial", 1, 12));
		jLabel7.setText("Distribution of DMRs on chromsomes");

		jButtonDMRDistribution.setFont(new java.awt.Font("Arial", 1, 12));
		jButtonDMRDistribution.setText("DMR Distribution");
		jButtonDMRDistribution.setEnabled(false);
		jButtonDMRDistribution
				.addMouseListener(new java.awt.event.MouseAdapter() {
					public void mouseClicked(java.awt.event.MouseEvent evt) {
						jButtonDMRDistributionMouseClicked(evt);
					}
				});
		jButtonDMRDistribution
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						jButtonDMRDistributionActionPerformed(evt);
					}
				});

		jComboBoxspecies.setFont(new java.awt.Font("Arial", 0, 12));
		jComboBoxspecies.setModel(new javax.swing.DefaultComboBoxModel(
				new String[] { "Human Feb. 2009 (GRCh37/hg19)",
						"Human Mar. 2006 (NCBI36/hg18)",
						"Human May 2004 (NCBI35/hg17)",
						"Human July 2003 (NCBI34/hg16)",
						"Mouse July 2007 (NCBI37/mm9)",
						"Mouse Feb. 2006 (NCBI36/mm8)",
						"Mouse Aug. 2005 (NCBI35/mm7)",
						"Rat Nov. 2004 (Baylor3.4/rn4)",
						"Rat June 2003 (Baylor3.1/rn3)",
						"Chicken May 2006 (WUGSC2.1/galGal3)",
						"Chicken Feb. 2004 (WUGSC1.0/galGal2)",
						"Zebrafish Dec. 2008 (Zv8/danRer6)",
						"Zebrafish July 2007 (Zv7/danRer5)",
						"Zebrafish Mar. 2006 (Zv6/danRer4)",
						"Zebrafish May 2005 (Zv5/danRer3)",
						"C.+elegans May 2008 (WS190/ce6)",
						"C.+elegans Jan. 2007 (WS170/ce4)",
						"C.+elegans Mar. 2004 (WS120/ce2)",
						"S.+cerevisiae June 2008 (SGD/sacCer2)",
						"S.+cerevisiae Oct. 2003 (SGD/sacCer1)" }));
		jComboBoxspecies.setSelectedIndex(1);

		jLabelspecies.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelspecies.setText("Species");

		jLabelchrom.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelchrom.setText("Chromsome Column");

		jComboBoxchrom.setFont(new java.awt.Font("Arial", 0, 12));
		jComboBoxchrom
				.setModel(new javax.swing.DefaultComboBoxModel(new String[] {
						"Column 1", "Column 2", "Column 3", "Column 4" }));
		jComboBoxchrom.setSelectedIndex(2);

		jLabelstart.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelstart.setText("Region Start Column");

		jComboBoxstart.setFont(new java.awt.Font("Arial", 0, 12));
		jComboBoxstart
				.setModel(new javax.swing.DefaultComboBoxModel(new String[] {
						"Column 1", "Column 2", "Column 3", "Column 4" }));
		jComboBoxstart.setSelectedIndex(3);

		jLabelend.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelend.setText("Region End Column");

		jComboBoxend.setFont(new java.awt.Font("Arial", 0, 12));
		jComboBoxend.setModel(new javax.swing.DefaultComboBoxModel(
				new String[] { "Column 1", "Column 2", "Column 3", "Column 4",
						"Column 5" }));
		jComboBoxend.setSelectedIndex(4);

		jLabelendPlotOrientation.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelendPlotOrientation.setText("Plot Orientation");

		jComboBoxPlot.setFont(new java.awt.Font("Arial", 0, 12));
		jComboBoxPlot.setModel(new javax.swing.DefaultComboBoxModel(
				new String[] { "Vertical", "Horizontal" }));

		javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(
				jPanel4);
		jPanel4.setLayout(jPanel4Layout);
		jPanel4Layout
				.setHorizontalGroup(jPanel4Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel4Layout.createSequentialGroup().addGap(
										79, 79, 79).addComponent(jLabel7,
										javax.swing.GroupLayout.PREFERRED_SIZE,
										221,
										javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(70, 70, 70))
						.addGroup(
								jPanel4Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addGroup(
																jPanel4Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel4Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabelspecies)
																						.addComponent(
																								jLabelstart)
																						.addComponent(
																								jLabelend)
																						.addComponent(
																								jLabelendPlotOrientation))
																		.addGap(
																				6,
																				6,
																				6))
														.addGroup(
																jPanel4Layout
																		.createSequentialGroup()
																		.addComponent(
																				jLabelchrom)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																jComboBoxspecies,
																0, 249,
																Short.MAX_VALUE)
														.addComponent(
																jComboBoxPlot,
																0, 249,
																Short.MAX_VALUE)
														.addComponent(
																jComboBoxend,
																0, 249,
																Short.MAX_VALUE)
														.addComponent(
																jComboBoxstart,
																0, 249,
																Short.MAX_VALUE)
														.addComponent(
																jComboBoxchrom,
																0, 249,
																Short.MAX_VALUE))
										.addContainerGap())
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel4Layout
										.createSequentialGroup()
										.addContainerGap(94, Short.MAX_VALUE)
										.addComponent(
												jButtonDMRDistribution,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												249,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(47, 47, 47)));
		jPanel4Layout
				.setVerticalGroup(jPanel4Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel4Layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(jLabel7)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jLabelspecies)
														.addComponent(
																jComboBoxspecies,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jLabelchrom)
														.addComponent(
																jComboBoxchrom,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																17,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jLabelstart)
														.addComponent(
																jComboBoxstart,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																17,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabelend)
														.addComponent(
																jComboBoxend,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																17,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jLabelendPlotOrientation)
														.addComponent(
																jComboBoxPlot,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																17,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(jButtonDMRDistribution)
										.addContainerGap(184, Short.MAX_VALUE)));

		jSplitPane4.setRightComponent(jPanel4);

		javax.swing.GroupLayout jPanel_TestLayout = new javax.swing.GroupLayout(
				jPanel_Test);
		jPanel_Test.setLayout(jPanel_TestLayout);
		jPanel_TestLayout.setHorizontalGroup(jPanel_TestLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addComponent(jSplitPane4,
						javax.swing.GroupLayout.DEFAULT_SIZE, 696,
						Short.MAX_VALUE));
		jPanel_TestLayout.setVerticalGroup(jPanel_TestLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addComponent(jSplitPane4,
						javax.swing.GroupLayout.DEFAULT_SIZE, 359,
						Short.MAX_VALUE));

		jTabbedPaneTestView.addTab("Statistics", jPanel_Test);

		jSplitPane3.setTopComponent(jTabbedPaneTestView);

		jPanelViewDMRs.setBorder(javax.swing.BorderFactory.createTitledBorder(
				null, "RegionMethyView",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
				javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Arial", 1, 12),
				new java.awt.Color(0, 0, 255)));

		javax.swing.GroupLayout jPanelViewDMRsLayout = new javax.swing.GroupLayout(
				jPanelViewDMRs);
		jPanelViewDMRs.setLayout(jPanelViewDMRsLayout);
		jPanelViewDMRsLayout.setHorizontalGroup(jPanelViewDMRsLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 701, Short.MAX_VALUE));
		jPanelViewDMRsLayout.setVerticalGroup(jPanelViewDMRsLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 12, Short.MAX_VALUE));

		jSplitPane3.setRightComponent(jPanelViewDMRs);

		jSplitPane2.setLeftComponent(jSplitPane3);

		jScrollPane3.setBorder(javax.swing.BorderFactory.createTitledBorder(
				null, "Operation Guide",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
				javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Arial", 1, 12),
				new java.awt.Color(0, 0, 255)));

		jTextAreaGuide.setColumns(20);
		jTextAreaGuide.setEditable(false);
		jTextAreaGuide.setFont(new java.awt.Font("Arial", 0, 12));
		jTextAreaGuide.setLineWrap(true);
		jTextAreaGuide.setRows(5);
		jTextAreaGuide.setTabSize(2);
		jTextAreaGuide
				.setText("Welcome to QDMR!\nThis manual will guide your operation during Analysis.\n\n\tThere are three ways to load data and start your analysis:\n\t\t1. Loading methylation data by clicking the \"Input Data\" button on the left panel.\n\t\t2. Loading methylation data via \"File->Import Methylation Data\".\n\t\t3. Loading methylation data by shortcut keys \"Ctrl+I\". ");
		jTextAreaGuide.setCaretPosition(0);
		jScrollPane3.setViewportView(jTextAreaGuide);

		jSplitPane2.setRightComponent(jScrollPane3);

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(
				jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jSplitPane2));
		jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jSplitPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 607,
				Short.MAX_VALUE));

		jSplitPane1.setRightComponent(jPanel2);

		jLabel1.setFont(new java.awt.Font("Arial", 0, 12));
		jLabel1.setText("Welcome to QDMR v1.0");

		fileMenu.setText("File");

		openMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_O,
				java.awt.event.InputEvent.CTRL_MASK));
		openMenuItem.setText("Open");
		fileMenu.add(openMenuItem);
		fileMenu.add(jSeparator2);

		saveMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_S,
				java.awt.event.InputEvent.CTRL_MASK));
		saveMenuItem.setText("Save");
		saveMenuItem.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				saveMenuItemActionPerformed(evt);
			}
		});
		fileMenu.add(saveMenuItem);

		saveAsMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_C,
				java.awt.event.InputEvent.SHIFT_MASK
						| java.awt.event.InputEvent.CTRL_MASK));
		saveAsMenuItem.setText("Save As ...");
		fileMenu.add(saveAsMenuItem);
		fileMenu.add(jSeparator1);

		InputMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_I,
				java.awt.event.InputEvent.CTRL_MASK));
		InputMenuItem.setText("Import");
		InputMenuItem.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				InputMenuItemActionPerformed(evt);
			}
		});
		fileMenu.add(InputMenuItem);

		ExportMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_E,
				java.awt.event.InputEvent.CTRL_MASK));
		ExportMenuItem.setText("Export");
		ExportMenuItem.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				ExportMenuItemActionPerformed(evt);
			}
		});
		fileMenu.add(ExportMenuItem);
		fileMenu.add(jSeparator3);

		exitMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_Q,
				java.awt.event.InputEvent.CTRL_MASK));
		exitMenuItem.setText("Exit");
		exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				exitMenuItemActionPerformed(evt);
			}
		});
		fileMenu.add(exitMenuItem);

		menuBar.add(fileMenu);

		editMenu.setText("Edit");

		cutMenuItem.setText("Cut");
		editMenu.add(cutMenuItem);

		copyMenuItem.setText("Copy");
		editMenu.add(copyMenuItem);

		pasteMenuItem.setText("Paste");
		editMenu.add(pasteMenuItem);

		deleteMenuItem.setText("Delete");
		editMenu.add(deleteMenuItem);

		menuBar.add(editMenu);

		helpMenu.setText("Help");

		contentsMenuItem.setText("Contents");
		helpMenu.add(contentsMenuItem);

		aboutMenuItem.setText("About");
		helpMenu.add(aboutMenuItem);

		menuBar.add(helpMenu);

		jProgressBar.setFont(new java.awt.Font("Arial", 0, 12));
		jProgressBar.setForeground(new java.awt.Color(0, 204, 51));

		fileMenu1.setText("File");
		fileMenu1.add(jSeparator4);
		fileMenu1.add(jSeparator5);

		InputMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_I,
				java.awt.event.InputEvent.CTRL_MASK));
		InputMenuItem1.setFont(new java.awt.Font("Arial", 0, 12));
		InputMenuItem1.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/images/Importd.png"))); // NOI18N
		InputMenuItem1.setText("Import Methylation Data");
		InputMenuItem1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				InputMenuItemActionPerformed(evt);
			}
		});
		fileMenu1.add(InputMenuItem1);

		jMenuExport.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/save.png"))); // NOI18N
		jMenuExport.setText("Save Analysis Result");
		jMenuExport.setEnabled(false);
		jMenuExport.setFont(new java.awt.Font("Arial", 0, 12));

		jMenuItemExportEntropy.setAccelerator(javax.swing.KeyStroke
				.getKeyStroke(java.awt.event.KeyEvent.VK_E,
						java.awt.event.InputEvent.SHIFT_MASK
								| java.awt.event.InputEvent.CTRL_MASK));
		jMenuItemExportEntropy.setFont(new java.awt.Font("Arial", 0, 12));
		jMenuItemExportEntropy.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/images/save.png"))); // NOI18N
		jMenuItemExportEntropy.setText("Entropy Table");
		jMenuItemExportEntropy.setEnabled(false);
		jMenuItemExportEntropy
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						try {
							jMenuItemExportEntropyActionPerformed(evt);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
		jMenuExport.add(jMenuItemExportEntropy);

		jMenuItemExportDMR.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_R,
				java.awt.event.InputEvent.SHIFT_MASK
						| java.awt.event.InputEvent.CTRL_MASK));
		jMenuItemExportDMR.setFont(new java.awt.Font("Arial", 0, 12));
		jMenuItemExportDMR.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/images/save.png"))); // NOI18N
		jMenuItemExportDMR.setText("DMR Table");
		jMenuItemExportDMR.setEnabled(false);
		jMenuItemExportDMR
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						try {
							jMenuItemExportDMRActionPerformed(evt);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
		jMenuExport.add(jMenuItemExportDMR);

		jMenuItemExportNDMR.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_N,
				java.awt.event.InputEvent.SHIFT_MASK
						| java.awt.event.InputEvent.CTRL_MASK));
		jMenuItemExportNDMR.setFont(new java.awt.Font("Arial", 0, 12));
		jMenuItemExportNDMR.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/images/save.png"))); // NOI18N
		jMenuItemExportNDMR.setText("N-DMR Table");
		jMenuItemExportNDMR.setEnabled(false);
		jMenuItemExportNDMR
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						try {
							jMenuItemExportNDMRActionPerformed(evt);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
		jMenuExport.add(jMenuItemExportNDMR);

		jMenuItemExportIDMR.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_I,
				java.awt.event.InputEvent.SHIFT_MASK
						| java.awt.event.InputEvent.CTRL_MASK));
		jMenuItemExportIDMR.setFont(new java.awt.Font("Arial", 0, 12));
		jMenuItemExportIDMR.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/images/save.png"))); // NOI18N
		jMenuItemExportIDMR.setText("Specificity Table");
		jMenuItemExportIDMR.setEnabled(false);
		jMenuItemExportIDMR
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						try {
							jMenuItemExportIDMRActionPerformed(evt);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
		jMenuExport.add(jMenuItemExportIDMR);

		jMenuItemStatistics.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_S,
				java.awt.event.InputEvent.SHIFT_MASK
						| java.awt.event.InputEvent.CTRL_MASK));
		jMenuItemStatistics.setFont(new java.awt.Font("Arial", 0, 12));
		jMenuItemStatistics.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/images/save.png"))); // NOI18N
		jMenuItemStatistics.setText("Statistics");
		jMenuItemStatistics.setEnabled(false);
		jMenuItemStatistics
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						try {
							jMenuItemStatisticsActionPerformed(evt);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
		jMenuExport.add(jMenuItemStatistics);

		jMenuItemAllTables.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_A,
				java.awt.event.InputEvent.SHIFT_MASK
						| java.awt.event.InputEvent.CTRL_MASK));
		jMenuItemAllTables.setFont(new java.awt.Font("Arial", 0, 12));
		jMenuItemAllTables.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/images/save.png"))); // NOI18N
		jMenuItemAllTables.setText("All Results");
		jMenuItemAllTables.setEnabled(false);
		jMenuItemAllTables
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						try {
							jMenuItemAllTablesActionPerformed(evt);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
		jMenuExport.add(jMenuItemAllTables);

		fileMenu1.add(jMenuExport);
		fileMenu1.add(jSeparator6);

		exitMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_Q,
				java.awt.event.InputEvent.CTRL_MASK));
		exitMenuItem1.setFont(new java.awt.Font("Arial", 0, 12));
		exitMenuItem1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/Leave.png"))); // NOI18N
		exitMenuItem1.setText("Exit");
		exitMenuItem1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				exitMenuItemActionPerformed(evt);
			}
		});
		fileMenu1.add(exitMenuItem1);

		menuBar1.add(fileMenu1);

		editMenu1.setText("Analysis");

		CanculateEntropyMenuItem.setAccelerator(javax.swing.KeyStroke
				.getKeyStroke(java.awt.event.KeyEvent.VK_E,
						java.awt.event.InputEvent.ALT_MASK));
		CanculateEntropyMenuItem.setFont(new java.awt.Font("Arial", 0, 12));
		CanculateEntropyMenuItem.setText("Quantify Difference");
		CanculateEntropyMenuItem.setEnabled(false);
		CanculateEntropyMenuItem
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						try {
							CanculateEntropyMenuItemActionPerformed(evt);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
		editMenu1.add(CanculateEntropyMenuItem);

		IdentifyDMRsMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_I,
				java.awt.event.InputEvent.ALT_MASK));
		IdentifyDMRsMenuItem.setFont(new java.awt.Font("Arial", 0, 12));
		IdentifyDMRsMenuItem.setText("Identify DMRs");
		IdentifyDMRsMenuItem.setEnabled(false);
		IdentifyDMRsMenuItem
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						IdentifyDMRsMenuItemActionPerformed(evt);
					}
				});
		editMenu1.add(IdentifyDMRsMenuItem);

		jMenuItemSpecificity.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_M,
				java.awt.event.InputEvent.ALT_MASK));
		jMenuItemSpecificity.setFont(new java.awt.Font("Arial", 0, 12));
		jMenuItemSpecificity.setText("Measure Specificity");
		jMenuItemSpecificity.setEnabled(false);
		editMenu1.add(jMenuItemSpecificity);
		editMenu1.add(jSeparator8);

		jMenuItemThreshold.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_T,
				java.awt.event.InputEvent.ALT_MASK));
		jMenuItemThreshold.setFont(new java.awt.Font("Arial", 0, 12));
		jMenuItemThreshold.setText("Predefined Threshold");
		jMenuItemThreshold
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						jMenuItemThresholdActionPerformed(evt);
					}
				});
		editMenu1.add(jMenuItemThreshold);

		OnlineServiceMenuItem.setAccelerator(javax.swing.KeyStroke
				.getKeyStroke(java.awt.event.KeyEvent.VK_S,
						java.awt.event.InputEvent.ALT_MASK));
		OnlineServiceMenuItem.setFont(new java.awt.Font("Arial", 0, 12));
		OnlineServiceMenuItem.setText("Online Service");
		OnlineServiceMenuItem
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						try {
							OnlineServiceMenuItemActionPerformed(evt);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (URISyntaxException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
		editMenu1.add(OnlineServiceMenuItem);

		menuBar1.add(editMenu1);

		helpMenu1.setText("Help");

		jMenuItemOnline.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_W,
				java.awt.event.InputEvent.CTRL_MASK));
		jMenuItemOnline.setFont(new java.awt.Font("Arial", 0, 12));
		jMenuItemOnline.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/images/Home.png"))); // NOI18N
		jMenuItemOnline.setText("Visit QDMR Website");
		jMenuItemOnline.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				try {
					jMenuItemOnlineActionPerformed(evt);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (URISyntaxException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		helpMenu1.add(jMenuItemOnline);

		contentsMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_T,
				java.awt.event.InputEvent.CTRL_MASK));
		contentsMenuItem1.setFont(new java.awt.Font("Arial", 0, 12));
		contentsMenuItem1.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/images/Tutorials.png"))); // NOI18N
		contentsMenuItem1.setText("Online Tutorials");
		contentsMenuItem1
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						try {
							contentsMenuItem1ActionPerformed(evt);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (URISyntaxException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
		helpMenu1.add(contentsMenuItem1);

		aboutMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
				java.awt.event.KeyEvent.VK_A,
				java.awt.event.InputEvent.CTRL_MASK));
		aboutMenuItem1.setFont(new java.awt.Font("Arial", 0, 12));
		aboutMenuItem1.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/images/About.png"))); // NOI18N
		aboutMenuItem1.setText("About");
		aboutMenuItem1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				aboutMenuItem1ActionPerformed(evt);
			}
		});
		helpMenu1.add(aboutMenuItem1);

		menuBar1.add(helpMenu1);

		setJMenuBar(menuBar1);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout
				.setHorizontalGroup(layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																layout
																		.createSequentialGroup()
																		.addComponent(
																				jLabel1,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				204,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																				444,
																				Short.MAX_VALUE)
																		.addComponent(
																				jProgressBar,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				250,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addComponent(
																jSplitPane1))
										.addContainerGap()));
		layout
				.setVerticalGroup(layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(jSplitPane1)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(jLabel1)
														.addComponent(
																jProgressBar,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButtonDMRDistributionActionPerformed(
			java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		ProgressBar(0);
		String Species = (String) jComboBoxspecies.getSelectedItem(); //����
		int ChromColumn = jComboBoxchrom.getSelectedIndex(); //Ⱦɫ����
		int StartColumn = jComboBoxstart.getSelectedIndex(); //��ʼλ����
		int EndColumn = jComboBoxend.getSelectedIndex(); //��ֹλ����
		int PlotOrien = jComboBoxPlot.getSelectedIndex(); //Ⱦɫ�廭ͼ����0������1������
		new ChromDMRView(jPanelViewDMRs, jSplitPane3, jTableDMR, Species,
				ChromColumn, StartColumn, EndColumn, PlotOrien);
		ProgressBar(100);
		jSplitPane2.setDividerLocation(1.0);

	}

	private void jButtonDMRDistributionMouseClicked(
			java.awt.event.MouseEvent evt) {
		// TODO add your handling code here:
	}

	private void jButtonAllResultsActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButtonAllResultsMouseClicked(java.awt.event.MouseEvent evt)
			throws Exception {
		// TODO add your handling code here:
		ProgressBar(0);
		new DataExportAll(EntropyDataTable, jTableDMR, jTableNDMR,
				jTableSpecificity, jLabelSampleNuma, jLabelThreDMR,
				jLabelDMRNum, jLabelDMRNum1, jLabelNDMRNum, jLabelNDMRNum1); //�������б�
	}

	private void jTabbedPaneTestViewMouseClicked(java.awt.event.MouseEvent evt) {
		// TODO add your handling code here:
		jTabbedPaneTestView.setForegroundAt(0, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(1, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(2, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(3, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(4, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(5, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(jTabbedPaneTestView
				.getSelectedIndex(), Color.RED);
	}

	private void jMenuItemAllTablesActionPerformed(
			java.awt.event.ActionEvent evt) throws Exception {
		// TODO add your handling code here:
		ProgressBar(0);
		new DataExportAll(EntropyDataTable, jTableDMR, jTableNDMR,
				jTableSpecificity, jLabelSampleNuma, jLabelThreDMR,
				jLabelDMRNum, jLabelDMRNum1, jLabelNDMRNum, jLabelNDMRNum1);
	}

	private void jMenuItemStatisticsActionPerformed(
			java.awt.event.ActionEvent evt) throws IOException {
		// TODO add your handling code here:
		ProgressBar(0);
		new DataExportStatistics(jLabelSampleNuma, jLabelThreDMR, jLabelDMRNum,
				jLabelDMRNum1, jLabelNDMRNum, jLabelNDMRNum1, "Statistics"); //���ݵ�������������׻������򵼳�
	}

	private void jMenuItemExportIDMRActionPerformed(
			java.awt.event.ActionEvent evt) throws IOException {
		// TODO add your handling code here:
		ProgressBar(0);
		new DataExport(jTableSpecificity, "DMRs-Specificity"); //���ݵ�������������׻������򵼳�
	}

	private void jMenuItemExportNDMRActionPerformed(
			java.awt.event.ActionEvent evt) throws IOException {
		// TODO add your handling code here:
		ProgressBar(0);
		new DataExport(jTableNDMR, "N-DMRs"); //���ݵ�������������׻������򵼳�
	}

	private void jMenuItemExportDMRActionPerformed(
			java.awt.event.ActionEvent evt) throws IOException {
		// TODO add your handling code here:
		ProgressBar(0);
		new DataExport(jTableDMR, "DMRs"); //���ݵ�������������׻������򵼳�
	}

	private void jMenuItemExportEntropyActionPerformed(
			java.awt.event.ActionEvent evt) throws IOException {
		// TODO add your handling code here:
		ProgressBar(0);
		new DataExport(EntropyDataTable, "Entropy"); //���ݵ����������ر�����
	}

	private void jButtonSpecificityMouseClicked(java.awt.event.MouseEvent evt)
			throws Exception {
		// TODO add your handling code here:
		ProgressBar(0);
		DMRSpecificity(jTableDMR);
	}

	private void IdentifyDMRsMenuItemActionPerformed(
			java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		DMRIdentity(EntropyDataTable); //���ò���׻���ɸѡ����ɸѡ����׻�������������������
	}

	private void IdentityDMRMouseClicked(java.awt.event.MouseEvent evt) {
		// TODO add your handling code here:
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				final DMRThreshold dialog = new DMRThreshold(new javax.swing.JFrame(), true,SDcolumn);
				dialog.okButton.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(
							java.awt.event.ActionEvent evt) {
						try {
							SDcolumn=dialog.SDcolumnselected;
							dialog.setVisible(false);
							DMRIdentity(EntropyDataTable); //���ò���׻���ɸѡ����ɸѡ����׻�������������������
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
				dialog.cancelButton.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(
							java.awt.event.ActionEvent evt) {
						try {
							SDcolumn=dialog.SDcolumnselected;
							dialog.setVisible(false);
							DMRIdentity(EntropyDataTable); //���ò���׻���ɸѡ����ɸѡ����׻�������������������
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
				dialog.addWindowListener(new java.awt.event.WindowAdapter() {
					public void windowClosing(java.awt.event.WindowEvent e) {
						dialog.setVisible(false);
						DMRIdentity(EntropyDataTable); //���ò���׻���ɸѡ����ɸѡ����׻�������������������
					}
				});
				dialog.setVisible(true);
			}
		});
		
	}

	private void CanculateEntropyMenuItemActionPerformed(
			java.awt.event.ActionEvent evt) throws Exception {
		// TODO add your handling code here:
		EntropyAnalysis(UserDataTable); //�����ؼ��㺯�������ز���������������
	}

	private void CanculateEntropyMouseClicked(java.awt.event.MouseEvent evt)
			throws Exception {
		// TODO add your handling code here:
		EntropyAnalysis(UserDataTable); //�����ؼ��㺯�������ز���������������
	}

//	private void jMenuItemThresholdActionPerformed(
//			java.awt.event.ActionEvent evt) {
//		// TODO add your handling code here:
//		java.awt.EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				final ThresholdPredefined dialog = new ThresholdPredefined(
//						new javax.swing.JFrame(), true, SDcolumn, SampleNum);
//				dialog.addWindowListener(new java.awt.event.WindowAdapter() {
//					public void windowClosing(java.awt.event.WindowEvent e) {
//						dialog.dispose();
//					}
//				});
//				dialog.setVisible(true);
//			}
//		});
//	}

	private void jMenuItemThresholdActionPerformed(
			java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				final DMRThreshold dialog = new DMRThreshold(new javax.swing.JFrame(), true,SDcolumn);
				dialog.okButton.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(
							java.awt.event.ActionEvent evt) {
						try {
							SDcolumn=dialog.SDcolumnselected;
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
				dialog.setVisible(true);
			}
		});
	}

	private void aboutMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				final About dialog = new About(new javax.swing.JFrame(), true);
				dialog.addWindowListener(new java.awt.event.WindowAdapter() {
					public void windowClosing(java.awt.event.WindowEvent e) {
						dialog.dispose();
					}
				});
				dialog.setVisible(true);
			}
		});
	}

	private void jMenuItemOnlineActionPerformed(java.awt.event.ActionEvent evt)
			throws IOException, URISyntaxException {
		// TODO add your handling code here:
		Desktop.getDesktop()
				.browse(new URI("http://bioinfo.hrbmu.edu.cn/qdmr"));
	}

	private void jLabelLogoMouseEntered(java.awt.event.MouseEvent evt) {
		// TODO add your handling code here:
		jLabelLogo.setCursor(new Cursor(Cursor.HAND_CURSOR));
	}

	private void contentsMenuItem1ActionPerformed(java.awt.event.ActionEvent evt)
			throws IOException, URISyntaxException {
		// TODO add your handling code here:
		Desktop.getDesktop().browse(
				new URI("http://bioinfo.hrbmu.edu.cn/qdmr/Tutorial.jsp"));
	}

	private void jLabelLogoMouseClicked(java.awt.event.MouseEvent evt)
			throws IOException, URISyntaxException {
		// TODO add your handling code here:
		Desktop.getDesktop()
				.browse(new URI("http://bioinfo.hrbmu.edu.cn/qdmr"));
	}

	private void OnlineServiceMenuItemActionPerformed(
			java.awt.event.ActionEvent evt) throws IOException,
			URISyntaxException {
		// TODO add your handling code here:
		Desktop.getDesktop()
				.browse(new URI("http://bioinfo.hrbmu.edu.cn/qdmr"));
	}

	private void DataInputActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		InputMenuItemActionPerformed(evt);
	}

	/**
	 * @param ��������������棬�����û��ύ�����ݴ洢�ڶ�ά�����з���(�÷������������쳣ʱ������������)
	 */
	private void InputMenuItemActionPerformed(java.awt.event.ActionEvent evt) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				//���ȳ�ʼ�����г����������
				Init_Parameters();
				final DataInputPreviewNew UserInputData = new DataInputPreviewNew(new javax.swing.JFrame(), true);
				ProgressBar(0);
				jProgressBar.setStringPainted(true);
				UserInputData.okButton.addActionListener(new java.awt.event.ActionListener() {
							public void actionPerformed(
									java.awt.event.ActionEvent evt) {
								try {
									DataGetAndView(UserInputData);
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						});
				UserInputData.setVisible(true);
			}
		});
	}

	/**
	 * @param 
	 */
	public void Init_Parameters() {
		InputfilePath = null; //�����������ݵľ���·��
		InputFileName = null;
		Separator = "\t|\\s+\t|\t\\s+|\\s+"; //Ԥ����ָ���
		SampleNum = 0; //Ԥ����������Ŀ��Ĭ�������Ϊ����-5���û��޸ĺ󽫸��´�ֵ��
		UserDataRowNum = 0; //Ԥ�����û���������
		ColumnNum = 0; //�û�������������
		FirstLineIsColumnName = false; //�û�ѡ���һ��Ϊ����ֵ��Ĭ�ϲ�ѡ
		MaxMethylationLevel = 100; //��¼�û�ѡ��ļ׻������ֵ
		SampleStartColumn = 5; //��¼�û����������׻������ݿ�ʼ���У�Ĭ��Ϊ������
		CanculateEntropy.setEnabled(false); //���ü����ذ�ť����
		CanculateEntropyMenuItem.setEnabled(false); //���ü����صĲ˵�����
		IdentityDMR.setEnabled(false); //����ʶ�����׻�������ť����
		IdentifyDMRsMenuItem.setEnabled(false); //����ʶ�����׻������� �˵�������
		jButtonSpecificity.setEnabled(false); //���ñ������׻�������ť������
		jButtonAllResults.setEnabled(false); //���ñ������н���İ�ť������
		jMenuItemExportDMR.setEnabled(false); //����DMR����˵�������
		jMenuItemExportNDMR.setEnabled(false); //����NDMR����˵�������
		jMenuItemExportIDMR.setEnabled(false); //����IDMR����˵�������
		jMenuItemStatistics.setEnabled(false); //����ͳ�Ʊ�����˵�������
		jMenuItemAllTables.setEnabled(false); //����ȫ��������˵�������
		jMenuItemExportEntropy.setEnabled(false); //����������˵�������
		jTextAreaGuide
				.setText("Welcome back to QDMR for another data!\n"
						+ "This manual will guide your operation during Analysis.\n"
						+ "\n   There are three ways to load data and start your analysis:\n"
						+ "		1) Loading methylation data by clicking the \"Import Data\" button on the left panel.\n"
						+ "		2) Loading methylation data via \"File->Import Methylation Data\".\n"
						+ "		3) Loading methylation data by shortcut keys \"Ctrl+I\". ");
		jTextAreaGuide.setCaretPosition(0); //���ò���˵����ʼ��
	}

	private void InputMenuItemActionPerformed() {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				final DataInputPreviewNew UserInputData = new DataInputPreviewNew(
						new javax.swing.JFrame(), true);
				ProgressBar(0);
				jProgressBar.setStringPainted(true);
				UserInputData.okButton
						.addActionListener(new java.awt.event.ActionListener() {
							public void actionPerformed(
									java.awt.event.ActionEvent evt) {
								try {
									DataGetAndView(UserInputData);
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						});
				UserInputData.setVisible(true);
			}
		});
	}

	private void saveMenuItemActionPerformed(java.awt.event.ActionEvent evt) { //��ʱ����ָ�������
		// TODO add your handling code here:         

	}

	private void ExportMenuItemActionPerformed(java.awt.event.ActionEvent evt) {
		JFileChooser chooser = new JFileChooser();
		chooser.showOpenDialog(this);
	}

	private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
		System.exit(0);
	}//GEN-LAST:event_exitMenuItemActionPerformed

	/**
	 * @param �û����Import������ݽ��е��벢����Ԥ��
	 */
	private void DataGetAndView(DataInputPreviewNew UserInputData)
			throws Exception {
		//���¼��У���DataԤ���л�ȡ��������ĸ�Ҫ��Ϣ
		InputfilePath = UserInputData.InputfilePath; //�û��������ݵľ���·��
		InputFileName = UserInputData.InputFileName; //�û���������ݵ��ļ���
		Separator = UserInputData.Separator; //���ݷָ���
		ColumnNum = UserInputData.ColumnNum; //�û��������ݵ�����
		FirstLineIsColumnName = UserInputData.FirstLineIsColumnName; //�û��Ƿ�ѡ���һ��Ϊ����
		MaxMethylationLevel = UserInputData.MaxMethylationLevel; //����û�����ļ׻������ֵ
		SampleStartColumn = UserInputData.SampleStartColumn;

		//���¼�����Ⱦɫ��ֲ�ͼ����������λ����Ϣ
		String[] ColumnNameLin = new String[SampleStartColumn];
		for (int i = 1; i <= SampleStartColumn; i++) {
			ColumnNameLin[i - 1] = "Column " + i;
		}
		jComboBoxchrom.setModel(new javax.swing.DefaultComboBoxModel(
				ColumnNameLin));
		jComboBoxstart.setModel(new javax.swing.DefaultComboBoxModel(
				ColumnNameLin));
		jComboBoxend.setModel(new javax.swing.DefaultComboBoxModel(
				ColumnNameLin));
		jComboBoxspecies.setSelectedIndex(UserInputData.SpeciesNum); //����˳����ʼΪ0��                    
		jComboBoxchrom.setSelectedIndex(UserInputData.ChromsomeColumn + 1); //Ⱦɫ���У���ʼΪ0��
		jComboBoxstart.setSelectedIndex(UserInputData.RegionStartColumn + 1); //����ʼ�� ����ʼΪ0��
		jComboBoxend.setSelectedIndex(UserInputData.RegionEndColumn + 1); //������ֹ�� ����ʼΪ0��

		//���¼��У����ݸ�Ҫ��Ϣ���û��ṩ�ĵ�ַ��ȡ���ݲ����¹ؼ���
		DataInput InputUserData = new DataInput(InputfilePath, Separator,
				ColumnNum, FirstLineIsColumnName, SampleStartColumn); //�������ݵ����ർ���û�������
		ProgressBar(10);
		final String[][] UserData = InputUserData.getData(); //�����û����������
		final String[] ColumnName = InputUserData.getColumnName(); //�����û����ݸ��е�����
		UserDataRowNum = InputUserData.UserDataRowNum; //��ȡ�û��������ݵ�����(����������)
		//		System.out.println(UserDataRowNum);
		SampleNum = InputUserData.getSampleNum(); //��ȡ�û��������ݵ�������Ŀ
		ProgressBar(75);
		//���¼��У����ݵõ����û����ݣ������ݽ�����ʾ�ͷ���
		if (UserDataRowNum > 0) { //���û������������������0ʱ�����û������������
			DataInputview(UserData, ColumnName); //����������ʾ�û����������
		}
		ProgressBar(100);
		jTextAreaGuide
				.setText("1. Methylation data has been successfully loaded.\n"
						+ "2. And the data has been shown in the data table.\n"
						+ "3. Methylation levels in the first row were shown in RegionMethyView acquiescently.\n"
						+ "4. The first column named \"RegionID\" is generated automatically as the ID for each region in QDMR.\n"
						+ "5. Next you can do each of the following operations:\n"
						+ "		1) Click a row to view the methylation level across samples and set the image properties by right click.\n"
						+ "		2) Double-click a row to view the region information in the UCSC Genome Browser.\n"
						+ "		2) Click \"Quantify Difference\" button to canculate entropy for all regions.\n");
		jTextAreaGuide.setCaretPosition(0);
		CanculateEntropy.setEnabled(true); //���ü����ذ�ť����
		CanculateEntropyMenuItem.setEnabled(true); //���ü����صĲ˵�����
	}

	/**
	 * @param ���û�����������ڱ�������������������г�
	 */
	private void DataInputview(String[][] UserData, String[] ColumnName) {
		Object[][] RowData = UserData;
		UserDataTable.setModel( //�½�һ��JTable������Ԫ�����óɲ��ɱ༭��������ѡ���к���
				new javax.swing.table.DefaultTableModel(RowData, ColumnName) {
					private static final long serialVersionUID = 1L;

					public boolean isCellEditable(int row, int column) {
						return false;
					}
				});
		UserDataTable.getSelectionModel().setSelectionInterval(0, 0);
		UserDataTablePanel.setViewportView(UserDataTable);
		jTabbedPaneTestView.setSelectedIndex(0);
		jTabbedPaneTestView.setForegroundAt(0, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(1, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(2, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(jTabbedPaneTestView
				.getSelectedIndex(), Color.RED);
		UserDataTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); //AUTO_RESIZE_OFF ���Զ������еĿ��ȣ�ʹ�ù�������
		UserDataTable.getTableHeader().setReorderingAllowed(false); //�����еı�ͷ�����϶�
		new DMRView(jPanelViewDMRs, jSplitPane3, UserDataTable, 0,
				SampleStartColumn, MaxMethylationLevel);
		//�������ݱ���˫�����ӻ��¼�
		UserDataTable.addMouseListener(new MouseAdapter() {
			//����˫���¼�
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 1) { //�õ���굥���¼�,��ʾ��ǰ�м׻�������
					int Row = UserDataTable.getSelectedRow(); //��ȡ��ǰѡ�����
					new DMRView(jPanelViewDMRs, jSplitPane3, UserDataTable,
							Row, SampleStartColumn, MaxMethylationLevel); //���ñ��е�ѡ�к��ļ׻���ֵ���ӻ�

				} else if (e.getClickCount() == 2) {//�õ����˫���¼���ͨ�����ӷ���UCSC��Ӧ����
					//**********************��������UCSC����**************************//
					try {
						UCSCLink(UserDataTable);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (URISyntaxException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
	}

	/**
	 * @param ��ȡUCSC���Ӳ�����
	 * @throws URISyntaxException 
	 * @throws IOException 
	 * @throws Exception 
	 */

	private void UCSCLink(JTable UserDataTable) throws IOException,
			URISyntaxException {
		//���¼���Ϊ������Ϣ
		String SpeciesAllName = (String) jComboBoxspecies.getSelectedItem(); //����ȫ��
		String Linshi1[] = SpeciesAllName.split("\t|\\s+\t|\t\\s+|\\s+");
		String Species = Linshi1[0]; //����
		String Linshi2[] = Linshi1[3].split("/");
		String Version = Linshi2[1].substring(0, Linshi2[1].length() - 1); //�汾��
		//���¼��л�ȡλ����Ϣ
		int Row = UserDataTable.getSelectedRow(); //��ȡ��ǰѡ�����
		String ChromNUM = (String) UserDataTable.getValueAt(Row,
				ChromsomeColumn + 1); //Ⱦɫ���
		String StartNUM = (String) UserDataTable.getValueAt(Row,
				RegionStartColumn + 1);//����ʼ
		String EndNUM = (String) UserDataTable.getValueAt(Row,
				RegionEndColumn + 1); //������ֹ
		//����UCSC����
		String UCSCLink = "http://genome.ucsc.edu/cgi-bin/hgTracks?" + "&org="
				+ Species + "&db=" + Version + "&position=" + ChromNUM + ":"
				+ StartNUM + "-" + EndNUM;
		//��������
		Desktop.getDesktop().browse(new URI(UCSCLink));

	}

	/**
	 * @param �û����Quantify Difference������ݽ��е��벢������
	 * @throws Exception 
	 */
	private void EntropyAnalysis(JTable UserDataTable) throws Exception {

		//���¼��У������û���������ݽ��з�������ȡ�׻�������
		UserDataToAnalysisData AnalysisData = new UserDataToAnalysisData(
				UserDataRowNum, SampleNum, SampleStartColumn,
				MaxMethylationLevel);
		ProgressBar(5);
		String[][] RegionInforData = AnalysisData.getRegionInformationData(
				UserDataTable, SampleStartColumn);
		ProgressBar(10);
		double[][] MethylationData = AnalysisData
				.getSampleMethylation(UserDataTable);
		if (MethylationData[0][0] == -1) {//�����������д�����ʾ�û�������ݣ���������
			JOptionPane
					.showMessageDialog(
							null,
							"Methylation value is beyond the prescribed range!\nError position: Row "+(int)MethylationData[0][1]+" and Sample Column "+(int)MethylationData[1][0]+"\n1.Please try to change the max value of methylation in the advanced panel.\n2.Please refer to the data example and then adjust your data format.",
							"Warning Message and Suggestions",
							JOptionPane.WARNING_MESSAGE);
			InputMenuItemActionPerformed();
		} else if (MethylationData[0][0] == -2) {//�����������д�����ʾ�û�������ݣ���������
			JOptionPane
					.showMessageDialog(
							null,
							"Methylation value is beyond the prescribed range!\nError position: Row "+(int)MethylationData[0][1]+" and Sample Column "+(int)MethylationData[1][0]+"\n1.Please confirm whether each methylation value is numeric type.\n2.Please confirm there is no missing value in the data file.\n3.Please refer to the data example and then adjust your data format.",
							"Warning Message and Suggestions",
							JOptionPane.WARNING_MESSAGE);
			InputMenuItemActionPerformed();
		} else {
			ProgressBar(15);
			Entropy UserDataEntropy = new Entropy(SampleNum, UserDataRowNum,
					MaxMethylationLevel);
			double[] Entropy = UserDataEntropy
					.EntropyCalculate(MethylationData);
			int ThisColumnNum = ColumnNum + 2;
			final Object[][] RegionandEntropy = new Object[UserDataRowNum][ThisColumnNum]; //��������
			final String[] EntropyColumnName = new String[ThisColumnNum]; //��ͷ��������
			for (int i = 0; i < UserDataRowNum; i++) { //���ɱ����е�����
				int CurrentColumn = 0;
				for (int j = 0; j < SampleStartColumn; j++) {
					RegionandEntropy[i][CurrentColumn++] = RegionInforData[i][j]; //������Ϣ
				}
				RegionandEntropy[i][CurrentColumn++] = VF.format(Entropy[i]); //��
				for (int q = 0; q < SampleNum; q++) {
					RegionandEntropy[i][CurrentColumn++] = MethylationData[i][q]; //�����׻�����Ϣ
				}
			}
			ProgressBar(95);
			int CurrentColumn = 0;
			for (int j = 0; j < SampleStartColumn; j++) {
				EntropyColumnName[CurrentColumn++] = UserDataTable
						.getColumnName(j); //������Ϣ����
			}
			EntropyColumnName[CurrentColumn++] = "Entropy"; //������
			for (int j = SampleStartColumn; j <= ColumnNum; j++) {
				EntropyColumnName[CurrentColumn++] = UserDataTable
						.getColumnName(j); //�����׻�����Ϣ����
			}
			if (UserDataRowNum > 0) {
				DataEntropyview(RegionandEntropy, EntropyColumnName); //���ú������ɱ���
			}
			ProgressBar(100);
			jTextAreaGuide
					.setText("1. The methylation difference has been quantified and shown in the entropy table.\n"
							+ "2. The first few columns contain the region information.\n"
							+ "3. The column named \"Entropy\" contains the entropy for each region.\n"
							+ "4. The last columns are the raw methylation data for each region imported by user.\n"
							+ "5. Next you can do each of the following operations:\n"
							+ "		1) Click a row to view the methylation level across samples and set the image properties by right click.\n"
							+ "		2) Double-click a row to view the region information in the UCSC Genome Browser.\n"
							+ "		3) Save entropy and raw data via \"File->Save Analysis Result->Entropy Table\".\n"
							+ "		4) Click the \"Identify DMRs\" button to identify DMRs and N-DMRs for your analysis.\n");
			jTextAreaGuide.setCaretPosition(0);
			//			EntropyExportAction(); //������ֵ����������
			IdentityDMR.setEnabled(true); //����ʶ�����׻�������ť����
			IdentifyDMRsMenuItem.setEnabled(true); //����ʶ�����׻������� �˵�����
			//			IdentifyDMRsMenuItem
			//					.addActionListener(new java.awt.event.ActionListener() {
			//						public void actionPerformed(
			//								java.awt.event.ActionEvent evt) {
			//							try {
			//								DMRIdentity(RegionandEntropy, EntropyColumnName); //���ò���׻���ɸѡ����ɸѡ����׻�������������������
			//							} catch (Exception e) {
			//								// TODO Auto-generated catch block
			//								e.printStackTrace();
			//							}
			//						}
			//					});
			//			IdentityDMR.setEnabled(true); //����ʶ�����׻�������ť����
			//			IdentifyDMRsMenuItem.setEnabled(true); //����ʶ�����׻������� �˵�����
			//			IdentityDMR.addMouseListener(new java.awt.event.MouseAdapter() { //�����û��Ƿ���в���׻���ɸѡ
			//						public void mouseClicked(java.awt.event.MouseEvent evt) { //�û�����ɸѡ
			//							try {
			//								DMRIdentity(RegionandEntropy, EntropyColumnName); //���ò���׻���ɸѡ����ɸѡ����׻�������������������
			//							} catch (Exception e) {
			//								// TODO Auto-generated catch block
			//								e.printStackTrace();
			//							}
			//						}
			//					});
		}
	}

	/**
	 * @param ���û����ݼ��������������������������г�
	 */
	private void DataEntropyview(Object[][] RegionandEntropy,
			String[] EntropyColumnName) {
		EntropyDataTable.setModel( //�½�һ��JTable������Ԫ�����óɲ��ɱ༭��������ѡ���к���
				new javax.swing.table.DefaultTableModel(RegionandEntropy,
						EntropyColumnName) {
					private static final long serialVersionUID = 1L;

					public boolean isCellEditable(int row, int column) {
						return false;
					}
				});
		EntropyDataTable.getSelectionModel().setSelectionInterval(0, 0); //ѡ�е�һ��
		EntropyPanel.setViewportView(EntropyDataTable);
		jTabbedPaneTestView.setSelectedIndex(1);
		jTabbedPaneTestView.setForegroundAt(0, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(1, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(2, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(3, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(4, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(5, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(jTabbedPaneTestView
				.getSelectedIndex(), Color.RED);
		EntropyDataTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); //AUTO_RESIZE_OFF ���Զ������еĿ��ȣ�ʹ�ù�������
		EntropyDataTable.getTableHeader().setReorderingAllowed(false); //�����еı�ͷ�����϶�
		new DMRView(jPanelViewDMRs, jSplitPane3, EntropyDataTable, 0,
				MaxMethylationLevel, SampleStartColumn);
		JTableViewListener(EntropyDataTable); //����ѡ��ĳ�б�ѡ����¼���Ȼ���ڻ�ͼ������Ƽ׻���ֵ�ֲ�ͼ
		jMenuExport.setEnabled(true); //���ñ���˵�����
		jMenuItemExportEntropy.setEnabled(true); //������ֵ�������˵�����

	}

	/**
	 * @param �û����Identity DME�󣬴������ص��б���ɸѡ����׻������򣬱�׼��Ԥ����ı�׼��ȡ����������Ŀ
	 * @throws Exception 
	 */
	private void DMRIdentity(JTable EntropyDataTable) {
		ProgressBar(5);
		DMRClassify DMRClassification = new DMRClassify(UserDataRowNum,SampleStartColumn, SampleNum,SDcolumn);
		double[][] EntropySorted = DMRClassification.EntropySort(EntropyDataTable);
		String[] EntropyColumnName = DMRClassification.getEntropyColumnName(EntropyDataTable);
		ProgressBar(80);
		//		int IDMRLocation = DMRClassify.IDMRLocation;
		int DMRLocation = DMRClassify.DMRLocation;
		int TableColumnNum = EntropyDataTable.getColumnCount();
		DMRNum = 0; //��ʼ��DMR�ĸ���
		NDMRNum = 0; //��ʼ��NDMR�ĸ���
		//		int IDMRNum = 0;
		int Row = 0;
		//��ȡ����׻�������
		Object[][] DMR = new Object[DMRLocation][TableColumnNum];
		for (int i = 0; i < DMRLocation; i++) {
			Row = (int) EntropySorted[i][0];
			for (int j = 0; j < TableColumnNum; j++) {
				DMR[i][j] = EntropyDataTable.getValueAt(Row, j);
			}
			DMRNum++;
		}
		String DMRpro = VF1.format(DMRNum * 100.0 / UserDataRowNum);
		ProgressBar(85);
		//��ȡ�ǲ���׻�������
		Object[][] NDMR = new Object[UserDataRowNum - DMRLocation][TableColumnNum];
		for (int i = (UserDataRowNum - 1); i >= DMRLocation; i--) {
			Row = (int) EntropySorted[i][0];
			for (int j = 0; j < TableColumnNum; j++) {
				NDMR[NDMRNum][j] = EntropyDataTable.getValueAt(Row, j);
			}
			NDMRNum++;
		}
		String NDMRpro = VF1.format(NDMRNum * 100.0 / UserDataRowNum);
		ProgressBar(90);
		//		//��ȡ�м����׻�������
		//		Object[][] IDMR = new Object[NDMRLocation - IDMRLocation][TableColumnNum];
		//		for (int i = IDMRLocation; i < NDMRLocation; i++) {
		//			Row = (int) EntropySorted[i][0];
		//			for (int j = 0; j < TableColumnNum; j++) {
		//				IDMR[i - IDMRLocation][j] = EntropyDataTable.getValueAt(Row, j);
		//			}
		//			IDMRNum++;
		//		}
		//		String IDMRpro = VF1.format(100 - Double.parseDouble(DMRpro)- Double.parseDouble(NDMRpro));
		//		System.out.println(EntropySorted[0]);		
		ProgressBar(95);
		D_N_I_MRView(DMR, NDMR, EntropyColumnName);
		jLabelSampleNuma.setText(String.valueOf(SampleNum));
		jLabelThreDMR.setText(String.valueOf(DMRClassify.DMRThreshold));
		//		jLabelThreNDMR.setText(String.valueOf(DMRClassify.NDMRThreshold));

		jLabelDMRNum.setText(DMRNum + "");
		jLabelDMRNum1.setText("(" + DMRpro + "%)");
		jLabelNDMRNum.setText(NDMRNum + "");
		jLabelNDMRNum1.setText("(" + NDMRpro + "%)");
		//		jLabelIDMRNum.setText(IDMRNum + "");
		//		jLabelIDMRNum1.setText("(" + IDMRpro + "%)");
		//���ñ�ͼ���������ֲ�ͼ (��ʱ����)
		ProgressBar(100);
		jTextAreaGuide
				.setText("1. DMRs and N-DMRs have been identified and shown in the DMR and N-DMR table, respectively.\n"
						+ "2. DMR table contains regions owning entropy less than the DMR threshold.\n"
						+ "3. N-DMR table contains regions owning entropy greater than the N-DMR threshold.\n"
						+ "4. Statistics table contains the statistics of regions and DMR distribution in chromosomes.\n"
						+ "5. Next you can do each of the following operations:\n"
						+ "		1) Click a row to view the methylation level across samples and set the image properties by right click.\n"
						+ "		2) Double-click a row to view the region information in the UCSC Genome Browser.\n"
						+ "		3) Save DMRs and N-DMRs via \"File->Save Analysis Result->DMR or N-DMR Table\".\n"
						+ "		4) See the statistics information and DMR distribution in chromosomes in Statistics Table.\n"
						+ "		5) Click the \"Measure Specificity\" button to measure the sample specificity for all DMRs.\n");
		jTextAreaGuide.setCaretPosition(0);
		jButtonSpecificity.setEnabled(true); //���ñ������׻�������ť����
		jMenuItemExportDMR.setEnabled(true); //����DMR����˵�����
		jMenuItemExportNDMR.setEnabled(true); //����NDMR����˵�����
		//		jMenuItemExportIDMR.setEnabled(true); //����IDMR����˵�����
		jMenuItemStatistics.setEnabled(true); //����ͳ�Ʊ�����˵�����
		jMenuItemAllTables.setEnabled(true); //����ȫ��������˵�����

		jButtonSpecificity.setEnabled(true); //����ʶ���������׻�������ť����
		jMenuItemSpecificity.setEnabled(true); //����ʶ���������׻������� �˵�����
		jButtonDMRDistribution.setEnabled(true); //���ò���׻���������Ⱦɫ���ϵķֲ���ť����
		//	DMRExportAction(); //���ò���׻��������������
	}

	/**
	 * @param ��ɸѡ�����Ĳ���׻������򡢷ǲ���׻�����������������������г�
	 */
	private void D_N_I_MRView(Object[][] DMR, Object[][] NDMR,
			String[] EntropyColumnName) {
		//���¼���Ϊ����׻����������ʾ
		if (DMRNum > 0) {
			jTableDMR.setModel( //�½�һ��JTable������Ԫ�����óɲ��ɱ༭��������ѡ���к���
					new javax.swing.table.DefaultTableModel(DMR,
							EntropyColumnName) {
						private static final long serialVersionUID = 1L;

						public boolean isCellEditable(int row, int column) {
							return false;
						}
					});
			jTableDMR.getSelectionModel().setSelectionInterval(0, 0); //ѡ�е�һ��
			jScrollPane1.setViewportView(jTableDMR);

			//		jSplitPane4.setTopComponent(jScrollPane1);
			jTableDMR.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); //AUTO_RESIZE_OFF ���Զ������еĿ��ȣ�ʹ�ù�������
			jTableDMR.getTableHeader().setReorderingAllowed(false); //�����еı�ͷ�����϶�
		}
		//���¼���Ϊ�ǲ���׻����������ʾ
		if (NDMRNum > 0) {
			jTableNDMR.setModel( //�½�һ��JTable������Ԫ�����óɲ��ɱ༭��������ѡ���к���
					new javax.swing.table.DefaultTableModel(NDMR,
							EntropyColumnName) {
						private static final long serialVersionUID = 1L;

						public boolean isCellEditable(int row, int column) {
							return false;
						}
					});
			jTableNDMR.getSelectionModel().setSelectionInterval(0, 0); //ѡ�е�һ��
			jScrollPane4.setViewportView(jTableNDMR);

			//		jSplitPane4.setTopComponent(jScrollPane1);
			jTableNDMR.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); //AUTO_RESIZE_OFF ���Զ������еĿ��ȣ�ʹ�ù�������
			jTableNDMR.getTableHeader().setReorderingAllowed(false); //�����еı�ͷ�����϶�
		}
		//���¼���Ϊ�м����׻����������ʾ
		//		jTableIDMR.setModel( //�½�һ��JTable������Ԫ�����óɲ��ɱ༭��������ѡ���к���
		//				new javax.swing.table.DefaultTableModel(IDMR, EntropyColumnName) {
		//					private static final long serialVersionUID = 1L;
		//
		//					public boolean isCellEditable(int row, int column) {
		//						return false;
		//					}
		//				});
		//		jTableIDMR.getSelectionModel().setSelectionInterval(0, 0); //ѡ�е�һ��
		//		jScrollPane5.setViewportView(jTableIDMR);
		//		jSplitPane4.setTopComponent(jScrollPane1);
		jTableSpecificity.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); //AUTO_RESIZE_OFF ���Զ������еĿ��ȣ�ʹ�ù�������
		jTableSpecificity.getTableHeader().setReorderingAllowed(false); //�����еı�ͷ�����϶�
		jTabbedPaneTestView.setSelectedIndex(2);
		jTabbedPaneTestView.setForegroundAt(0, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(1, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(2, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(jTabbedPaneTestView
				.getSelectedIndex(), Color.RED);
		if (DMRNum > 0 & NDMRNum > 0) {
			new DMRView(jPanelViewDMRs, jSplitPane3, jTableDMR, 0,
					MaxMethylationLevel, SampleStartColumn);
			JTableViewListener(jTableDMR); //����ѡ��ĳ�б�ѡ����¼���Ȼ���ڻ�ͼ������Ƽ׻���ֵ�ֲ�ͼ
			JTableViewListener(jTableNDMR); //����ѡ��ĳ�б�ѡ����¼���Ȼ���ڻ�ͼ������Ƽ׻���ֵ�ֲ�ͼ
		} else if (DMRNum > 0) {
			new DMRView(jPanelViewDMRs, jSplitPane3, jTableDMR, 0,
					MaxMethylationLevel, SampleStartColumn);
			JTableViewListener(jTableDMR); //����ѡ��ĳ�б�ѡ����¼���Ȼ���ڻ�ͼ������Ƽ׻���ֵ�ֲ�ͼ
		} else if (NDMRNum > 0) {
			new DMRView(jPanelViewDMRs, jSplitPane3, jTableNDMR, 0,
					MaxMethylationLevel, SampleStartColumn);
			JTableViewListener(jTableNDMR); //����ѡ��ĳ�б�ѡ����¼���Ȼ���ڻ�ͼ������Ƽ׻���ֵ�ֲ�ͼ
		}

		//		JTableViewListener(jTableIDMR); //����ѡ��ĳ�б�ѡ����¼���Ȼ���ڻ�ͼ������Ƽ׻���ֵ�ֲ�ͼ
	}

	/**
	 * @param �û����Measure Specificity�󣬴�����DMR���б����е�DMR�У�����ÿ��DMR��ÿ����֯�е�������
	 * @throws IOException 
	 * @throws Exception 
	 */
	private void DMRSpecificity(JTable DMRTable) throws IOException {
		// TODO Auto-generated method stub
		ProgressBar(1);
		double jindu = 0.0;
		double danweijindu = (100.0 - jindu) / ((SampleNum + 1) * DMRNum);
		UserDataToAnalysisData AnalysisData = new UserDataToAnalysisData(
				DMRNum, SampleNum, SampleStartColumn + 1, MaxMethylationLevel);
		String[][] RegionInforData = AnalysisData.getRegionInformationData(
				DMRTable, SampleStartColumn);
		double[][] MethylationData = AnalysisData
				.getSampleMethylation(DMRTable);
		Entropy UserDataEntropy = new Entropy(SampleNum, DMRNum,
				MaxMethylationLevel);
		double[][] EntropyAndQ = UserDataEntropy.EntropyCalculate_withQ(
				MethylationData, danweijindu);
		ProgressBar((int) (100 / (SampleNum + 1)));
		jindu = (int) (100 / (SampleNum + 1));

		//		EntropyAndQ= UserDataEntropy.DMRSpecificMeasure(MethylationData,EntropyAndQ);
		EntropyAndQ = UserDataEntropy.DMRSpecificMeasure(MethylationData,
				EntropyAndQ, jindu, danweijindu);
		ProgressBar(95);

		int ThisColumnNum = ColumnNum + 1 + SampleNum + 1;
		final Object[][] RegionandEntropyandQ = new Object[DMRNum][ThisColumnNum]; //��������
		final String[] EntropyandQColumnName = new String[ThisColumnNum]; //��ͷ��������
		for (int i = 0; i < DMRNum; i++) { //���ɱ����е�����
			int CurrentColumn = 0;
			for (int j = 0; j < SampleStartColumn; j++) {
				RegionandEntropyandQ[i][CurrentColumn++] = RegionInforData[i][j]; //������Ϣ
			}
			for (int s = 0; s < (SampleNum + 1); s++) {
				RegionandEntropyandQ[i][CurrentColumn++] = VF
						.format(EntropyAndQ[i][s]); //�غ�Qֵ��Ϣ
			}
			for (int q = 0; q < SampleNum; q++) {
				RegionandEntropyandQ[i][CurrentColumn++] = MethylationData[i][q]; //�����׻�����Ϣ
			}
		}
		int CurrentColumn = 0;
		for (int j = 0; j < SampleStartColumn; j++) {
			EntropyandQColumnName[CurrentColumn++] = EntropyDataTable
					.getColumnName(j); //������Ϣ����
		}
		EntropyandQColumnName[CurrentColumn++] = "Entropy"; //������
		for (int s = 0; s < SampleNum; s++) {
			EntropyandQColumnName[CurrentColumn++] = "CS_"
					+ UserDataTable.getColumnName(s + SampleStartColumn); //Qֵ��Ϣ����
		}
		for (int j = SampleStartColumn; j <= ColumnNum; j++) {
			EntropyandQColumnName[CurrentColumn++] = UserDataTable
					.getColumnName(j); //�����׻�����Ϣ����
		}
		if (DMRNum > 0) {
			DataSpecificityview(RegionandEntropyandQ, EntropyandQColumnName); //���ú������ɱ���
		}
		ProgressBar(100);
		jTextAreaGuide
				.setText("1. The measurement of sample specificity has been finished and shown in the Specificity Table.\n"
						+ "2. The first few columns contain the region information.\n"
						+ "3. The column named \"Entropy\" contains the entropy for each region.\n"
						+ "4. The columns named as \"CS_\" contain the specificity of each region in every sample.\n"
						+ "5. The last columns are the raw methylation data for each region imported by user.\n"
						+ "6. Next you can do each of the following operations:\n"
						+ "		1) Click a row to view the methylation level across samples and set the image properties by right click.\n"
						+ "		2) Double-click a row to view the region information in the UCSC Genome Browser.\n"
						+ "		3) Save Specificity Table via \"File->Save Analysis Result->Specificity Table\".\n"
						+ "		4) Save All Results by clicking \"Export All Results\" or via \"File->Save Analysis Result->All Results\".\n"
						+ "		5) Click the icon to visit our web and give us recommendations for improvement.\n"
						+ "7. Thanks for your use of QDMR. Best wishes to you!");
		jTextAreaGuide.setCaretPosition(0);
		jButtonAllResults.setEnabled(true); //����ʶ�����׻�������ť����
		jMenuItemAllTables.setEnabled(true); //����ʶ�����׻������� �˵�����
		jMenuItemExportIDMR.setEnabled(true);
	}

	/**
	 * @param ���û����ݼ��������������������������г�
	 */
	private void DataSpecificityview(Object[][] RegionandEntropy,
			String[] EntropyColumnName) {
		jTableSpecificity.setModel( //�½�һ��JTable������Ԫ�����óɲ��ɱ༭��������ѡ���к���
				new javax.swing.table.DefaultTableModel(RegionandEntropy,
						EntropyColumnName) {
					private static final long serialVersionUID = 1L;

					public boolean isCellEditable(int row, int column) {
						return false;
					}
				});
		jTableSpecificity.getSelectionModel().setSelectionInterval(0, 0); //ѡ�е�һ��
		jScrollPane5.setViewportView(jTableSpecificity);
		jTabbedPaneTestView.setSelectedIndex(4);
		jTabbedPaneTestView.setForegroundAt(0, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(1, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(2, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(3, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(4, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(5, Color.BLUE);
		jTabbedPaneTestView.setForegroundAt(jTabbedPaneTestView
				.getSelectedIndex(), Color.RED);
		jTableSpecificity.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); //AUTO_RESIZE_OFF ���Զ������еĿ��ȣ�ʹ�ù�������
		jTableSpecificity.getTableHeader().setReorderingAllowed(false); //�����еı�ͷ�����϶�
		new DMRView(jPanelViewDMRs, jSplitPane3, jTableSpecificity, 0,
				SampleNum, SampleStartColumn, MaxMethylationLevel);
		JTableViewSpecificityListener(); //����ѡ��ĳ�б�ѡ����¼���Ȼ���ڻ�ͼ������Ƽ׻���ֵ�ֲ�ͼ
		jMenuExport.setEnabled(true); //���ñ���˵�����
		jMenuItemExportEntropy.setEnabled(true); //������ֵ�������˵�����

	}

	/**
	 * @param Ϊĳ�����õ�JTable���û�ͼ����(�ر���DMR��N-DMR���Ŀ��Ӽ���)
	 */
	private void JTableViewListener(final JTable SelectedTable) {
		SelectedTable.addMouseListener(new MouseAdapter() {
			//���ڵ�/˫���¼�
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 1) {//�õ���굥���¼�����ҪΪ˫��ֻ�轫1��Ϊ2.
					int Row = SelectedTable.getSelectedRow(); //��ȡ��ǰѡ�����
					new DMRView(jPanelViewDMRs, jSplitPane3, SelectedTable,
							Row, MaxMethylationLevel, SampleStartColumn); //���ñ��е�ѡ�к��ļ׻���ֵ���ӻ�
				} else if (e.getClickCount() == 2) {//�õ����˫���¼���ͨ�����ӷ���UCSC��Ӧ����
					//**********************��������UCSC����**************************//
					try {
						UCSCLink(SelectedTable);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (URISyntaxException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}

			}
		});
	}

	/**
	 * @param Ϊĳ�����õ�JTable���û�ͼ����(��֯�����Ա��ļ���)
	 */
	private void JTableViewSpecificityListener() {
		jTableSpecificity.addMouseListener(new MouseAdapter() {
			//���ڵ�/˫���¼�
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 1) {//�õ���굥���¼�����ҪΪ˫��ֻ�轫1��Ϊ2.
					int Row = jTableSpecificity.getSelectedRow(); //��ȡ��ǰѡ�����
					new DMRView(jPanelViewDMRs, jSplitPane3, jTableSpecificity,
							Row, SampleNum, SampleStartColumn,
							MaxMethylationLevel); //���ñ��е�ѡ�к��ļ׻���ֵ���ӻ�
				} else if (e.getClickCount() == 2) {//�õ����˫���¼���ͨ�����ӷ���UCSC��Ӧ����
					//**********************��������UCSC����**************************//
					try {
						UCSCLink(jTableSpecificity);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (URISyntaxException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
	}

	//	/**
	//	 * @param Ϊĳ�����õ�JTable���û�ͼ����(��һ������ĳ�б�ѡ��ʱ����ʾ���еļ׻���ֵ)
	//	 */
	//	private void JTableViewListener(final JTable SelectedTable) {
	//		//�������ݱ���ѡ�����м׻���ֵ�Ŀ��ӻ��¼�
	//		ListSelectionModel model = SelectedTable.getSelectionModel();
	//		model.addListSelectionListener(new ListSelectionListener() {
	//			public void valueChanged(ListSelectionEvent e) {
	//				int Row = SelectedTable.getSelectedRow(); //��ȡ��ǰѡ�����
	//				new DMRView(jPanelViewDMRs, jSplitPane3, SelectedTable, Row,
	//						SampleNum, SampleStartColumn, MaxMethylationLevel); //���ñ��е�ѡ�к��ļ׻���ֵ���ӻ�
	//			}
	//		});
	//	}

	/**
	 * @param ���������ȸ���
	 */
	public static void ProgressBar(int jindu) {
		jProgressBar.setValue(jindu);
		jProgressBar.paintImmediately(0, 0, jProgressBar.getSize().width,
				jProgressBar.getSize().height);
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) throws Exception {
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); //����ϵͳ�Ӿ�����
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new QDMR().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton CanculateEntropy;
	private javax.swing.JMenuItem CanculateEntropyMenuItem;
	private javax.swing.JButton DataInput;
	private javax.swing.JTable EntropyDataTable;
	private javax.swing.JScrollPane EntropyPanel;
	private javax.swing.JMenuItem ExportMenuItem;
	private javax.swing.JMenuItem IdentifyDMRsMenuItem;
	private javax.swing.JButton IdentityDMR;
	private javax.swing.JMenuItem InputMenuItem;
	private javax.swing.JMenuItem InputMenuItem1;
	private javax.swing.JMenuItem OnlineServiceMenuItem;
	private javax.swing.JTable UserDataTable;
	private javax.swing.JScrollPane UserDataTablePanel;
	private javax.swing.JMenuItem aboutMenuItem;
	private javax.swing.JMenuItem aboutMenuItem1;
	private javax.swing.JMenuItem contentsMenuItem;
	private javax.swing.JMenuItem contentsMenuItem1;
	private javax.swing.JMenuItem copyMenuItem;
	private javax.swing.JMenuItem cutMenuItem;
	private javax.swing.JMenuItem deleteMenuItem;
	private javax.swing.JMenu editMenu;
	private javax.swing.JMenu editMenu1;
	private javax.swing.JMenuItem exitMenuItem;
	private javax.swing.JMenuItem exitMenuItem1;
	private javax.swing.JMenu fileMenu;
	private javax.swing.JMenu fileMenu1;
	private javax.swing.JMenu helpMenu;
	private javax.swing.JMenu helpMenu1;
	private javax.swing.JButton jButtonAllResults;
	private javax.swing.JButton jButtonDMRDistribution;
	private javax.swing.JButton jButtonSpecificity;
	private javax.swing.JComboBox jComboBoxPlot;
	private javax.swing.JComboBox jComboBoxchrom;
	private javax.swing.JComboBox jComboBoxend;
	private javax.swing.JComboBox jComboBoxspecies;
	private javax.swing.JComboBox jComboBoxstart;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JLabel jLabelDMRNum;
	private javax.swing.JLabel jLabelDMRNum1;
	private javax.swing.JLabel jLabelLogo;
	private javax.swing.JLabel jLabelNDMRNum;
	private javax.swing.JLabel jLabelNDMRNum1;
	private javax.swing.JLabel jLabelSampleNum;
	private javax.swing.JLabel jLabelSampleNum1;
	private javax.swing.JLabel jLabelSampleNum2;
	private javax.swing.JLabel jLabelSampleNuma;
	private javax.swing.JLabel jLabelThreDMR;
	private javax.swing.JLabel jLabelThresholdDMR;
	private javax.swing.JLabel jLabelchrom;
	private javax.swing.JLabel jLabelend;
	private javax.swing.JLabel jLabelendPlotOrientation;
	private javax.swing.JLabel jLabelspecies;
	private javax.swing.JLabel jLabelstart;
	private javax.swing.JMenu jMenuExport;
	private javax.swing.JMenuItem jMenuItemAllTables;
	private javax.swing.JMenuItem jMenuItemExportDMR;
	private javax.swing.JMenuItem jMenuItemExportEntropy;
	private javax.swing.JMenuItem jMenuItemExportIDMR;
	private javax.swing.JMenuItem jMenuItemExportNDMR;
	private javax.swing.JMenuItem jMenuItemOnline;
	private javax.swing.JMenuItem jMenuItemSpecificity;
	private javax.swing.JMenuItem jMenuItemStatistics;
	private javax.swing.JMenuItem jMenuItemThreshold;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JPanel jPanel3;
	private javax.swing.JPanel jPanel4;
	private javax.swing.JPanel jPanelViewDMRs;
	private javax.swing.JPanel jPanel_Test;
	private static javax.swing.JProgressBar jProgressBar;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JScrollPane jScrollPane2;
	private javax.swing.JScrollPane jScrollPane3;
	private javax.swing.JScrollPane jScrollPane4;
	private javax.swing.JScrollPane jScrollPane5;
	private javax.swing.JSeparator jSeparator1;
	private javax.swing.JSeparator jSeparator2;
	private javax.swing.JSeparator jSeparator3;
	private javax.swing.JSeparator jSeparator4;
	private javax.swing.JSeparator jSeparator5;
	private javax.swing.JSeparator jSeparator6;
	private javax.swing.JSeparator jSeparator8;
	private javax.swing.JSplitPane jSplitPane1;
	private javax.swing.JSplitPane jSplitPane2;
	private javax.swing.JSplitPane jSplitPane3;
	private javax.swing.JSplitPane jSplitPane4;
	private javax.swing.JTabbedPane jTabbedPaneTestView;
	private javax.swing.JTable jTableDMR;
	private javax.swing.JTable jTableNDMR;
	private javax.swing.JTable jTableSpecificity;
	private javax.swing.JTextArea jTextArea1;
	private javax.swing.JTextArea jTextAreaGuide;
	private javax.swing.JMenuBar menuBar;
	private javax.swing.JMenuBar menuBar1;
	private javax.swing.JMenuItem openMenuItem;
	private javax.swing.JMenuItem pasteMenuItem;
	private javax.swing.JMenuItem saveAsMenuItem;
	private javax.swing.JMenuItem saveMenuItem;
	// End of variables declaration//GEN-END:variables

}