import java.awt.BasicStroke;
import java.awt.Color;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTable;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.DatasetRenderingOrder;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.LevelRenderer;
import org.jfree.data.category.DefaultCategoryDataset;


public class ChromDMRView {
    int RegionChrom=2;        //Ⱦɫ����
    int RegionStart=3;        //��ʼλ����
    int RegionEnd=4;          //��ֹλ����
    int Rownum=0;             //Ⱦɫ����DMR���������ֵ
    String Species="Human Build 36";  //����
    int PlotOrien=0;          //Ⱦɫ�廭ͼ����0������1������
	
	/**  
	 ** ���ݿ��ӻ��������û�����׻�������DMR�����ݿ��ӻ���.
	 * @param plotOrien 
	 * @param endColumn 
	 * @param startColumn 
	 * @param chromColumn 
	 * @param species 
     */
	public ChromDMRView(JPanel jPanelViewDMRs, JSplitPane jSplitPane3, JTable jTableDMR, String speciesinput, int chromColumn, int startColumn, int endColumn, int plotOrieninput) {
		// TODO Auto-generated constructor stub
		Species=speciesinput;
		RegionChrom=chromColumn;
		RegionStart=startColumn;
		RegionEnd=endColumn;
		PlotOrien=plotOrieninput;
	    
        final JFreeChart chart = createChart(jTableDMR);  //��JFreeChart������ͼ
        jPanelViewDMRs = new ChartPanel(chart);         //��ͼ���ӵ���������ӻ�����
        jPanelViewDMRs.setBorder(javax.swing.BorderFactory.createTitledBorder(  //���ÿ��ӻ���������
				null, "RegionMethyView",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
				javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Arial", 1, 12),
				new java.awt.Color(0, 0, 255)));
		
        jSplitPane3.setRightComponent(jPanelViewDMRs);    //���ӵ�������
        jSplitPane3.setDividerLocation(250);             //���÷ָ�ڱ���
	}

	 /**
     * ����DMR��Ⱦɫ���ϵķֲ�ͼ��
     * @return ����ͼ��ʾ�ڹ���ͼ����.
     */
	@SuppressWarnings({ "deprecation", "unchecked" })
	private JFreeChart createChart(JTable jTableDMR) {
        
        //���ȴ���Ⱦɫ�峤����Ϣ����ͨ��������ʹ����ӳ�����ʣ�
        DefaultCategoryDataset DatasetChrom = new DefaultCategoryDataset();
        DatasetChrom=DatasetChromBuild(DatasetChrom,Species);
        
        
        // ������Ӧ���ְ汾��Ⱦɫ��
        final BarRenderer renderer = new BarRenderer();          //����Ⱦɫ����Ӧ��������
        renderer.setPaint(Color.lightGray);                           //����ÿ��Ⱦɫ�����ɫ
//        renderer.setPaint(Color.getHSBColor(0.58f, 1.0f, 1.0f)); //����ÿ��Ⱦɫ�����ɫ
        
        renderer.setMaximumBarWidth(0.02);                       //����ÿ��Ⱦɫ��Ŀ���
        renderer.setShadowVisible(false);                        //������Ӱ�Ƿ�ɼ�
        renderer.setBaseOutlinePaint(Color.BLACK);               // �������ӱ߿���ɫ  
        renderer.setDrawBarOutline(true);                        // �������ӱ߿�ɼ�
        renderer.setToolTipGenerator(new StandardCategoryToolTipGenerator());  //����ͼƬ��Ӧ�Ĺ���
        final CategoryPlot plot = new CategoryPlot();            //����ͼ
        plot.setDataset(DatasetChrom);                           //����Ⱦɫ��λ����Ϣ����ͼ
        plot.setRenderer(renderer);                              //����������λ����Ϣ��ͼ
//        plot.setForegroundAlpha(0.2f);                         //�������ӵ�͸����

        
        
        CategoryAxis CategoryAxis =new CategoryAxis("Chromosome");
        if(PlotOrien==0){
            CategoryAxis.setCategoryLabelPositions(CategoryLabelPositions.DOWN_45); //�����ϵ� Lable 45����б 
        }else{
        	CategoryAxis.setCategoryLabelPositions(CategoryLabelPositions.STANDARD); //�����ϵ� Lable 45����б 	
        }
//        CategoryAxis.setCategoryLabelPositions(CategoryLabelPositions.createUpRotationLabelPositions(Math.PI /1.5));
        plot.setDomainAxis(CategoryAxis);     //ͼ�к�������lable��Ⱦɫ��
        plot.setRangeAxis(new NumberAxis("DMR Position"));      //ͼ����������lable������׻�������λ��
        if(PlotOrien==0){
            plot.setOrientation(PlotOrientation.VERTICAL);          //������ͼ���������û��Լ����ƣ�
        }else{
            plot.setOrientation(PlotOrientation.HORIZONTAL);        //���ú�ͼ���������û��Լ����ƣ�     
        }
//      plot.setRangeGridlinesVisible(false);                 //�������񲻿ɼ���Ĭ��Ϊ�ɼ���
        QDMR.ProgressBar(5);  //��������Ľ���
        

       
        
        
        //��ʼ����DMR��Ⱦɫ���ϵķֲ�
        //��һ�����ȴ�Ⱦɫ��ͼ�л��Ⱦɫ�������
        List Chromcategory= DatasetChrom.getColumnKeys();
        int ChromNum=Chromcategory.size();
        Comparable [] ChromName=new Comparable[ChromNum];  //���ַ���������ת��ΪComparable����
        for(int i=0;i<ChromNum;i++){ChromName[i]=(Comparable<String>) Chromcategory.get(i);}
        //�ڶ�����������Ⱦɫ����QDMR�����ݼ���ͨ�������ӳ���
        int[][] AllDMRRegion=AllDMRRegionBuild(Chromcategory,jTableDMR);
        //�����������õ������ݼ���ÿ�еĲ���׻����������ӵ���Ӧ��Ⱦɫ��λ����
        QDMR.ProgressBar(10);  //��������Ľ���
        int RegionCenter=0;
        for(int i=0;i<Rownum;i++){ //��ȡÿ�����ݲ����������ͼ����
        	QDMR.ProgressBar(10+90*(i+1)/Rownum);  //��������Ľ���
//        	System.out.println(i/Rownum+"%");
        	//1����õ�ǰ�е�����
        	DefaultCategoryDataset DatasetDMR = new DefaultCategoryDataset();  //��¼ÿ���е�DMRλ����Ϣ
        	for (int j=0;j<ChromNum;j++){
        		if(AllDMRRegion[i][j*2]>=0){ //����ǰ�����ڸ�Ⱦɫ������DMR�������DMR���ģ�����DMR��Ϣ
        		     RegionCenter=(AllDMRRegion[i][j*2]+AllDMRRegion[i][j*2+1])/2;  //��ȡDMR���������
//        		     System.out.println(ChromName[j]);
        		     DatasetDMR.addValue(RegionCenter, "DMR", ChromName[j]);  //����һ��DMRλ��
        		}else{                     //����ǰ�����ڸ�Ⱦɫ����û��DMR���򽫿�null���ӵ���Ⱦɫ��
        			 DatasetDMR.addValue(null, "DMR", ChromName[j]);  //����һ��DMRλ��
        		}
        			
        	}
        	//2������DMR��ظ�ʽ
        	final LevelRenderer RendereDMR = new LevelRenderer();  //DMR��ʽ����
           	RendereDMR.setPaint(Color.RED);    //DMR�ߵ���ɫ
//        	RendereDMR.setPaint(Color.getHSBColor(1f, 1f, 1f));         //DMR�ߵ���ɫ
        	RendereDMR.setMaximumItemWidth(0.02);                       //DMR�ߵĿ���
//        	RendereDMR.setMaximumItemWidth(0.7f);                       //DMR�ߵĿ���
//        	RendereDMR.setSeriesOutlineStroke(i+1, new BasicStroke(0.005f));
        	if(Rownum<=100){
        	   RendereDMR.setStroke(new BasicStroke(0.7f));                  //DMR�ߵĴ�ϸ
        	}else if (Rownum<=300){
        	   RendereDMR.setStroke(new BasicStroke(0.4f));                  //DMR�ߵĴ�ϸ
        	}else if (Rownum<=500){
        	   RendereDMR.setStroke(new BasicStroke(0.2f));                  //DMR�ߵĴ�ϸ
        	}else if (Rownum<=3000){
        	   RendereDMR.setStroke(new BasicStroke(0.1f));                  //DMR�ߵĴ�ϸ
        	}else {
        	   RendereDMR.setStroke(new BasicStroke(0.08f));                  //DMR�ߵĴ�ϸ
        	}
//        	RendereDMR.setSeriesStroke(i+1, new BasicStroke(1.6f));       //DMR�ߵĴ�ϸ
        	RendereDMR.setToolTipGenerator(new StandardCategoryToolTipGenerator());  //��ʾͼ������
        	
        	//3�����������ͼ����
            plot.setDataset(i+1, DatasetDMR);                               //����DMR������
            plot.setRenderer(i+1, RendereDMR);                              //����DMR�߸�ʽ
            plot.setDatasetRenderingOrder(DatasetRenderingOrder.FORWARD); //���ò��
        	
        }
        
//        plot.setBackgroundPaint(Color.lightGray);
        plot.setBackgroundPaint(Color.white);         //��ɫΪ��ɫ                                   //�¸�
        plot.setRangeGridlinePaint(Color.lightGray);  //��׼��Ϊǳ��ɫ                          //�¸�
        
        final JFreeChart chart = new JFreeChart(plot);
        chart.setTitle("Distribution of DMRs on chromsomes");
        chart.setBackgroundPaint(Color.white);
        chart.removeLegend();
        return chart;
        
        }
	


	/**
     * �Ӳ���׻�������������������ȡÿ��Ⱦɫ���ϵĲ���׻���������ʼλ�����ֹλ��
     * @return ����ÿ��Ⱦɫ����DMR��λ����Ϣ���������ɴ�С���У�ÿ��Ⱦɫ����������ɣ���һ��Ϊ��ʼλ�㣬�ڶ���Ϊ��ֹλ��.
     */
	@SuppressWarnings("unchecked")
	private int[][] AllDMRRegionBuild(List Chromcategory, JTable TableDMR) {
		// TODO Auto-generated method stub
		Rownum=0;
		int DMRRowNum=TableDMR.getRowCount();        //DMR������
		int ChromNum=Chromcategory.size();           //��Ⱦɫ����
		int[] Count=new int[ChromNum];               //ÿ��Ⱦɫ������ӵ��DMR��Ŀͳ��
		for (int i=0;i<ChromNum;i++)  {Count[i]=0;}  //��ʼ����ÿ��Ⱦɫ����DMR��ĿΪ0
		
		//����DMR�����е�ÿһ�У�����λ�ü�¼����Ӧ��Ⱦɫ���ϣ�������
		int[][] AllDMRRegion= new int[DMRRowNum][ChromNum*2];
		for (int i=0;i<DMRRowNum;i++){for(int j=0;j<ChromNum*2;j++){AllDMRRegion[i][j]=-1;}}  //�������е�ÿ��Ԫ�����ó�-1
		String ChromName=null;
		for(int i=0; i<DMRRowNum;i++){
			ChromName=TableDMR.getValueAt(i, RegionChrom).toString();
			
			//����ͨ��һ��ѭ�����ҵ�ǰ��DMR���ڵڼ���Ⱦɫ�岢�������ݴ�����Ӧ��λ��
			for(int j=0;j<ChromNum;j++){
				if (ChromName.equalsIgnoreCase((String) Chromcategory.get(j))){  //����ǰ��DMR�ڸ�Ⱦɫ���ϣ���¼����ʼ��ֹλ��
					AllDMRRegion[Count[j]][j*2]=Integer.parseInt(TableDMR.getValueAt(i, RegionStart).toString());  //��ʼλ��
					AllDMRRegion[Count[j]][j*2+1]=Integer.parseInt(TableDMR.getValueAt(i, RegionEnd).toString());  //��ֹλ��
					Count[j]++;
				}
			}
		}
		for(int j=0;j<ChromNum;j++){
			if (Count[j]>Rownum) Rownum=Count[j];
		}
		
		return AllDMRRegion;
	}
	
	
	
	/**
     * �����ֱ�����ȡ��Ӧ���ֵ�Ⱦɫ����Ϣ
     * @return .
     */
	private DefaultCategoryDataset DatasetChromBuild(DefaultCategoryDataset DatasetChrom, String SpeciesID) {
		// TODO Auto-generated method stub
		if (SpeciesID.equals("Human Feb. 2009 (GRCh37/hg19)")){//����
			DatasetChrom.addValue(249250621.00, "Human", "Chr1");
			DatasetChrom.addValue(243199373.00, "Human", "Chr2");
			DatasetChrom.addValue(198022430.00, "Human", "Chr3");
			DatasetChrom.addValue(191154276.00, "Human", "Chr4");
			DatasetChrom.addValue(180915260.00, "Human", "Chr5");
			DatasetChrom.addValue(171115067.00, "Human", "Chr6");
			DatasetChrom.addValue(159138663.00, "Human", "Chr7");
			DatasetChrom.addValue(146364022.00, "Human", "Chr8");
			DatasetChrom.addValue(141213431.00, "Human", "Chr9");
			DatasetChrom.addValue(135534747.00, "Human", "Chr10");
			DatasetChrom.addValue(135006516.00, "Human", "Chr11");
			DatasetChrom.addValue(133851895.00, "Human", "Chr12");
			DatasetChrom.addValue(115169878.00, "Human", "Chr13");
			DatasetChrom.addValue(107349540.00, "Human", "Chr14");
			DatasetChrom.addValue(102531392.00, "Human", "Chr15");
			DatasetChrom.addValue(90354753.00, "Human", "Chr16");
			DatasetChrom.addValue(81195210.00, "Human", "Chr17");
			DatasetChrom.addValue(78077248.00, "Human", "Chr18");
			DatasetChrom.addValue(59128983.00, "Human", "Chr19");
			DatasetChrom.addValue(63025520.00, "Human", "Chr20");
			DatasetChrom.addValue(48129895.00, "Human", "Chr21");
			DatasetChrom.addValue(51304566.00, "Human", "Chr22");
			DatasetChrom.addValue(155270560.00, "Human", "ChrX");
			DatasetChrom.addValue(59373566.00, "Human", "ChrY");
		}
		
        if (SpeciesID.equals("Human Mar. 2006 (NCBI36/hg18)")){//����
           DatasetChrom.addValue(247249719.00 , "Human", "Chr1");
           DatasetChrom.addValue(242951149.00 , "Human", "Chr2");
           DatasetChrom.addValue(199501827.00 , "Human", "Chr3");
           DatasetChrom.addValue(191273063.00 , "Human", "Chr4");
           DatasetChrom.addValue(180857866.00 , "Human", "Chr5");
           DatasetChrom.addValue(170899992.00 , "Human", "Chr6");
           DatasetChrom.addValue(158821424.00 , "Human", "Chr7");
           DatasetChrom.addValue(146274826.00 , "Human", "Chr8");
           DatasetChrom.addValue(140273252.00 , "Human", "Chr9");
           DatasetChrom.addValue(135374737.00 , "Human", "Chr10");
           DatasetChrom.addValue(134452384.00 , "Human", "Chr11");
           DatasetChrom.addValue(132349534.00 , "Human", "Chr12");
           DatasetChrom.addValue(114142980.00 , "Human", "Chr13");
           DatasetChrom.addValue(106368585.00 , "Human", "Chr14");
           DatasetChrom.addValue(100338915.00 , "Human", "Chr15");
           DatasetChrom.addValue(88827254.00 , "Human", "Chr16");
           DatasetChrom.addValue(78774742.00 , "Human", "Chr17");
           DatasetChrom.addValue(76117153.00 , "Human", "Chr18");
           DatasetChrom.addValue(63811651.00 , "Human", "Chr19");
           DatasetChrom.addValue(62435964.00 , "Human", "Chr20");
           DatasetChrom.addValue(46944323.00 , "Human", "Chr21");
           DatasetChrom.addValue(49691432.00 , "Human", "Chr22");
           DatasetChrom.addValue(154913754.00 , "Human","ChrX");
           DatasetChrom.addValue(57772954.00 , "Human", "ChrY");
        }
        
        if (SpeciesID.equals("Human May 2004 (NCBI35/hg17)")){//����
        	DatasetChrom.addValue(245442847.00, "Human", "Chr1");
        	DatasetChrom.addValue(242818229.00, "Human", "Chr2");
        	DatasetChrom.addValue(199450740.00, "Human", "Chr3");
        	DatasetChrom.addValue(191401218.00, "Human", "Chr4");
        	DatasetChrom.addValue(180837866.00, "Human", "Chr5");
        	DatasetChrom.addValue(170972699.00, "Human", "Chr6");
        	DatasetChrom.addValue(158628139.00, "Human", "Chr7");
        	DatasetChrom.addValue(146274826.00, "Human", "Chr8");
        	DatasetChrom.addValue(138429268.00, "Human", "Chr9");
        	DatasetChrom.addValue(135413628.00, "Human", "Chr10");
        	DatasetChrom.addValue(134452384.00, "Human", "Chr11");
        	DatasetChrom.addValue(132389811.00, "Human", "Chr12");
        	DatasetChrom.addValue(114127980.00, "Human", "Chr13");
        	DatasetChrom.addValue(106360585.00, "Human", "Chr14");
        	DatasetChrom.addValue(100338915.00, "Human", "Chr15");
        	DatasetChrom.addValue(88822254.00, "Human", "Chr16");
        	DatasetChrom.addValue(78654742.00, "Human", "Chr17");
        	DatasetChrom.addValue(76117153.00, "Human", "Chr18");
        	DatasetChrom.addValue(63806651.00, "Human", "Chr19");
        	DatasetChrom.addValue(62435964.00, "Human", "Chr20");
        	DatasetChrom.addValue(46944323.00, "Human", "Chr21");
        	DatasetChrom.addValue(49534710.00, "Human", "Chr22");
        	DatasetChrom.addValue(154824264.00, "Human", "ChrX");
        	DatasetChrom.addValue(57701691.00, "Human", "ChrY");
		}
        
        if (SpeciesID.equals("Human July 2003 (NCBI34/hg16)")){//����
        	DatasetChrom.addValue(246127941, "Human", "Chr1");
        	DatasetChrom.addValue(243615958, "Human", "Chr2");
        	DatasetChrom.addValue(199344050, "Human", "Chr3");
        	DatasetChrom.addValue(191731959, "Human", "Chr4");
        	DatasetChrom.addValue(181034922, "Human", "Chr5");
        	DatasetChrom.addValue(170914576, "Human", "Chr6");
        	DatasetChrom.addValue(158545518, "Human", "Chr7");
        	DatasetChrom.addValue(146308819, "Human", "Chr8");
        	DatasetChrom.addValue(136372045, "Human", "Chr9");
        	DatasetChrom.addValue(135037215, "Human", "Chr10");
        	DatasetChrom.addValue(134482954, "Human", "Chr11");
        	DatasetChrom.addValue(132078379, "Human", "Chr12");
        	DatasetChrom.addValue(113042980, "Human", "Chr13");
        	DatasetChrom.addValue(105311216, "Human", "Chr14");
        	DatasetChrom.addValue(100256656, "Human", "Chr15");
        	DatasetChrom.addValue(90041932, "Human", "Chr16");
        	DatasetChrom.addValue(81860266, "Human", "Chr17");
        	DatasetChrom.addValue(76115139, "Human", "Chr18");
        	DatasetChrom.addValue(63811651, "Human", "Chr19");
        	DatasetChrom.addValue(63741868, "Human", "Chr20");
        	DatasetChrom.addValue(46976097, "Human", "Chr21");
        	DatasetChrom.addValue(49396972, "Human", "Chr22");
        	DatasetChrom.addValue(153692391, "Human", "ChrX");
        	DatasetChrom.addValue(50286555, "Human", "ChrY");
		}
        
        if (SpeciesID.equals("Mouse July 2007 (NCBI37/mm9)")){//С��
        	DatasetChrom.addValue(197195432,"Mouse","Chr1");
        	DatasetChrom.addValue(181748087,"Mouse","Chr2");
        	DatasetChrom.addValue(159599783,"Mouse","Chr3");
        	DatasetChrom.addValue(155630120,"Mouse","Chr4");
        	DatasetChrom.addValue(152537259,"Mouse","Chr5");
        	DatasetChrom.addValue(149517037,"Mouse","Chr6");
        	DatasetChrom.addValue(152524553,"Mouse","Chr7");
        	DatasetChrom.addValue(131738871,"Mouse","Chr8");
        	DatasetChrom.addValue(124076172,"Mouse","Chr9");
        	DatasetChrom.addValue(129993255,"Mouse","Chr10");
        	DatasetChrom.addValue(121843856,"Mouse","Chr11");
        	DatasetChrom.addValue(121257530,"Mouse","Chr12");
        	DatasetChrom.addValue(120284312,"Mouse","Chr13");
        	DatasetChrom.addValue(125194864,"Mouse","Chr14");
        	DatasetChrom.addValue(103494974,"Mouse","Chr15");
        	DatasetChrom.addValue(98319150,"Mouse","Chr16");
        	DatasetChrom.addValue(95272651,"Mouse","Chr17");
        	DatasetChrom.addValue(90772031,"Mouse","Chr18");
        	DatasetChrom.addValue(61342430,"Mouse","Chr19");
        	DatasetChrom.addValue(166650296,"Mouse","ChrX");
        	DatasetChrom.addValue(15902555,"Mouse","ChrY");
		}
        
        if (SpeciesID.equals("Mouse Feb. 2006 (NCBI36/mm8)")){//С��
        	DatasetChrom.addValue(197069962,"Mouse","Chr1");
        	DatasetChrom.addValue(181976762,"Mouse","Chr2");
        	DatasetChrom.addValue(159872112,"Mouse","Chr3");
        	DatasetChrom.addValue(155029701,"Mouse","Chr4");
        	DatasetChrom.addValue(152003063,"Mouse","Chr5");
        	DatasetChrom.addValue(149525685,"Mouse","Chr6");
        	DatasetChrom.addValue(145134094,"Mouse","Chr7");
        	DatasetChrom.addValue(132085098,"Mouse","Chr8");
        	DatasetChrom.addValue(124000669,"Mouse","Chr9");
        	DatasetChrom.addValue(129959148,"Mouse","Chr10");
        	DatasetChrom.addValue(121798632,"Mouse","Chr11");
        	DatasetChrom.addValue(120463159,"Mouse","Chr12");
        	DatasetChrom.addValue(120614378,"Mouse","Chr13");
        	DatasetChrom.addValue(123978870,"Mouse","Chr14");
        	DatasetChrom.addValue(103492577,"Mouse","Chr15");
        	DatasetChrom.addValue(98252459,"Mouse","Chr16");
        	DatasetChrom.addValue(95177420,"Mouse","Chr17");
        	DatasetChrom.addValue(90736837,"Mouse","Chr18");
        	DatasetChrom.addValue(61321190,"Mouse","Chr19");
        	DatasetChrom.addValue(165556469,"Mouse","ChrX");
        	DatasetChrom.addValue(16029404,"Mouse","ChrY");
		}
        
        if (SpeciesID.equals("Mouse Aug. 2005 (NCBI35/mm7)")){//С��
        	DatasetChrom.addValue(194923535,"Mouse","Chr1");
        	DatasetChrom.addValue(182548267,"Mouse","Chr2");
        	DatasetChrom.addValue(159849039,"Mouse","Chr3");
        	DatasetChrom.addValue(155175443,"Mouse","Chr4");
        	DatasetChrom.addValue(153054177,"Mouse","Chr5");
        	DatasetChrom.addValue(149646834,"Mouse","Chr6");
        	DatasetChrom.addValue(141766352,"Mouse","Chr7");
        	DatasetChrom.addValue(127874053,"Mouse","Chr8");
        	DatasetChrom.addValue(123828236,"Mouse","Chr9");
        	DatasetChrom.addValue(130066766,"Mouse","Chr10");
        	DatasetChrom.addValue(122091587,"Mouse","Chr11");
        	DatasetChrom.addValue(117814103,"Mouse","Chr12");
        	DatasetChrom.addValue(116696528,"Mouse","Chr13");
        	DatasetChrom.addValue(119226840,"Mouse","Chr14");
        	DatasetChrom.addValue(103647385,"Mouse","Chr15");
        	DatasetChrom.addValue(98481019,"Mouse","Chr16");
        	DatasetChrom.addValue(93276925,"Mouse","Chr17");
        	DatasetChrom.addValue(90918714,"Mouse","Chr18");
        	DatasetChrom.addValue(61223509,"Mouse","Chr19");
        	DatasetChrom.addValue(164906252,"Mouse","ChrX");
        	DatasetChrom.addValue(15523453,"Mouse","ChrY");
		}
        
        if (SpeciesID.equals("Rat Nov. 2004 (Baylor 3.4/rn4)")){//����
        	DatasetChrom.addValue(267910886,"Rat","Chr1");
        	DatasetChrom.addValue(258207540,"Rat","Chr2");
        	DatasetChrom.addValue(171063335,"Rat","Chr3");
        	DatasetChrom.addValue(187126005,"Rat","Chr4");
        	DatasetChrom.addValue(173096209,"Rat","Chr5");
        	DatasetChrom.addValue(147636619,"Rat","Chr6");
        	DatasetChrom.addValue(143002779,"Rat","Chr7");
        	DatasetChrom.addValue(129041809,"Rat","Chr8");
        	DatasetChrom.addValue(113440463,"Rat","Chr9");
        	DatasetChrom.addValue(110718848,"Rat","Chr10");
        	DatasetChrom.addValue(87759784,"Rat","Chr11");
        	DatasetChrom.addValue(46782294,"Rat","Chr12");
        	DatasetChrom.addValue(111154910,"Rat","Chr13");
        	DatasetChrom.addValue(112194335,"Rat","Chr14");
        	DatasetChrom.addValue(109758846,"Rat","Chr15");
        	DatasetChrom.addValue(90238779,"Rat","Chr16");
        	DatasetChrom.addValue(97296363,"Rat","Chr17");
        	DatasetChrom.addValue(87265094,"Rat","Chr18");
        	DatasetChrom.addValue(59218465,"Rat","Chr19");
        	DatasetChrom.addValue(55268282,"Rat","Chr20");
        	DatasetChrom.addValue(160699376,"Rat","ChrX");
		}
        
        if (SpeciesID.equals("Rat June 2003 (Baylor 3.1/rn3)")){//����
        	DatasetChrom.addValue(268121971,"Rat","Chr1");
        	DatasetChrom.addValue(258222147,"Rat","Chr2");
        	DatasetChrom.addValue(170969371,"Rat","Chr3");
        	DatasetChrom.addValue(187371129,"Rat","Chr4");
        	DatasetChrom.addValue(173106704,"Rat","Chr5");
        	DatasetChrom.addValue(147642806,"Rat","Chr6");
        	DatasetChrom.addValue(143082968,"Rat","Chr7");
        	DatasetChrom.addValue(129061546,"Rat","Chr8");
        	DatasetChrom.addValue(113649943,"Rat","Chr9");
        	DatasetChrom.addValue(110733352,"Rat","Chr10");
        	DatasetChrom.addValue(87800381,"Rat","Chr11");
        	DatasetChrom.addValue(46649226,"Rat","Chr12");
        	DatasetChrom.addValue(111348958,"Rat","Chr13");
        	DatasetChrom.addValue(112220682,"Rat","Chr14");
        	DatasetChrom.addValue(109774626,"Rat","Chr15");
        	DatasetChrom.addValue(90224819,"Rat","Chr16");
        	DatasetChrom.addValue(97307196,"Rat","Chr17");
        	DatasetChrom.addValue(87338544,"Rat","Chr18");
        	DatasetChrom.addValue(59223525,"Rat","Chr19");
        	DatasetChrom.addValue(55296979,"Rat","Chr20");
        	DatasetChrom.addValue(160775580,"Rat","ChrX");
		}

        
        
        if (SpeciesID.equals("Chicken May 2006 (WUGSC 2.1/galGal3)")){//��
        	DatasetChrom.addValue(200994015,"Chicken","Chr1");
        	DatasetChrom.addValue(154873767,"Chicken","Chr2");
        	DatasetChrom.addValue(113657789,"Chicken","Chr3");
        	DatasetChrom.addValue(94230402,"Chicken","Chr4");
        	DatasetChrom.addValue(62238931,"Chicken","Chr5");
        	DatasetChrom.addValue(37400442,"Chicken","Chr6");
        	DatasetChrom.addValue(38384769,"Chicken","Chr7");
        	DatasetChrom.addValue(30671729,"Chicken","Chr8");
        	DatasetChrom.addValue(25554352,"Chicken","Chr9");
        	DatasetChrom.addValue(22556432,"Chicken","Chr10");
        	DatasetChrom.addValue(21928095,"Chicken","Chr11");
        	DatasetChrom.addValue(20536687,"Chicken","Chr12");
        	DatasetChrom.addValue(18911934,"Chicken","Chr13");
        	DatasetChrom.addValue(15819469,"Chicken","Chr14");
        	DatasetChrom.addValue(12968165,"Chicken","Chr15");
        	DatasetChrom.addValue(432983,"Chicken","Chr16");
        	DatasetChrom.addValue(11182526,"Chicken","Chr17");
        	DatasetChrom.addValue(10925261,"Chicken","Chr18");
        	DatasetChrom.addValue(9939723,"Chicken","Chr19");
        	DatasetChrom.addValue(13986235,"Chicken","Chr20");
        	DatasetChrom.addValue(6959642,"Chicken","Chr21");
        	DatasetChrom.addValue(3936574,"Chicken","Chr22");
        	DatasetChrom.addValue(6042217,"Chicken","Chr23");
        	DatasetChrom.addValue(6400109,"Chicken","Chr24");
        	DatasetChrom.addValue(2031799,"Chicken","Chr25");
        	DatasetChrom.addValue(5102438,"Chicken","Chr26");
        	DatasetChrom.addValue(4841970,"Chicken","Chr27");
        	DatasetChrom.addValue(4512026,"Chicken","Chr28");
        	DatasetChrom.addValue(1028,"Chicken","Chr32");
        	DatasetChrom.addValue(259642,"Chicken","ChrW");
        	DatasetChrom.addValue(74602320,"Chicken","ChrZ");
		}
        
        if (SpeciesID.equals("Chicken Feb. 2004 (WUGSC 1.0/galGal2)")){//��
        	DatasetChrom.addValue(188239860,"Chicken","Chr1");
        	DatasetChrom.addValue(147590765,"Chicken","Chr2");
        	DatasetChrom.addValue(108638738,"Chicken","Chr3");
        	DatasetChrom.addValue(90634903,"Chicken","Chr4");
        	DatasetChrom.addValue(56310377,"Chicken","Chr5");
        	DatasetChrom.addValue(33893787,"Chicken","Chr6");
        	DatasetChrom.addValue(37338262,"Chicken","Chr7");
        	DatasetChrom.addValue(30024636,"Chicken","Chr8");
        	DatasetChrom.addValue(23409228,"Chicken","Chr9");
        	DatasetChrom.addValue(20909726,"Chicken","Chr10");
        	DatasetChrom.addValue(19020054,"Chicken","Chr11");
        	DatasetChrom.addValue(19821895,"Chicken","Chr12");
        	DatasetChrom.addValue(17279963,"Chicken","Chr13");
        	DatasetChrom.addValue(20603938,"Chicken","Chr14");
        	DatasetChrom.addValue(12438626,"Chicken","Chr15");
        	DatasetChrom.addValue(239457,"Chicken","Chr16");
        	DatasetChrom.addValue(10632206,"Chicken","Chr17");
        	DatasetChrom.addValue(8919268,"Chicken","Chr18");
        	DatasetChrom.addValue(9463882,"Chicken","Chr19");
        	DatasetChrom.addValue(13506680,"Chicken","Chr20");
        	DatasetChrom.addValue(6202554,"Chicken","Chr21");
        	DatasetChrom.addValue(2228820,"Chicken","Chr22");
        	DatasetChrom.addValue(5666127,"Chicken","Chr23");
        	DatasetChrom.addValue(5910111,"Chicken","Chr24");
        	DatasetChrom.addValue(4255270,"Chicken","Chr26");
        	DatasetChrom.addValue(2668888,"Chicken","Chr27");
        	DatasetChrom.addValue(4731479,"Chicken","Chr28");
        	DatasetChrom.addValue(1018878,"Chicken","Chr32");
        	DatasetChrom.addValue(4916845,"Chicken","ChrW");
        	DatasetChrom.addValue(33651169,"Chicken","ChrZ");
		}
       
        if (SpeciesID.equals("Zebrafish Dec. 2008 (Zv8/danRer6)")){//��
        	DatasetChrom.addValue(59305620,"Zebrafish","Chr1");
        	DatasetChrom.addValue(58009534,"Zebrafish","Chr2");
        	DatasetChrom.addValue(60907308,"Zebrafish","Chr3");
        	DatasetChrom.addValue(71658100,"Zebrafish","Chr4");
        	DatasetChrom.addValue(74451498,"Zebrafish","Chr5");
        	DatasetChrom.addValue(61647013,"Zebrafish","Chr6");
        	DatasetChrom.addValue(76918211,"Zebrafish","Chr7");
        	DatasetChrom.addValue(55568185,"Zebrafish","Chr8");
        	DatasetChrom.addValue(54736511,"Zebrafish","Chr9");
        	DatasetChrom.addValue(43467561,"Zebrafish","Chr10");
        	DatasetChrom.addValue(44116856,"Zebrafish","Chr11");
        	DatasetChrom.addValue(46853116,"Zebrafish","Chr12");
        	DatasetChrom.addValue(50748729,"Zebrafish","Chr13");
        	DatasetChrom.addValue(52930158,"Zebrafish","Chr14");
        	DatasetChrom.addValue(47237297,"Zebrafish","Chr15");
        	DatasetChrom.addValue(51890894,"Zebrafish","Chr16");
        	DatasetChrom.addValue(49469313,"Zebrafish","Chr17");
        	DatasetChrom.addValue(49271716,"Zebrafish","Chr18");
        	DatasetChrom.addValue(48708673,"Zebrafish","Chr19");
        	DatasetChrom.addValue(51884995,"Zebrafish","Chr20");
        	DatasetChrom.addValue(47572505,"Zebrafish","Chr21");
        	DatasetChrom.addValue(41415389,"Zebrafish","Chr22");
        	DatasetChrom.addValue(44714728,"Zebrafish","Chr23");
        	DatasetChrom.addValue(40403431,"Zebrafish","Chr24");
        	DatasetChrom.addValue(38768535,"Zebrafish","Chr25");
		}
        
        if (SpeciesID.equals("Zebrafish July 2007 (Zv7/danRer5)")){//��
        	DatasetChrom.addValue(56204684,"Zebrafish","Chr1");
        	DatasetChrom.addValue(54366722,"Zebrafish","Chr2");
        	DatasetChrom.addValue(62931207,"Zebrafish","Chr3");
        	DatasetChrom.addValue(42602441,"Zebrafish","Chr4");
        	DatasetChrom.addValue(70371393,"Zebrafish","Chr5");
        	DatasetChrom.addValue(59200669,"Zebrafish","Chr6");
        	DatasetChrom.addValue(70262009,"Zebrafish","Chr7");
        	DatasetChrom.addValue(56456705,"Zebrafish","Chr8");
        	DatasetChrom.addValue(51490918,"Zebrafish","Chr9");
        	DatasetChrom.addValue(42379582,"Zebrafish","Chr10");
        	DatasetChrom.addValue(44616367,"Zebrafish","Chr11");
        	DatasetChrom.addValue(47523734,"Zebrafish","Chr12");
        	DatasetChrom.addValue(53547397,"Zebrafish","Chr13");
        	DatasetChrom.addValue(56522864,"Zebrafish","Chr14");
        	DatasetChrom.addValue(46629432,"Zebrafish","Chr15");
        	DatasetChrom.addValue(53070661,"Zebrafish","Chr16");
        	DatasetChrom.addValue(52310423,"Zebrafish","Chr17");
        	DatasetChrom.addValue(49281368,"Zebrafish","Chr18");
        	DatasetChrom.addValue(46181231,"Zebrafish","Chr19");
        	DatasetChrom.addValue(56528676,"Zebrafish","Chr20");
        	DatasetChrom.addValue(46057314,"Zebrafish","Chr21");
        	DatasetChrom.addValue(38981829,"Zebrafish","Chr22");
        	DatasetChrom.addValue(46388020,"Zebrafish","Chr23");
        	DatasetChrom.addValue(40293347,"Zebrafish","Chr24");
        	DatasetChrom.addValue(32876240,"Zebrafish","Chr25");
		}
        
        if (SpeciesID.equals("Zebrafish Mar. 2006 (Zv6/danRer4)")){//��
        	DatasetChrom.addValue(70589895,"Zebrafish","Chr1");
        	DatasetChrom.addValue(61889685,"Zebrafish","Chr2");
			DatasetChrom.addValue(77179095,"Zebrafish","Chr3");
			DatasetChrom.addValue(47249802,"Zebrafish","Chr4");
			DatasetChrom.addValue(84656180,"Zebrafish","Chr5");
			DatasetChrom.addValue(69554819,"Zebrafish","Chr6");
			DatasetChrom.addValue(87691871,"Zebrafish","Chr7");
			DatasetChrom.addValue(66798501,"Zebrafish","Chr8");
			DatasetChrom.addValue(55712184,"Zebrafish","Chr9");
			DatasetChrom.addValue(54070595,"Zebrafish","Chr10");
			DatasetChrom.addValue(52342180,"Zebrafish","Chr11");
			DatasetChrom.addValue(58719258,"Zebrafish","Chr12");
			DatasetChrom.addValue(64258675,"Zebrafish","Chr13");
			DatasetChrom.addValue(91717235,"Zebrafish","Chr14");
			DatasetChrom.addValue(57214918,"Zebrafish","Chr15");
			DatasetChrom.addValue(65489547,"Zebrafish","Chr16");
			DatasetChrom.addValue(63411520,"Zebrafish","Chr17");
			DatasetChrom.addValue(59765243,"Zebrafish","Chr18");
			DatasetChrom.addValue(51715404,"Zebrafish","Chr19");
			DatasetChrom.addValue(63653707,"Zebrafish","Chr20");
			DatasetChrom.addValue(56255777,"Zebrafish","Chr21");
			DatasetChrom.addValue(47751166,"Zebrafish","Chr22");
			DatasetChrom.addValue(53215897,"Zebrafish","Chr23");
			DatasetChrom.addValue(46081529,"Zebrafish","Chr24");
			DatasetChrom.addValue(40315040,"Zebrafish","Chr25");
		}
        
        if (SpeciesID.equals("Zebrafish May 2005 (Zv5/danRer3)")){//��
        	DatasetChrom.addValue(55805710,"Zebrafish","Chr1");
        	DatasetChrom.addValue(48216763,"Zebrafish","Chr2");
        	DatasetChrom.addValue(46936833,"Zebrafish","Chr3");
        	DatasetChrom.addValue(33808418,"Zebrafish","Chr4");
        	DatasetChrom.addValue(73302350,"Zebrafish","Chr5");
        	DatasetChrom.addValue(32358018,"Zebrafish","Chr6");
        	DatasetChrom.addValue(58062261,"Zebrafish","Chr7");
        	DatasetChrom.addValue(43834978,"Zebrafish","Chr8");
        	DatasetChrom.addValue(43373685,"Zebrafish","Chr9");
        	DatasetChrom.addValue(38401909,"Zebrafish","Chr10");
        	DatasetChrom.addValue(42743494,"Zebrafish","Chr11");
        	DatasetChrom.addValue(37038836,"Zebrafish","Chr12");
        	DatasetChrom.addValue(47719189,"Zebrafish","Chr13");
        	DatasetChrom.addValue(69208573,"Zebrafish","Chr14");
        	DatasetChrom.addValue(47009279,"Zebrafish","Chr15");
        	DatasetChrom.addValue(52484741,"Zebrafish","Chr16");
        	DatasetChrom.addValue(49766687,"Zebrafish","Chr17");
        	DatasetChrom.addValue(50308305,"Zebrafish","Chr18");
        	DatasetChrom.addValue(71278240,"Zebrafish","Chr19");
        	DatasetChrom.addValue(56731588,"Zebrafish","Chr20");
        	DatasetChrom.addValue(40779743,"Zebrafish","Chr21");
        	DatasetChrom.addValue(49148762,"Zebrafish","Chr22");
        	DatasetChrom.addValue(55418239,"Zebrafish","Chr23");
        	DatasetChrom.addValue(33833903,"Zebrafish","Chr24");
        	DatasetChrom.addValue(28799116,"Zebrafish","Chr25");
		}
        
        if (SpeciesID.equals("C. elegans May 2008 (WS190/ce6)")){//�߳�
        	DatasetChrom.addValue(15072421,"C. elegans","ChrI");
        	DatasetChrom.addValue(15279323,"C. elegans","ChrII");
        	DatasetChrom.addValue(13783681,"C. elegans","ChrIII");
        	DatasetChrom.addValue(17493785,"C. elegans","ChrIV");
        	DatasetChrom.addValue(20919568,"C. elegans","ChrV");
        	DatasetChrom.addValue(17718854,"C. elegans","ChrX");
		}
        
        if (SpeciesID.equals("C. elegans Jan. 2007 (WS170/ce4)")){//�߳�
        	DatasetChrom.addValue(15072419,"C. elegans","ChrI");
        	DatasetChrom.addValue(15279316,"C. elegans","ChrII");
        	DatasetChrom.addValue(13783681,"C. elegans","ChrIII");
        	DatasetChrom.addValue(17493784,"C. elegans","ChrIV");
        	DatasetChrom.addValue(20919398,"C. elegans","ChrV");
        	DatasetChrom.addValue(17718852,"C. elegans","ChrX");
		}
        
        if (SpeciesID.equals("C. elegans Mar. 2004 (WS120/ce2)")){//�߳�
        	DatasetChrom.addValue(15080483,"C.elegans","ChrI");
        	DatasetChrom.addValue(15279308,"C.elegans","ChrII");
        	DatasetChrom.addValue(13783313,"C.elegans","ChrIII");
        	DatasetChrom.addValue(17493791,"C.elegans","ChrIV");
        	DatasetChrom.addValue(20922231,"C.elegans","ChrV");
        	DatasetChrom.addValue(17718849,"C.elegans","ChrX");
		}
        
        if (SpeciesID.equals("S. cerevisiae June 2008 (SGD/sacCer2)")){//��ĸ
        	DatasetChrom.addValue(230208,"S. cerevisiae","ChrI");
        	DatasetChrom.addValue(813178,"S. cerevisiae","ChrII");
        	DatasetChrom.addValue(316617,"S. cerevisiae","ChrIII");
        	DatasetChrom.addValue(1531919,"S. cerevisiae","ChrIV");
        	DatasetChrom.addValue(439885,"S. cerevisiae","ChrIX");
        	DatasetChrom.addValue(576869,"S. cerevisiae","ChrV");
        	DatasetChrom.addValue(270148,"S. cerevisiae","ChrVI");
        	DatasetChrom.addValue(1090947,"S. cerevisiae","ChrVII");
        	DatasetChrom.addValue(562643,"S. cerevisiae","ChrVIII");
        	DatasetChrom.addValue(745742,"S. cerevisiae","ChrX");
        	DatasetChrom.addValue(666454,"S. cerevisiae","ChrXI");
        	DatasetChrom.addValue(1078175,"S. cerevisiae","ChrXII");
        	DatasetChrom.addValue(924429,"S. cerevisiae","ChrXIII");
        	DatasetChrom.addValue(784333,"S. cerevisiae","ChrXIV");
        	DatasetChrom.addValue(1091289,"S. cerevisiae","ChrXV");
        	DatasetChrom.addValue(948062,"S. cerevisiae","ChrXVI");
		}
        
        if (SpeciesID.equals("S. cerevisiae Oct. 2003 (SGD/sacCer1)")){//��ĸ
        	DatasetChrom.addValue(230208,"S. cerevisiae","Chr1");
        	DatasetChrom.addValue(813136,"S. cerevisiae","Chr2");
        	DatasetChrom.addValue(316613,"S. cerevisiae","Chr3");
        	DatasetChrom.addValue(1531914,"S. cerevisiae","Chr4");
        	DatasetChrom.addValue(576869,"S. cerevisiae","Chr5");
        	DatasetChrom.addValue(270148,"S. cerevisiae","Chr6");
        	DatasetChrom.addValue(1090944,"S. cerevisiae","Chr7");
        	DatasetChrom.addValue(562639,"S. cerevisiae","Chr8");
        	DatasetChrom.addValue(439885,"S. cerevisiae","Chr9");
        	DatasetChrom.addValue(745446,"S. cerevisiae","Chr10");
        	DatasetChrom.addValue(666445,"S. cerevisiae","Chr11");
        	DatasetChrom.addValue(1078173,"S. cerevisiae","Chr12");
        	DatasetChrom.addValue(924430,"S. cerevisiae","Chr13");
        	DatasetChrom.addValue(784328,"S. cerevisiae","Chr14");
        	DatasetChrom.addValue(1091285,"S. cerevisiae","Chr15");
        	DatasetChrom.addValue(948060,"S. cerevisiae","Chr16");
		}
        
		return DatasetChrom;
	}

}

