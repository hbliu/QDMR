import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

/**
 *
 * @author  __USER__
 */
public class About extends javax.swing.JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** Creates new form About */
	public About(java.awt.Frame parent, boolean modal) {
		super(parent, modal);
		Toolkit kit = Toolkit.getDefaultToolkit();
		Dimension screenSize = kit.getScreenSize(); //
		int screenWidth = screenSize.width;
		int ScreenHeight = screenSize.height;
		setLocation(screenWidth / 2 - 175, ScreenHeight / 2 - 150); //
		setTitle("About IDMRE");
		Image image = kit.getImage(getClass().getResource("/images/logo.png"));
		setIconImage(image);
		initComponents();
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jLabel1 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		jLabel4 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jLabel6 = new javax.swing.JLabel();
		jLabel7 = new javax.swing.JLabel();
		jLabel8 = new javax.swing.JLabel();
		jButton1 = new javax.swing.JButton();
		jLabel9 = new javax.swing.JLabel();
		jLabelLogo = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

		jLabel1.setFont(new java.awt.Font("Arial", 0, 12));
		jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

		jLabel2.setFont(new java.awt.Font("Arial", 0, 12));
		jLabel2.setText("v1.0");

		jLabel3.setFont(new java.awt.Font("Arial", 0, 12));
		jLabel3
				.setText("Copyright:\u00a9 Group of Computational Epigenetic Research");

		jLabel4.setFont(new java.awt.Font("Arial", 0, 12));
		jLabel4.setText("College of Bioinformatics Science and Technology");

		jLabel5.setFont(new java.awt.Font("Arial", 0, 12));
		jLabel5.setText("Harbin Medical University, China");

		jLabel6.setFont(new java.awt.Font("Arial", 0, 12));
		jLabel6.setText("Developed by: Hongbo Liu and Yan Zhang");

		jLabel7.setFont(new java.awt.Font("Arial", 0, 12));
		jLabel7.setText("Contact:  hongbo1111@yahoo.com.cn");

		jLabel8.setFont(new java.awt.Font("Arial", 0, 12));
		jLabel8.setText("For more information, please see: QDMR web site");
		jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				try {
					jLabel8MouseClicked(evt);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (URISyntaxException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			public void mouseEntered(java.awt.event.MouseEvent evt) {
				jLabel8MouseEntered(evt);
			}
		});

		jButton1.setText("Close");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		jLabel9.setFont(new java.awt.Font("Arial", 0, 12));
		jLabel9.setText("Contact:  yanyou1225@yahoo.com.cn");

		jLabelLogo.setFont(new java.awt.Font("Arial", 0, 3));
		jLabelLogo.setForeground(new java.awt.Color(0, 0, 255));
		jLabelLogo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabelLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/QDMRlogo.png"))); // NOI18N
		jLabelLogo.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				try {
					jLabelLogoMouseClicked(evt);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (URISyntaxException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			public void mouseEntered(java.awt.event.MouseEvent evt) {
				jLabelLogoMouseEntered(evt);
			}
		});

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout
				.setHorizontalGroup(layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								layout
										.createSequentialGroup()
										.addContainerGap(32, Short.MAX_VALUE)
										.addComponent(jLabel1)
										.addGap(85, 85, 85)
										.addComponent(
												jLabelLogo,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												131,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(jLabel2).addGap(92, 92,
												92))
						.addGroup(
								layout.createSequentialGroup().addGap(22, 22,
										22).addComponent(jLabel3)
										.addContainerGap(34, Short.MAX_VALUE))
						.addGroup(
								layout.createSequentialGroup().addGap(82, 82,
										82).addComponent(jLabel5)
										.addContainerGap(113, Short.MAX_VALUE))
						.addGroup(
								layout
										.createSequentialGroup()
										.addGap(60, 60, 60)
										.addGroup(
												layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(jLabel6)
														.addGroup(
																layout
																		.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.LEADING)
																		.addComponent(
																				jLabel9)
																		.addComponent(
																				jLabel7,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				216,
																				javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addContainerGap(82, Short.MAX_VALUE))
						.addGroup(
								layout
										.createSequentialGroup()
										.addGap(42, 42, 42)
										.addGroup(
												layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(jLabel8)
														.addComponent(jLabel4))
										.addContainerGap(55, Short.MAX_VALUE))
						.addGroup(
								layout.createSequentialGroup().addGap(155, 155,
										155).addComponent(jButton1)
										.addContainerGap(154, Short.MAX_VALUE)));
		layout
				.setVerticalGroup(layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								layout
										.createSequentialGroup()
										.addGroup(
												layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																layout
																		.createSequentialGroup()
																		.addGap(
																				47,
																				47,
																				47)
																		.addComponent(
																				jLabel1)
																		.addGap(
																				26,
																				26,
																				26))
														.addGroup(
																layout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addComponent(
																				jLabelLogo,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				58,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED))
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																layout
																		.createSequentialGroup()
																		.addContainerGap(
																				32,
																				Short.MAX_VALUE)
																		.addComponent(
																				jLabel2)
																		.addGap(
																				26,
																				26,
																				26)))
										.addComponent(jLabel3)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(jLabel4)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(jLabel5)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(jLabel6)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(jLabel7)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(jLabel9)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(jLabel8).addGap(18, 18,
												18).addComponent(jButton1)
										.addContainerGap()));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jLabel8MouseClicked(java.awt.event.MouseEvent evt)
			throws IOException, URISyntaxException {
		// TODO add your handling code here:
		Desktop.getDesktop()
				.browse(new URI("http://bioinfo.hrbmu.edu.cn/qdmr"));

	}

	private void jLabel8MouseEntered(java.awt.event.MouseEvent evt) {
		// TODO add your handling code here:
		jLabel8.setCursor(new Cursor(Cursor.HAND_CURSOR));
	}

	private void jLabelLogoMouseEntered(java.awt.event.MouseEvent evt) {
		// TODO add your handling code here:
		jLabelLogo.setCursor(new Cursor(Cursor.HAND_CURSOR));
	}

	private void jLabelLogoMouseClicked(java.awt.event.MouseEvent evt)
			throws IOException, URISyntaxException {
		// TODO add your handling code here:
		Desktop.getDesktop()
				.browse(new URI("http://bioinfo.hrbmu.edu.cn/qdmr"));
	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		this.dispose();
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				About dialog = new About(new javax.swing.JFrame(), true);
				dialog.addWindowListener(new java.awt.event.WindowAdapter() {
					public void windowClosing(java.awt.event.WindowEvent e) {
						System.exit(0);
					}
				});
				dialog.setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JLabel jLabel8;
	private javax.swing.JLabel jLabel9;
	private javax.swing.JLabel jLabelLogo;
	// End of variables declaration//GEN-END:variables

}