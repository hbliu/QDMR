import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

/**
 */
public class DMRThreshold extends javax.swing.JDialog {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** A return status code - returned if Cancel button has been pressed */
	public static final int RET_CANCEL = 0;
	/** A return status code - returned if OK button has been pressed */
	public static final int RET_OK = 1;
	int SDcolumnselected=7;

	/** Creates new form DMRThreshold */
	public DMRThreshold(java.awt.Frame parent, boolean modal, int SDcolumn) {
		super(parent, modal);
		Toolkit kit = Toolkit.getDefaultToolkit();
		Dimension screenSize = kit.getScreenSize(); //ȡ���û���Ļ��С��Ϣ
		int screenWidth = screenSize.width;
		setLocation(screenWidth / 2 - 400, 100); //�����������Ͻǵ�λ�ã�resizable��ѡ��
		setTitle("Predifined Threshold for DMR");
		Image image = kit.getImage(getClass().getResource("/images/logo.png"));
		SDcolumnselected=SDcolumn;  //�������еı�׼��������
		setIconImage(image);
		initComponents();
		String[] ThresholdName={"SN",
                  "SD=0.00",
                  "SD=0.01",
                  "SD=0.02",
                  "SD=0.03",
                  "SD=0.04",
                  "SD=0.05",
                  "SD=0.06",
                  "SD=0.07",
                  "SD=0.08",
                  "SD=0.09",
                  "SD=0.10",
                  "SD=0.11",
                  "SD=0.12",
                  "SD=0.13",
                  "SD=0.14",
                  "SD=0.15"};
double[][] Threshold={
	  {2,13.288,4.555,3.525,2.925,2.503,2.134,1.883,1.659,1.461,1.284,1.147,1.003,0.874,0.760,0.629,0.542},
	  {3,21.061,1.970,1.541,1.263,1.064,0.919,0.814,0.697,0.595,0.514,0.436,0.365,0.311,0.241,0.172,0.120},
	  {4,26.575,5.047,3.958,3.340,2.910,2.541,2.246,1.991,1.769,1.584,1.407,1.246,1.081,0.934,0.823,0.688},
	  {5,30.853,6.819,5.410,4.529,3.913,3.441,3.037,2.701,2.413,2.153,1.916,1.697,1.502,1.327,1.155,0.986},
	  {6,34.348,8.350,6.568,5.534,4.765,4.166,3.669,3.259,2.899,2.583,2.294,2.032,1.796,1.566,1.365,1.180},
	  {7,37.303,9.450,7.407,6.208,5.333,4.656,4.104,3.636,3.222,2.861,2.526,2.234,1.971,1.711,1.493,1.277},
	  {8,39.863,10.462,8.181,6.819,5.876,5.115,4.498,3.975,3.521,3.133,2.756,2.429,2.133,1.854,1.602,1.367},
	  {9,42.121,11.237,8.760,7.304,6.254,5.440,4.779,4.220,3.734,3.304,2.903,2.540,2.227,1.932,1.664,1.409},
	  {10,44.141,11.997,9.329,7.767,6.633,5.768,5.066,4.464,3.918,3.449,3.059,2.658,2.328,2.016,1.725,1.447},
	  {11,45.968,12.576,9.759,8.107,6.940,6.035,5.281,4.637,4.073,3.595,3.149,2.766,2.391,2.055,1.740,1.465},
	  {12,47.636,13.180,10.205,8.482,7.225,6.270,5.484,4.804,4.214,3.717,3.262,2.850,2.458,2.101,1.794,1.494},
	  {13,49.170,13.674,10.577,8.751,7.471,6.477,5.643,4.953,4.353,3.825,3.345,2.902,2.519,2.141,1.810,1.508},
	  {14,50.591,14.145,10.944,9.062,7.727,6.673,5.804,5.099,4.455,3.920,3.416,2.973,2.552,2.171,1.841,1.534},
	  {15,51.914,14.559,11.257,9.294,7.901,6.831,5.970,5.235,4.561,3.987,3.473,3.020,2.596,2.201,1.851,1.523},
	  {16,53.151,14.968,11.539,9.531,8.105,7.006,6.103,5.326,4.658,4.075,3.547,3.065,2.645,2.224,1.862,1.518},
	  {17,54.313,15.322,11.794,9.745,8.277,7.133,6.220,5.425,4.755,4.148,3.601,3.105,2.660,2.250,1.868,1.519},
	  {18,55.409,15.691,12.073,9.949,8.447,7.289,6.329,5.522,4.808,4.205,3.658,3.147,2.703,2.270,1.887,1.535},
	  {19,56.445,16.002,12.307,10.151,8.606,7.407,6.433,5.601,4.890,4.256,3.675,3.162,2.707,2.280,1.883,1.508},
	  {20,57.429,16.297,12.537,10.330,8.748,7.533,6.533,5.689,4.960,4.305,3.727,3.205,2.727,2.304,1.889,1.518},
	  {21,58.364,16.583,12.733,10.476,8.886,7.648,6.634,5.767,5.036,4.365,3.769,3.238,2.761,2.301,1.894,1.518},
	  {22,59.256,16.859,12.944,10.657,9.020,7.769,6.713,5.836,5.070,4.416,3.812,3.265,2.757,2.306,1.910,1.508},
	  {23,60.108,17.099,13.134,10.816,9.142,7.848,6.806,5.905,5.129,4.439,3.842,3.283,2.782,2.311,1.884,1.512},
	  {24,60.924,17.353,13.329,10.941,9.255,7.946,6.882,5.964,5.178,4.488,3.871,3.305,2.781,2.321,1.907,1.505},
	  {25,61.706,17.598,13.479,11.080,9.372,8.036,6.938,6.001,5.221,4.538,3.896,3.323,2.799,2.325,1.889,1.508},
	  {26,62.458,17.829,13.647,11.197,9.458,8.115,7.013,6.073,5.293,4.559,3.935,3.353,2.819,2.343,1.907,1.498},
	  {27,63.182,18.029,13.808,11.326,9.565,8.199,7.081,6.139,5.325,4.609,3.957,3.370,2.832,2.338,1.885,1.481},
	  {28,63.879,18.248,13.954,11.442,9.663,8.276,7.144,6.180,5.360,4.636,3.971,3.382,2.829,2.353,1.897,1.478},
	  {29,64.551,18.437,14.113,11.560,9.745,8.352,7.213,6.249,5.401,4.664,3.983,3.395,2.851,2.354,1.881,1.460},
	  {30,65.201,18.632,14.242,11.681,9.844,8.422,7.278,6.292,5.423,4.683,4.002,3.412,2.862,2.343,1.881,1.467},
	  {31,65.830,18.820,14.363,11.786,9.947,8.495,7.326,6.328,5.472,4.718,4.027,3.417,2.860,2.331,1.884,1.447},
	  {32,66.439,18.988,14.511,11.883,10.015,8.565,7.377,6.390,5.503,4.751,4.064,3.437,2.871,2.354,1.880,1.432},
	  {33,67.028,19.164,14.637,11.979,10.075,8.629,7.427,6.419,5.548,4.759,4.089,3.432,2.868,2.339,1.862,1.433},
	  {34,67.601,19.323,14.756,12.068,10.167,8.687,7.481,6.461,5.571,4.784,4.081,3.452,2.883,2.361,1.858,1.432},
	  {35,68.156,19.494,14.856,12.178,10.246,8.749,7.523,6.493,5.590,4.821,4.099,3.475,2.889,2.347,1.859,1.415},
	  {36,68.696,19.649,14.983,12.245,10.299,8.796,7.557,6.544,5.618,4.825,4.124,3.468,2.894,2.346,1.857,1.404},
	  {37,69.222,19.792,15.096,12.330,10.371,8.857,7.609,6.570,5.656,4.830,4.139,3.460,2.891,2.354,1.859,1.400},
	  {38,69.733,19.946,15.223,12.424,10.456,8.904,7.674,6.601,5.677,4.864,4.139,3.489,2.882,2.332,1.845,1.390},
	  {39,70.231,20.080,15.301,12.502,10.514,8.962,7.698,6.632,5.704,4.898,4.149,3.500,2.889,2.359,1.843,1.380},
	  {40,70.716,20.222,15.396,12.576,10.582,9.007,7.752,6.671,5.718,4.933,4.176,3.507,2.899,2.349,1.827,1.384},
	  {41,71.190,20.347,15.503,12.649,10.630,9.059,7.776,6.703,5.762,4.944,4.180,3.507,2.906,2.337,1.826,1.373},
	  {42,71.652,20.494,15.593,12.725,10.692,9.117,7.825,6.727,5.779,4.942,4.202,3.521,2.915,2.337,1.831,1.355},
	  {43,72.103,20.613,15.688,12.801,10.747,9.152,7.849,6.749,5.799,4.958,4.207,3.535,2.901,2.323,1.817,1.367},
	  {44,72.543,20.744,15.790,12.874,10.798,9.203,7.878,6.793,5.814,4.963,4.207,3.537,2.897,2.339,1.797,1.357},
	  {45,72.974,20.860,15.870,12.946,10.868,9.242,7.921,6.808,5.849,4.987,4.231,3.531,2.910,2.335,1.805,1.350},
	  {46,73.396,20.985,15.956,13.026,10.905,9.295,7.964,6.836,5.865,5.002,4.235,3.549,2.909,2.327,1.793,1.330},
	  {47,73.808,21.096,16.032,13.075,10.955,9.335,8.011,6.865,5.887,5.011,4.247,3.540,2.925,2.332,1.804,1.315},
	  {48,74.211,21.209,16.129,13.133,11.003,9.370,8.029,6.882,5.909,5.040,4.257,3.564,2.932,2.318,1.788,1.311},
	  {49,74.607,21.314,16.191,13.185,11.064,9.409,8.047,6.919,5.916,5.054,4.266,3.567,2.912,2.324,1.787,1.314},
	  {50,74.994,21.427,16.286,13.269,11.116,9.459,8.088,6.939,5.942,5.066,4.282,3.559,2.903,2.319,1.766,1.300},
	  {51,75.374,21.546,16.350,13.316,11.144,9.490,8.116,6.963,5.953,5.082,4.285,3.564,2.920,2.306,1.772,1.301},
	  {52,75.746,21.650,16.442,13.370,11.191,9.516,8.157,6.993,5.969,5.082,4.293,3.573,2.915,2.307,1.771,1.285},
	  {53,76.111,21.746,16.504,13.428,11.248,9.561,8.169,7.001,5.994,5.095,4.286,3.557,2.921,2.297,1.777,1.277},
	  {54,76.469,21.843,16.565,13.484,11.296,9.582,8.187,7.014,6.006,5.117,4.300,3.566,2.917,2.330,1.748,1.258},
	  {55,76.821,21.923,16.660,13.543,11.347,9.620,8.232,7.037,6.016,5.118,4.307,3.570,2.914,2.313,1.758,1.255},
	  {56,77.166,22.046,16.710,13.604,11.390,9.662,8.261,7.066,6.035,5.123,4.320,3.579,2.905,2.308,1.752,1.246},
	  {57,77.506,22.139,16.773,13.614,11.417,9.696,8.281,7.091,6.061,5.142,4.324,3.590,2.915,2.297,1.744,1.241},
	  {58,77.839,22.232,16.835,13.701,11.470,9.738,8.299,7.104,6.064,5.145,4.336,3.590,2.906,2.298,1.733,1.241},
	  {59,78.167,22.318,16.910,13.738,11.487,9.748,8.332,7.134,6.080,5.174,4.336,3.594,2.917,2.295,1.744,1.235},
	  {60,78.489,22.421,16.974,13.804,11.532,9.795,8.353,7.142,6.095,5.163,4.347,3.591,2.920,2.283,1.722,1.238},
	  {61,78.806,22.482,17.044,13.843,11.576,9.830,8.373,7.174,6.111,5.188,4.339,3.615,2.913,2.287,1.718,1.207},
	  {62,79.118,22.582,17.105,13.882,11.605,9.833,8.410,7.185,6.138,5.186,4.360,3.599,2.917,2.281,1.713,1.213},
	  {63,79.424,22.671,17.155,13.921,11.665,9.870,8.428,7.195,6.149,5.206,4.365,3.608,2.906,2.288,1.701,1.216},
	  {64,79.726,22.742,17.212,13.989,11.686,9.903,8.449,7.211,6.140,5.216,4.359,3.610,2.905,2.283,1.709,1.194},
	  {65,80.023,22.825,17.257,14.016,11.723,9.921,8.466,7.230,6.170,5.219,4.376,3.603,2.901,2.285,1.685,1.179},
	  {66,80.316,22.924,17.334,14.086,11.756,9.963,8.481,7.248,6.173,5.220,4.363,3.620,2.919,2.273,1.702,1.174},
	  {67,80.604,22.987,17.380,14.114,11.791,9.982,8.506,7.260,6.188,5.226,4.387,3.599,2.902,2.260,1.683,1.177},
	  {68,80.888,23.068,17.446,14.160,11.821,10.021,8.542,7.280,6.192,5.226,4.387,3.619,2.916,2.266,1.670,1.171},
	  {69,81.168,23.137,17.507,14.209,11.865,10.042,8.545,7.295,6.207,5.252,4.392,3.614,2.900,2.259,1.673,1.168},
	  {70,81.444,23.194,17.552,14.247,11.897,10.062,8.568,7.308,6.221,5.255,4.391,3.615,2.898,2.257,1.673,1.141},
	  {71,81.716,23.291,17.616,14.288,11.907,10.095,8.592,7.317,6.227,5.257,4.397,3.606,2.903,2.252,1.656,1.147},
	  {72,81.984,23.349,17.672,14.325,11.947,10.119,8.608,7.340,6.254,5.263,4.402,3.606,2.903,2.257,1.658,1.144},
	  {73,82.249,23.439,17.713,14.361,11.982,10.144,8.636,7.364,6.242,5.269,4.411,3.608,2.896,2.251,1.646,1.139},
	  {74,82.509,23.506,17.759,14.408,12.019,10.190,8.656,7.384,6.260,5.293,4.422,3.627,2.895,2.233,1.639,1.117},
	  {75,82.767,23.574,17.817,14.437,12.044,10.170,8.660,7.387,6.272,5.288,4.412,3.610,2.899,2.244,1.652,1.120},
	  {76,83.021,23.646,17.854,14.477,12.071,10.217,8.673,7.381,6.280,5.295,4.420,3.624,2.889,2.236,1.630,1.121},
	  {77,83.271,23.702,17.908,14.515,12.102,10.229,8.686,7.414,6.284,5.320,4.424,3.618,2.889,2.215,1.639,1.111},
	  {78,83.519,23.759,17.958,14.544,12.138,10.244,8.715,7.435,6.308,5.320,4.412,3.612,2.903,2.213,1.633,1.104},
	  {79,83.763,23.840,18.006,14.581,12.158,10.274,8.743,7.423,6.299,5.320,4.426,3.628,2.887,2.233,1.625,1.086},
	  {80,84.004,23.911,18.045,14.625,12.177,10.306,8.763,7.450,6.308,5.319,4.434,3.621,2.884,2.226,1.610,1.087},
	  {81,84.242,23.979,18.096,14.656,12.211,10.321,8.766,7.449,6.338,5.340,4.439,3.620,2.887,2.222,1.606,1.083},
	  {82,84.477,24.028,18.131,14.689,12.262,10.332,8.798,7.468,6.342,5.340,4.436,3.612,2.893,2.215,1.603,1.077},
	  {83,84.710,24.092,18.192,14.717,12.275,10.372,8.811,7.487,6.347,5.355,4.438,3.612,2.868,2.205,1.603,1.071},
	  {84,84.939,24.148,18.224,14.755,12.288,10.390,8.820,7.510,6.358,5.347,4.442,3.628,2.890,2.206,1.601,1.064},
	  {85,85.166,24.197,18.273,14.783,12.338,10.407,8.848,7.506,6.356,5.354,4.428,3.629,2.876,2.213,1.595,1.056},
	  {86,85.390,24.274,18.309,14.804,12.349,10.415,8.842,7.513,6.382,5.352,4.455,3.625,2.869,2.183,1.585,1.050},
	  {87,85.612,24.342,18.357,14.838,12.360,10.435,8.869,7.539,6.378,5.365,4.444,3.621,2.863,2.191,1.579,1.052},
	  {88,85.831,24.396,18.402,14.882,12.398,10.450,8.882,7.541,6.390,5.371,4.455,3.623,2.881,2.197,1.593,1.039},
	  {89,86.048,24.439,18.428,14.926,12.426,10.486,8.890,7.557,6.397,5.368,4.462,3.623,2.880,2.200,1.566,1.025},
	  {90,86.262,24.514,18.481,14.942,12.437,10.506,8.918,7.569,6.418,5.382,4.461,3.640,2.871,2.180,1.577,1.033},
	  {91,86.474,24.563,18.512,14.986,12.475,10.521,8.924,7.573,6.405,5.383,4.470,3.615,2.874,2.191,1.562,1.030},
	  {92,86.683,24.625,18.576,15.008,12.501,10.535,8.951,7.600,6.406,5.383,4.464,3.629,2.856,2.171,1.561,1.029},
	  {93,86.890,24.690,18.598,15.041,12.526,10.559,8.953,7.601,6.424,5.400,4.462,3.644,2.881,2.173,1.570,1.009},
	  {94,87.095,24.733,18.645,15.078,12.526,10.575,8.974,7.622,6.452,5.396,4.460,3.624,2.870,2.172,1.545,1.009},
	  {95,87.298,24.773,18.681,15.095,12.559,10.583,8.992,7.625,6.431,5.397,4.472,3.617,2.858,2.168,1.541,0.987},
	  {96,87.499,24.845,18.713,15.131,12.588,10.602,8.986,7.625,6.452,5.400,4.491,3.631,2.864,2.163,1.539,0.999},
	  {97,87.698,24.905,18.742,15.150,12.605,10.617,9.013,7.636,6.446,5.423,4.461,3.623,2.857,2.160,1.535,0.974},
	  {98,87.894,24.943,18.782,15.176,12.616,10.655,9.017,7.649,6.479,5.409,4.477,3.639,2.840,2.163,1.526,0.987},
	  {99,88.089,25.002,18.824,15.203,12.653,10.669,9.029,7.659,6.481,5.419,4.480,3.630,2.859,2.155,1.537,0.981},
	  {100,88.282,25.041,18.860,15.229,12.665,10.658,9.051,7.676,6.468,5.407,4.477,3.628,2.867,2.142,1.511,0.966}
};
		Object[][] RowData = new Object[99][17];
		for (int i = 0; i < 99; i++) {
			for (int j = 0; j < 17; j++) {
				RowData[i][j] = Threshold[i][j];
			}
		}
		jTable1.setModel(new javax.swing.table.DefaultTableModel(RowData,ThresholdName));
		for (int i = 0; i < 99; i++) {
			jTable1.setValueAt(i + 2, i, 0);
		}
		jTable1.getTableHeader().setReorderingAllowed(false); //�����еı�ͷ�����϶�
		for (int j = 0; j < 17; j++) {
			jTable1.getColumnModel().getColumn(j).setPreferredWidth(50);
		}
		
		//�̶��п�
		jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		TableColumnModel tcm = jTable1.getTableHeader().getColumnModel();
        for (int i = 0; i < tcm.getColumnCount(); i++)
        {   TableColumn tc = tcm.getColumn(i);
            if(i==0){
               tc.setPreferredWidth(30);
            }else{
            	tc.setPreferredWidth(60);
            }
            tc.setMaxWidth(70);
        }
        
        //������ż�еĲ�ͬ��ɫ,����ѡ���sd�����б�����ɫ����Ϊ��ɫ
        for (int i = 0, n = tcm.getColumnCount(); i < n; i++)
        {
            TableColumn tc = tcm.getColumn(i);
            if(i!=(SDcolumnselected+1)){
               tc.setCellRenderer(new RowRenderer());
            }else{
               tc.setCellRenderer(new RowRendererselected());
            }
        }
	}

	 /**
     * �����ڲ��࣬���ڿ��Ƶ�Ԫ����ɫ��ÿ������ɫ��䣬�����ж���Ϊ��ɫ����ɫ��
     */
    private class RowRenderer extends DefaultTableCellRenderer
    {
		private static final long serialVersionUID = -5722311005161133828L;

		public Component getTableCellRendererComponent(JTable t, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column)
        {
            //������ż�еı���ɫ�����ڴ˸�����Ҫ�����޸�
            if (row % 2 == 0)
                setBackground(Color.white);
            else
                setBackground(Color.lightGray);
            setHorizontalAlignment(JLabel.CENTER); 
            return super.getTableCellRendererComponent(t, value, isSelected,
                    hasFocus, row, column);
        }
    }
	
    /**
     * �����ڲ��࣬���ڿ��Ʊ�ѡ��Ԫ����ɫ��ÿ������ɫ��䣬�����ж���Ϊ��ɫ����ɫ��
     */
    private class RowRendererselected extends DefaultTableCellRenderer
    {
        /**
		 * 
		 */
		private static final long serialVersionUID = -5722311005161133828L;

		public Component getTableCellRendererComponent(JTable t, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column)
        {   setBackground(Color.orange);
            setHorizontalAlignment(JLabel.CENTER); 
            return super.getTableCellRendererComponent(t, value, isSelected,
                    hasFocus, row, column);
        }
    }
	
	/** @return the return status of this dialog - one of RET_OK or RET_CANCEL */
	public int getReturnStatus() {
		return returnStatus;
	}

	/** This method is called from within the constructor to
	 * initialize the form.
	 * WARNING: Do NOT modify this code. The content of this method is
	 * always regenerated by the Form Editor.
	 */
	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		okButton = new javax.swing.JButton();
		cancelButton = new javax.swing.JButton();
		jPanel3 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jScrollPane1 = new javax.swing.JScrollPane();
		jTable1 = new javax.swing.JTable();
		jPanel2 = new javax.swing.JPanel();
		jComboBox1 = new javax.swing.JComboBox();
		jPanel1 = new javax.swing.JPanel();
		jLabel3 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jLabel8 = new javax.swing.JLabel();

		addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent evt) {
				closeDialog(evt);
			}
		});

		okButton.setText("OK");
		okButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				okButtonActionPerformed(evt);
			}
		});

		cancelButton.setText("Cancel");
		cancelButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				cancelButtonActionPerformed(evt);
			}
		});

		jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

		jLabel1.setFont(new java.awt.Font("Arial", 0, 18));
		jLabel1.setText("Predifined Threshold for DMR");

		javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(
				jPanel3);
		jPanel3.setLayout(jPanel3Layout);
		jPanel3Layout.setHorizontalGroup(jPanel3Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel3Layout.createSequentialGroup().addGap(19, 19, 19)
						.addComponent(jLabel1,
								javax.swing.GroupLayout.PREFERRED_SIZE, 248,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(512, Short.MAX_VALUE)));
		jPanel3Layout.setVerticalGroup(jPanel3Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel3Layout.createSequentialGroup().addContainerGap()
						.addComponent(jLabel1).addContainerGap(
								javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE)));

		jScrollPane1.setBorder(javax.swing.BorderFactory.createTitledBorder(
				null, "Threshold Table",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
				javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Arial", 0, 12),
				new java.awt.Color(0, 0, 255)));

		jTable1.setBackground(new java.awt.Color(102, 255, 204));
		jTable1.setFont(new java.awt.Font("Arial", 0, 12));
		jTable1
				.setModel(new javax.swing.table.DefaultTableModel(
						new Object[][] { { null, null, null, null },
								{ null, null, null, null },
								{ null, null, null, null },
								{ null, null, null, null },
								{ null, null, null, null } }, new String[] {
								"Title 1", "Title 2", "Title 3", "Title 4" }));
		jTable1.setEnabled(false);
		jTable1.setSelectionBackground(new java.awt.Color(0, 153, 255));
		jScrollPane1.setViewportView(jTable1);

		jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null,
				"Redefinition of SD",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
				javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Arial", 0, 12),
				new java.awt.Color(0, 0, 255)));

		jComboBox1.setFont(new java.awt.Font("Arial", 0, 12));
		jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] {
				"SD=0.00", "SD=0.01", "SD=0.02", "SD=0.03", "SD=0.04",
				"SD=0.05", "SD=0.06", "SD=0.07", "SD=0.08", "SD=0.09",
				"SD=0.10", "SD=0.11", "SD=0.12", "SD=0.13", "SD=0.14",
				"SD=0.15" }));
		jComboBox1.setSelectedIndex(SDcolumnselected);
		jComboBox1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jComboBox1ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(
				jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel2Layout.createSequentialGroup().addContainerGap()
						.addComponent(jComboBox1, 0, 86, Short.MAX_VALUE)
						.addContainerGap()));
		jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel2Layout.createSequentialGroup().addGap(19, 19, 19)
						.addComponent(jComboBox1,
								javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(25, Short.MAX_VALUE)));

		jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null,
				"Description",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
				javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Arial", 0, 12),
				new java.awt.Color(0, 0, 255)));

		jLabel3.setFont(new java.awt.Font("Arial", 0, 12));
		jLabel3
				.setText("SN(Sample Number):  the number of samples of data imported by user");

		jLabel5.setFont(new java.awt.Font("Arial", 0, 12));
		jLabel5
				.setText("SD(Standard Deviation):  the standard deviation of probability model for DMR threshold.");

		jLabel8.setFont(new java.awt.Font("Arial", 0, 12));
		jLabel8.setText("For more information, please see: QDMR web site");
		jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				try {
					jLabel8MouseClicked(evt);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (URISyntaxException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			public void mouseEntered(java.awt.event.MouseEvent evt) {
				jLabel8MouseEntered(evt);
			}
		});

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(
																				136,
																				136,
																				136)
																		.addComponent(
																				jLabel8))
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabel5)
																						.addComponent(
																								jLabel3))))
										.addContainerGap(155, Short.MAX_VALUE)));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel1Layout
										.createSequentialGroup()
										.addComponent(jLabel3)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)
										.addComponent(
												jLabel5,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												19,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(jLabel8).addGap(119, 119,
												119)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout
				.setHorizontalGroup(layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																layout
																		.createSequentialGroup()
																		.addComponent(
																				jScrollPane1,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				783,
																				Short.MAX_VALUE)
																		.addContainerGap())
														.addGroup(
																layout
																		.createSequentialGroup()
																		.addGroup(
																				layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jPanel3,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								Short.MAX_VALUE)
																						.addGroup(
																								layout
																										.createSequentialGroup()
																										.addComponent(
																												jPanel2,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												jPanel1,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												Short.MAX_VALUE)))
																		.addContainerGap())
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																layout
																		.createSequentialGroup()
																		.addComponent(
																				okButton,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				67,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(
																				18,
																				18,
																				18)
																		.addComponent(
																				cancelButton)
																		.addGap(
																				19,
																				19,
																				19)))));

		layout.linkSize(javax.swing.SwingConstants.HORIZONTAL,
				new java.awt.Component[] { cancelButton, okButton });

		layout
				.setVerticalGroup(layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(
												jPanel3,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jScrollPane1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												253,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(
																jPanel1,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																96,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																jPanel2,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																cancelButton)
														.addComponent(okButton))
										.addContainerGap()));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jLabel8MouseEntered(java.awt.event.MouseEvent evt) {
		// TODO add your handling code here:
		jLabel8.setCursor(new Cursor(Cursor.HAND_CURSOR));
	}

	private void jLabel8MouseClicked(java.awt.event.MouseEvent evt)
			throws IOException, URISyntaxException {
		// TODO add your handling code here:
		Desktop.getDesktop()
				.browse(new URI("http://bioinfo.hrbmu.edu.cn/qdmr"));
	}

	private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		SDcolumnselected=jComboBox1.getSelectedIndex();
        //������ż�еĲ�ͬ��ɫ,����ѡ���sd�����б�����ɫ����Ϊ��ɫ
		jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		TableColumnModel tcm = jTable1.getTableHeader().getColumnModel();
        for (int i = 0, n = tcm.getColumnCount(); i < n; i++)
        {
            TableColumn tc = tcm.getColumn(i);
            if(i!=(SDcolumnselected+1)){
               tc.setCellRenderer(new RowRenderer());
            }else{
               tc.setCellRenderer(new RowRendererselected());
            }
        }
	}

	private void okButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okButtonActionPerformed
		doClose(RET_OK);
	}//GEN-LAST:event_okButtonActionPerformed
	
	
	private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
		doClose(RET_CANCEL);
	}//GEN-LAST:event_cancelButtonActionPerformed

	/** Closes the dialog */
	private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
		doClose(RET_CANCEL);
	}//GEN-LAST:event_closeDialog

	private void doClose(int retStatus) {
		returnStatus = retStatus;
		setVisible(false);
		dispose();
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				DMRThreshold dialog = new DMRThreshold(
						new javax.swing.JFrame(), true, 8);
				dialog.addWindowListener(new java.awt.event.WindowAdapter() {
					public void windowClosing(java.awt.event.WindowEvent e) {
						System.exit(0);
					}
				});
				dialog.setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	javax.swing.JButton cancelButton;
	private javax.swing.JComboBox jComboBox1;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel8;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JPanel jPanel3;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JTable jTable1;
	javax.swing.JButton okButton;
    
	// End of variables declaration//GEN-END:variables

	private int returnStatus = RET_CANCEL;
	
}