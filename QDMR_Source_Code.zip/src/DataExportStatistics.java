import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;


public class DataExportStatistics {
      public DataExportStatistics(JLabel jLabelSampleNuma,JLabel jLabelThreDMR,JLabel jLabelDMRNum,JLabel jLabelDMRNum1,JLabel jLabelNDMRNum,JLabel jLabelNDMRNum1,String FileNameAuto) throws IOException{
    	JFileChooser chooser = new JFileChooser();
  		FileFilter filter1 = new FileNameExtensionFilter(".txt", "txt");
  		FileFilter filter2 = new FileNameExtensionFilter(".xls", "xls");
  		chooser.addChoosableFileFilter(filter2);
  		chooser.addChoosableFileFilter(filter1);
  		chooser.setSelectedFile(new File(FileNameAuto));  //����Ĭ�ϵ��ļ���
  		int result=chooser.showSaveDialog(chooser);
  		if(result==JFileChooser.APPROVE_OPTION){
  		String FileName = chooser.getSelectedFile().getAbsolutePath().trim();  //��ȡ��ַ
  		String houzhui=chooser.getFileFilter().getDescription(); //��ȡ��׺
  		FileWriter out = new FileWriter(FileName+houzhui);       //�������
  		out.write("The Number of Samples is :\t"+jLabelSampleNuma.getText()+"\n");
  		out.write("The Threshold for DMR is :\t"+jLabelThreDMR.getText()+"\n");
  		out.write("The Number of DMRs is :\t"+jLabelDMRNum.getText()+jLabelDMRNum1.getText()+"\n");
  		out.write("The Number of N-DMRs is :\t"+jLabelNDMRNum.getText()+jLabelNDMRNum1.getText()+"\n");
  		out.close();
  	    QDMR.ProgressBar(100);
  	    JOptionPane.showMessageDialog(null, "Data export is successful!");
  		  }
      }
}
