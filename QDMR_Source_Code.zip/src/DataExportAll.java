import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;


public class DataExportAll {
	String FileNameSelected=null;
	int fudu=0;
	int jindu=0;
    public DataExportAll(JTable EntropyDataTable,JTable jTableDMR,JTable jTableNDMR,JTable jTableSpecificity,JLabel jLabelSampleNuma,JLabel jLabelThreDMR,JLabel jLabelDMRNum,JLabel jLabelDMRNum1,JLabel jLabelNDMRNum,JLabel jLabelNDMRNum1)throws Exception{
    	fudu=EntropyDataTable.getRowCount()/50;
    	if (fudu<1) fudu=1;
    	JFileChooser chooser = new JFileChooser();
		FileFilter filter1 = new FileNameExtensionFilter(".txt", "txt");
		FileFilter filter2 = new FileNameExtensionFilter(".xls", "xls");
		chooser.addChoosableFileFilter(filter2);
		chooser.addChoosableFileFilter(filter1);
		chooser.setSelectedFile(new File("QDMR"));  //����Ĭ�ϵ��ļ���
		
		int result=chooser.showSaveDialog(chooser);
		if(result==JFileChooser.APPROVE_OPTION){
		FileNameSelected = chooser.getSelectedFile().getAbsolutePath().trim();  //��ȡ��ַ
		
		File dirFile=new File(FileNameSelected);
        boolean bFile = dirFile.mkdir();
		String houzhui=chooser.getFileFilter().getDescription(); //��ȡ��׺
		if(bFile){
		
		Export(EntropyDataTable,"\\EntropyTable"+houzhui);
		
		if(Integer.parseInt(jLabelDMRNum.getText())>0){
		Export(jTableDMR,"\\DMRTable"+houzhui);
		Export(jTableSpecificity,"\\SpecificityTable"+houzhui);   //������ļ�����
		}
		
		if(Integer.parseInt(jLabelNDMRNum.getText())>0){
		Export(jTableNDMR,"\\N-DMRTable"+houzhui);
		}
		
		ExportStatistics(jLabelSampleNuma,jLabelThreDMR,jLabelDMRNum,jLabelDMRNum1,jLabelNDMRNum,jLabelNDMRNum1,"\\Statistics"+houzhui);
		QDMR.ProgressBar(100);
	    JOptionPane.showMessageDialog(null, "Data export is successful!");
		}
		}
	}
    /**
     * 
     * @param ��ĳ�����ݱ��е�����������ļ�����   
     */
    public void Export(JTable DataTable,String FileName)throws IOException{
    	FileWriter out = new FileWriter(FileNameSelected+FileName);       //�������
    	for (int i = 0; i < DataTable.getColumnCount(); i++) {
			    out.write(DataTable.getColumnName(i) + "\t");
			   }
			   out.write("\n");
	    
	    for (int i = 0; i < DataTable.getRowCount(); i++) {
			for (int j = 0; j < DataTable.getColumnCount(); j++) {
			     out.write(DataTable.getValueAt(i, j).toString() + "\t");
			    }
			    out.write("\n");
			    jindu++;
			    QDMR.ProgressBar(jindu/fudu);  //��������Ľ���
			   }
	   out.close();
    }
    
        private void ExportStatistics(JLabel jLabelSampleNuma,JLabel jLabelThreDMR,JLabel jLabelDMRNum,JLabel jLabelDMRNum1,JLabel jLabelNDMRNum,JLabel jLabelNDMRNum1,String FileName) throws IOException{
        	FileWriter out = new FileWriter(FileNameSelected+FileName);       //�������
        	out.write("The Number of Samples is :\t"+jLabelSampleNuma.getText()+"\n");
      		out.write("The Threshold for DMR is :\t"+jLabelThreDMR.getText()+"\n");
      		out.write("The Number of DMRs is :\t"+jLabelDMRNum.getText()+jLabelDMRNum1.getText()+"\n");
      		out.write("The Number of N-DMRs is :\t"+jLabelNDMRNum.getText()+jLabelNDMRNum1.getText()+"\n");
      		out.close();
        }
    /**
     * ɾ���ļ����ļ���
     * @param path ��Ҫɾ�����ļ�|�ļ���      
     */
     public void RemoveFile(File path){
        System.out.println("removing file " + path.getPath());
        if (path.isDirectory()){
            File[] child = path.listFiles();
            if (child != null && child.length != 0){
                for (int i = 0; i < child.length; i++){
                    RemoveFile(child[i]);
                    child[i].delete();
                }
            }
        }
        path.delete();
    }
}
