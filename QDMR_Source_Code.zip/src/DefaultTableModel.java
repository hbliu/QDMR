
public class DefaultTableModel {
public DefaultTableModel(){
	
}
}
