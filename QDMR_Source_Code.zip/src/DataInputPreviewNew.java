import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author  __USER__
 */
public class DataInputPreviewNew extends javax.swing.JDialog {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** A return status code - returned if Cancel button has been pressed */
	public static final int RET_CANCEL = 0;
	/** A return status code - returned if OK button has been pressed */
	public static final int RET_OK = 1;
	String InputfilePath = null; //�����������ݵľ���·��
	String InputFileName = null;
	String Separator = "\t|\\s+\t|\t\\s+|\\s+"; //Ԥ����ָ���
	int ColumnNum = 0; //�û���������
	public boolean FirstLineIsColumnName = true; //�û�ѡ���һ��Ϊ����ֵ,Ĭ�ϲ�ѡ
	double MaxMethylationLevel = 100; //��¼�û�ѡ��ļ׻������ֵ
	int SampleStartColumn = 5; //��¼�û����������׻������ݿ�ʼ���У�Ĭ��Ϊ������
	int SpeciesNum = 1; //���֣�Ĭ��ѡ��ڶ���hg18����ʼΪ0��
	int ChromsomeColumn = 1; //Ⱦɫ���У�Ĭ��ѡ��ڶ��У���ʼΪ0��
	int RegionStartColumn = 2; //��ʼλ�㣺Ĭ��ѡ������У���ʼΪ0��
	int RegionEndColumn = 3; //��ֹλ�㣺Ĭ��ѡ������У���ʼΪ0��

	/** Creates new form DataInputPreviewNew */
	public DataInputPreviewNew(java.awt.Frame parent, boolean modal) {
		super(parent, modal);
		Toolkit kit = Toolkit.getDefaultToolkit();
		Dimension screenSize = kit.getScreenSize(); //ȡ���û���Ļ��С��Ϣ
		int screenWidth = screenSize.width;
		setLocation(screenWidth / 2 - 350, 50); //�����������Ͻǵ�λ�ã�resizable��ѡ��
		setTitle("Input Methylation Data of All Regions in All Samples");
		Image image = kit.getImage(getClass().getResource("/images/logo.png"));
		setIconImage(image);
		initComponents();
		okButton.setEnabled(false);
	}

	/** @return the return status of this dialog - one of RET_OK or RET_CANCEL */
	public int getReturnStatus() {
		return returnStatus;
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		okButton = new javax.swing.JButton();
		cancelButton = new javax.swing.JButton();
		jPanel1 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jPanel2 = new javax.swing.JPanel();
		DataFileLocation = new javax.swing.JTextField();
		DataFileBrowser = new javax.swing.JButton();
		jLabel2 = new javax.swing.JLabel();
		jPanel3 = new javax.swing.JPanel();
		jPanel4 = new javax.swing.JPanel();
		jLabelspecies = new javax.swing.JLabel();
		jComboBoxspecies = new javax.swing.JComboBox();
		jLabelchrom = new javax.swing.JLabel();
		jComboBoxchrom = new javax.swing.JComboBox();
		jLabelstart = new javax.swing.JLabel();
		jComboBoxstart = new javax.swing.JComboBox();
		jLabelend = new javax.swing.JLabel();
		jComboBoxend = new javax.swing.JComboBox();
		jTabbedPane1 = new javax.swing.JTabbedPane();
		jScrollPane1 = new javax.swing.JScrollPane();
		DataInputPreviewPanle = new javax.swing.JTable();
		jScrollPane2 = new javax.swing.JScrollPane();
		OperationGuide = new javax.swing.JTextArea();
		jPanel5 = new javax.swing.JPanel();
		ExempleData1 = new javax.swing.JButton();
		ExempleData2 = new javax.swing.JButton();
		jPanel6 = new javax.swing.JPanel();
		jPanel7 = new javax.swing.JPanel();
		jLabel6 = new javax.swing.JLabel();
		jRadioButton0to1 = new javax.swing.JRadioButton();
		jRadioButton0to100 = new javax.swing.JRadioButton();
		jLabelstart1 = new javax.swing.JLabel();
		jSpinnerSampleStart = new javax.swing.JSpinner();
		CheckBoxColumnNames = new javax.swing.JCheckBox();
		CheckBoxneedadvance = new javax.swing.JCheckBox();

		addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent evt) {
				closeDialog(evt);
			}
		});

		okButton.setText("Import");
		okButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				okButtonActionPerformed(evt);
			}
		});

		cancelButton.setText("Cancel");
		cancelButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				cancelButtonActionPerformed(evt);
			}
		});

		jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
		jPanel1.setFont(new java.awt.Font("Arial", 0, 12));

		jLabel1.setFont(new java.awt.Font("Arial", 0, 20));
		jLabel1.setForeground(new java.awt.Color(0, 0, 255));
		jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/Import.png"))); // NOI18N
		jLabel1.setText("Import Methylation Data from Txt File");

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel1Layout.createSequentialGroup().addComponent(jLabel1,
						javax.swing.GroupLayout.PREFERRED_SIZE, 505,
						javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(212, Short.MAX_VALUE)));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jLabel1, javax.swing.GroupLayout.Alignment.TRAILING,
				javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null,
				"Data Sourcees", javax.swing.border.TitledBorder.LEFT,
				javax.swing.border.TitledBorder.TOP, new java.awt.Font("Arial",
						1, 12), new java.awt.Color(0, 0, 255)));
		jPanel2.setFont(new java.awt.Font("Arial", 0, 12));
		jPanel2.setName("Data File");
		jPanel2.setOpaque(false);

		DataFileLocation.setFont(new java.awt.Font("Arial", 0, 12));
		DataFileLocation.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyPressed(java.awt.event.KeyEvent evt) {
				try {
					DataFileLocationKeyPressed(evt);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		DataFileBrowser.setFont(new java.awt.Font("Arial", 1, 12));
		DataFileBrowser.setText("Browser");
		DataFileBrowser.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				try {
					DataFileBrowserMouseClicked(evt);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		jLabel2.setFont(new java.awt.Font("Arial", 1, 12));
		jLabel2.setText("Input File");

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(
				jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout
				.setHorizontalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(jLabel2)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(
												DataFileLocation,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												321,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												DataFileBrowser,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												107,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap(25, Short.MAX_VALUE)));
		jPanel2Layout
				.setVerticalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																DataFileBrowser,
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				19,
																				19,
																				19)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jLabel2)
																						.addComponent(
																								DataFileLocation,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.PREFERRED_SIZE))))
										.addContainerGap(20, Short.MAX_VALUE)));

		jPanel3
				.setBorder(javax.swing.BorderFactory
						.createTitledBorder(
								javax.swing.BorderFactory
										.createBevelBorder(javax.swing.border.BevelBorder.RAISED),
								"Advanced",
								javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
								javax.swing.border.TitledBorder.DEFAULT_POSITION,
								new java.awt.Font("Arial", 1, 12),
								new java.awt.Color(0, 0, 255)));

		jPanel4.setEnabled(false);

		jLabelspecies.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelspecies.setText("Species");

		jComboBoxspecies.setFont(new java.awt.Font("Arial", 0, 12));
		jComboBoxspecies.setModel(new javax.swing.DefaultComboBoxModel(
				new String[] { "Human Feb. 2009 (GRCh37/hg19)",
						"Human Mar. 2006 (NCBI36/hg18)",
						"Human May 2004 (NCBI35/hg17)",
						"Human July 2003 (NCBI34/hg16)",
						"Mouse July 2007 (NCBI37/mm9)",
						"Mouse Feb. 2006 (NCBI36/mm8)",
						"Mouse Aug. 2005 (NCBI35/mm7)",
						"Rat Nov. 2004 (Baylor3.4/rn4)",
						"Rat June 2003 (Baylor3.1/rn3)",
						"Chicken May 2006 (WUGSC2.1/galGal3)",
						"Chicken Feb. 2004 (WUGSC1.0/galGal2)",
						"Zebrafish Dec. 2008 (Zv8/danRer6)",
						"Zebrafish July 2007 (Zv7/danRer5)",
						"Zebrafish Mar. 2006 (Zv6/danRer4)",
						"Zebrafish May 2005 (Zv5/danRer3)",
						"C.+elegans May 2008 (WS190/ce6)",
						"C.+elegans Jan. 2007 (WS170/ce4)",
						"C.+elegans Mar. 2004 (WS120/ce2)",
						"S.+cerevisiae June 2008 (SGD/sacCer2)",
						"S.+cerevisiae Oct. 2003 (SGD/sacCer1)" }));
		jComboBoxspecies.setSelectedIndex(1);
		jComboBoxspecies.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jComboBoxspeciesActionPerformed(evt);
			}
		});

		jLabelchrom.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelchrom.setText("Chromsome Column");

		jComboBoxchrom.setFont(new java.awt.Font("Arial", 0, 12));
		jComboBoxchrom
				.setModel(new javax.swing.DefaultComboBoxModel(new String[] {
						"Column 1", "Column 2", "Column 3", "Column 4" }));
		jComboBoxchrom.setSelectedIndex(1);
		jComboBoxchrom.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jComboBoxchromActionPerformed(evt);
			}
		});

		jLabelstart.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelstart.setText("Region Start Column");

		jComboBoxstart.setFont(new java.awt.Font("Arial", 0, 12));
		jComboBoxstart
				.setModel(new javax.swing.DefaultComboBoxModel(new String[] {
						"Column 1", "Column 2", "Column 3", "Column 4" }));
		jComboBoxstart.setSelectedIndex(2);
		jComboBoxstart.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jComboBoxstartActionPerformed(evt);
			}
		});

		jLabelend.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelend.setText("Region  End Column");

		jComboBoxend.setFont(new java.awt.Font("Arial", 0, 12));
		jComboBoxend
				.setModel(new javax.swing.DefaultComboBoxModel(new String[] {
						"Column 1", "Column 2", "Column 3", "Column 4" }));
		jComboBoxend.setSelectedIndex(3);
		jComboBoxend.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jComboBoxendActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(
				jPanel4);
		jPanel4.setLayout(jPanel4Layout);
		jPanel4Layout
				.setHorizontalGroup(jPanel4Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel4Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addGroup(
																javax.swing.GroupLayout.Alignment.LEADING,
																jPanel4Layout
																		.createSequentialGroup()
																		.addComponent(
																				jLabelspecies)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jComboBoxspecies,
																				0,
																				224,
																				Short.MAX_VALUE))
														.addGroup(
																javax.swing.GroupLayout.Alignment.LEADING,
																jPanel4Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel4Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING)
																						.addComponent(
																								jLabelend)
																						.addComponent(
																								jLabelstart)
																						.addComponent(
																								jLabelchrom))
																		.addGap(
																				18,
																				18,
																				18)
																		.addGroup(
																				jPanel4Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jComboBoxend,
																								0,
																								138,
																								Short.MAX_VALUE)
																						.addComponent(
																								jComboBoxstart,
																								0,
																								138,
																								Short.MAX_VALUE)
																						.addComponent(
																								jComboBoxchrom,
																								0,
																								138,
																								Short.MAX_VALUE))))
										.addContainerGap()));
		jPanel4Layout
				.setVerticalGroup(jPanel4Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel4Layout
										.createSequentialGroup()
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jLabelspecies)
														.addComponent(
																jComboBoxspecies,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jLabelchrom)
														.addComponent(
																jComboBoxchrom,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																17,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jLabelstart)
														.addComponent(
																jComboBoxstart,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																17,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabelend)
														.addComponent(
																jComboBoxend,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																17,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addContainerGap()));

		javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(
				jPanel3);
		jPanel3.setLayout(jPanel3Layout);
		jPanel3Layout.setHorizontalGroup(jPanel3Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel3Layout.createSequentialGroup().addGap(28, 28, 28)
						.addComponent(jPanel4,
								javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(22, Short.MAX_VALUE)));
		jPanel3Layout.setVerticalGroup(jPanel3Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.PREFERRED_SIZE));

		jTabbedPane1.setBorder(javax.swing.BorderFactory.createTitledBorder(
				javax.swing.BorderFactory.createEtchedBorder(
						new java.awt.Color(0, 153, 255), null), "Data Preview",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
				javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Arial", 1, 12),
				new java.awt.Color(0, 0, 255)));
		jTabbedPane1.setFont(new java.awt.Font("Arial", 0, 12));

		jScrollPane1.setFont(new java.awt.Font("Arial", 0, 12));

		DataInputPreviewPanle.setFont(new java.awt.Font("Arial", 0, 12));
		DataInputPreviewPanle
				.setModel(new javax.swing.table.DefaultTableModel(
						new Object[][] {
								{ null, null, null, null, null, null, null,
										null },
								{ null, null, null, null, null, null, null,
										null },
								{ null, null, null, null, null, null, null,
										null },
								{ null, null, null, null, null, null, null,
										null },
								{ null, null, null, null, null, null, null,
										null },
								{ null, null, null, null, null, null, null,
										null } }, new String[] { "RegionID",
								"Chromosome", "RegionStart", "RegionEnd",
								"Sample1", "Sample2", "Sample3", "More..." }));
		DataInputPreviewPanle.getTableHeader().setReorderingAllowed(false);
		jScrollPane1.setViewportView(DataInputPreviewPanle);

		jTabbedPane1.addTab("Data File Preview Window", jScrollPane1);

		jScrollPane2.setBorder(javax.swing.BorderFactory.createTitledBorder(
				null, "Operation Guide",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
				javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Arial", 1, 12),
				new java.awt.Color(0, 0, 204)));

		OperationGuide.setColumns(20);
		OperationGuide.setEditable(false);
		OperationGuide.setFont(new java.awt.Font("Arial", 0, 12));
		OperationGuide.setLineWrap(true);
		OperationGuide.setRows(5);
		OperationGuide.setTabSize(2);
		OperationGuide
				.setText("Import Methylation Data from Txt File\ni There are two ways to get your data file:\n     1.Input or paste the Absolute Path of the data file in the text field of \"Input File\".\n     2.Click the \"Browser\" button to select the data file.\nii Important Notices:\n     1.It is suggested to refer the exemple data by click the \"Exemple Data 1 or 2\" button before import your own data.\n     2.Information about the regions of interest should be before the methylation data for the region. \n     3.You can tune the start column of methylation data.\n     4.Select the Check Box named \"Transfer first row as column names\" if you want column names as your first row.\n     5.Column names will be generated automatically if you don't check the box named \"Transfer first row as column names\".\n     6.Be sure that methylation value should be in the rage of 0 to max value(1 or 100) according to your methylation data.\n     7.You must ensure that there are no missing values in your data.\n     6.The first 20 rows of data will be shown in the data file preview window as any change take places.");
		OperationGuide.setCaretPosition(0);
		jScrollPane2.setViewportView(OperationGuide);

		jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null,
				"Example Data", javax.swing.border.TitledBorder.LEFT,
				javax.swing.border.TitledBorder.TOP, new java.awt.Font("Arial",
						1, 12), new java.awt.Color(0, 0, 255)));
		jPanel5.setFont(new java.awt.Font("Arial", 0, 12));
		jPanel5.setName("Data File");
		jPanel5.setOpaque(false);

		ExempleData1.setFont(new java.awt.Font("Arial", 1, 12));
		ExempleData1.setText("Example Data 1");
		ExempleData1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				try {
					ExempleData1ActionPerformed(evt);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		ExempleData2.setFont(new java.awt.Font("Arial", 1, 12));
		ExempleData2.setText("Example Data 2");
		ExempleData2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				try {
					ExempleData2ActionPerformed(evt);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(
				jPanel5);
		jPanel5.setLayout(jPanel5Layout);
		jPanel5Layout
				.setHorizontalGroup(jPanel5Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel5Layout
										.createSequentialGroup()
										.addContainerGap(11, Short.MAX_VALUE)
										.addGroup(
												jPanel5Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																ExempleData1,
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(
																ExempleData2,
																javax.swing.GroupLayout.Alignment.TRAILING))
										.addContainerGap()));
		jPanel5Layout
				.setVerticalGroup(jPanel5Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel5Layout
										.createSequentialGroup()
										.addComponent(ExempleData1)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(ExempleData2)));

		jPanel6
				.setBorder(javax.swing.BorderFactory
						.createTitledBorder(
								javax.swing.BorderFactory
										.createBevelBorder(javax.swing.border.BevelBorder.RAISED),
								"Data Definition",
								javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
								javax.swing.border.TitledBorder.DEFAULT_POSITION,
								new java.awt.Font("Arial", 1, 12),
								new java.awt.Color(0, 0, 255)));
		jPanel6.setFont(new java.awt.Font("Arial", 0, 12));

		jLabel6.setFont(new java.awt.Font("Arial", 0, 12));
		jLabel6.setText("Methylation levle ranges from 0 to");

		jRadioButton0to1.setFont(new java.awt.Font("Arial", 0, 12));
		jRadioButton0to1.setText("1");
		jRadioButton0to1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				try {
					jRadioButton0to1ActionPerformed(evt);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		jRadioButton0to100.setFont(new java.awt.Font("Arial", 0, 12));
		jRadioButton0to100.setSelected(true);
		jRadioButton0to100.setText("100");
		jRadioButton0to100
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						try {
							jRadioButton0to100ActionPerformed(evt);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});

		jLabelstart1.setFont(new java.awt.Font("Arial", 0, 12));
		jLabelstart1.setText("Sample Start Column");

		jSpinnerSampleStart.setFont(new java.awt.Font("Arial", 0, 12));
		jSpinnerSampleStart.setModel(new javax.swing.SpinnerNumberModel(5, 1,
				110, 1));
		jSpinnerSampleStart
				.addChangeListener(new javax.swing.event.ChangeListener() {
					public void stateChanged(javax.swing.event.ChangeEvent evt) {
						try {
							jSpinnerSampleStartStateChanged(evt);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});

		CheckBoxColumnNames.setFont(new java.awt.Font("Arial", 0, 12));
		CheckBoxColumnNames.setSelected(true);
		CheckBoxColumnNames.setText("Transfer first line as column names");
		CheckBoxColumnNames
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						try {
							CheckBoxColumnNamesActionPerformed(evt);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});

		CheckBoxneedadvance.setFont(new java.awt.Font("Arial", 0, 12));
		CheckBoxneedadvance.setSelected(true);
		CheckBoxneedadvance.setText("Need advanced definition");
		CheckBoxneedadvance
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						CheckBoxneedadvanceActionPerformed(evt);
					}
				});

		javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(
				jPanel7);
		jPanel7.setLayout(jPanel7Layout);
		jPanel7Layout
				.setHorizontalGroup(jPanel7Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel7Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel7Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																CheckBoxneedadvance)
														.addGroup(
																jPanel7Layout
																		.createSequentialGroup()
																		.addComponent(
																				jLabel6)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jRadioButton0to1)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																		.addComponent(
																				jRadioButton0to100))
														.addComponent(
																CheckBoxColumnNames)
														.addGroup(
																jPanel7Layout
																		.createSequentialGroup()
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jLabelstart1,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				139,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																		.addComponent(
																				jSpinnerSampleStart,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addContainerGap(28, Short.MAX_VALUE)));
		jPanel7Layout
				.setVerticalGroup(jPanel7Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel7Layout
										.createSequentialGroup()
										.addGroup(
												jPanel7Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel6)
														.addComponent(
																jRadioButton0to100)
														.addComponent(
																jRadioButton0to1))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel7Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																jLabelstart1)
														.addComponent(
																jSpinnerSampleStart,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																18,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(CheckBoxColumnNames)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE).addComponent(
												CheckBoxneedadvance)));

		javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(
				jPanel6);
		jPanel6.setLayout(jPanel6Layout);
		jPanel6Layout.setHorizontalGroup(jPanel6Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel6Layout.createSequentialGroup().addGap(30, 30, 30)
						.addComponent(jPanel7,
								javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE)));
		jPanel6Layout.setVerticalGroup(jPanel6Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel6Layout.createSequentialGroup().addComponent(jPanel7,
						javax.swing.GroupLayout.PREFERRED_SIZE,
						javax.swing.GroupLayout.DEFAULT_SIZE,
						javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout
				.setHorizontalGroup(layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																layout
																		.createSequentialGroup()
																		.addComponent(
																				okButton,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				67,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																		.addComponent(
																				cancelButton)
																		.addGap(
																				52,
																				52,
																				52))
														.addGroup(
																layout
																		.createSequentialGroup()
																		.addGroup(
																				layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING)
																						.addComponent(
																								jPanel1,
																								javax.swing.GroupLayout.Alignment.LEADING,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								Short.MAX_VALUE)
																						.addGroup(
																								layout
																										.createSequentialGroup()
																										.addComponent(
																												jPanel6,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																												12,
																												Short.MAX_VALUE)
																										.addComponent(
																												jPanel3,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.PREFERRED_SIZE))
																						.addGroup(
																								javax.swing.GroupLayout.Alignment.LEADING,
																								layout
																										.createSequentialGroup()
																										.addComponent(
																												jPanel2,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addGap(
																												18,
																												18,
																												18)
																										.addComponent(
																												jPanel5,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.PREFERRED_SIZE)))
																		.addContainerGap(
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				Short.MAX_VALUE))
														.addGroup(
																layout
																		.createSequentialGroup()
																		.addComponent(
																				jTabbedPane1,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				721,
																				Short.MAX_VALUE)
																		.addContainerGap())
														.addGroup(
																layout
																		.createSequentialGroup()
																		.addComponent(
																				jScrollPane2,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				721,
																				Short.MAX_VALUE)
																		.addContainerGap()))));

		layout.linkSize(javax.swing.SwingConstants.HORIZONTAL,
				new java.awt.Component[] { cancelButton, okButton });

		layout
				.setVerticalGroup(layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								layout
										.createSequentialGroup()
										.addComponent(
												jPanel1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING,
																false)
														.addComponent(
																jPanel2,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																Short.MAX_VALUE)
														.addComponent(
																jPanel5,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																91,
																Short.MAX_VALUE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING,
																false)
														.addComponent(
																jPanel6,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																Short.MAX_VALUE)
														.addComponent(
																jPanel3,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																128,
																Short.MAX_VALUE))
										.addGap(4, 4, 4)
										.addComponent(
												jTabbedPane1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												168,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jScrollPane2,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												102,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(okButton)
														.addComponent(
																cancelButton))
										.addContainerGap(
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jComboBoxendActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		RegionEndColumn = jComboBoxend.getSelectedIndex(); //����������ֹλ����
	}

	private void jComboBoxstartActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		RegionStartColumn = jComboBoxstart.getSelectedIndex(); //����������ʼλ����
	}

	private void jComboBoxchromActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		ChromsomeColumn = jComboBoxchrom.getSelectedIndex(); //��������Ⱦɫ����
	}

	private void jComboBoxspeciesActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		SpeciesNum = jComboBoxspecies.getSelectedIndex(); //����������
	}

	private void CheckBoxneedadvanceActionPerformed(
			java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		if (CheckBoxneedadvance.isSelected()) {
			jComboBoxspecies.setEnabled(true);
			jComboBoxchrom.setEnabled(true);
			jComboBoxstart.setEnabled(true);
			jComboBoxend.setEnabled(true);
			if (SampleStartColumn <= 3) { //����Ϣ��С��3��ʱ������չ��Ϣ����Ϊ�����ã���������ʾ
				jComboBoxspecies.setEnabled(false);
				jComboBoxchrom.setEnabled(false);
				jComboBoxstart.setEnabled(false);
				jComboBoxend.setEnabled(false);
				CheckBoxneedadvance.setSelected(false);
				JOptionPane
						.showMessageDialog(
								this,
								"No enough information columns."
										+ "\n"
										+ "Please try add information of region locations!!",
								"Warning", JOptionPane.WARNING_MESSAGE);
			}
		} else {
			jComboBoxspecies.setEnabled(false);
			jComboBoxchrom.setEnabled(false);
			jComboBoxstart.setEnabled(false);
			jComboBoxend.setEnabled(false);
		}

	}

	private void ExempleData2ActionPerformed(java.awt.event.ActionEvent evt)
			throws Exception {
		// TODO add your handling code here:
		InputfilePath = "/data/Example_Rakyan_Dataset.txt"; //�����������ݴ����Jar���еĵ�ַ
		MaxMethylationLevel = 100;
		jRadioButton0to100.setSelected(true);
		jRadioButton0to1.setSelected(false);
		DataInputProcess(InputfilePath); //��������Ԥ������������ȡǰN�����ݣ��������ݽṹ
	}

	private void ExempleData1ActionPerformed(java.awt.event.ActionEvent evt)
			throws Exception {
		// TODO add your handling code here:
		InputfilePath = "/data/Example_HEP_Dataset.txt"; //�����������ݴ����Jar���еĵ�ַ
		MaxMethylationLevel = 100;
		jRadioButton0to100.setSelected(true);
		jRadioButton0to1.setSelected(false);
		DataInputProcess(InputfilePath); //��������Ԥ������������ȡǰN�����ݣ��������ݽṹ
	}

	private void jSpinnerSampleStartStateChanged(
			javax.swing.event.ChangeEvent evt) throws Exception {
		// TODO add your handling code here:
		SampleStartColumn = Integer.parseInt(String.valueOf(jSpinnerSampleStart
				.getValue()));
		//***************���¼��м�ʱ�޸���ѡ��******************//

		jComboBoxchrom.removeAllItems();
		jComboBoxstart.removeAllItems();
		jComboBoxend.removeAllItems();
		for (int i = 1; i < SampleStartColumn; i++) {
			jComboBoxchrom.addItem("Column " + i);
			jComboBoxstart.addItem("Column " + i);
			jComboBoxend.addItem("Column " + i);
		}
		ChromsomeColumn = SampleStartColumn - 4;
		jComboBoxchrom.setSelectedIndex(ChromsomeColumn);
		RegionStartColumn = SampleStartColumn - 3;
		jComboBoxstart.setSelectedIndex(RegionStartColumn);
		RegionEndColumn = SampleStartColumn - 2;
		jComboBoxend.setSelectedIndex(RegionEndColumn);
		if (SampleStartColumn <= 3) { //����Ϣ��С��3��ʱ������չ��Ϣ����Ϊ�����ã���������ʾ
			jComboBoxspecies.setEnabled(false);
			jComboBoxchrom.setEnabled(false);
			jComboBoxstart.setEnabled(false);
			jComboBoxend.setEnabled(false);
			CheckBoxneedadvance.setSelected(false);
			JOptionPane
					.showMessageDialog(
							this,
							"No enough information columns."
									+ "\n"
									+ "Please try add information of region locations!!",
							"Warning", JOptionPane.WARNING_MESSAGE);
		}
		//***************���ϼ��м�ʱ�޸���ѡ��******************//

		//***************����һ��Ϊ�ж�����******************//
		DataInputProcess(InputfilePath);
	}

	private void jRadioButton0to100ActionPerformed(
			java.awt.event.ActionEvent evt) throws Exception {
		// TODO add your handling code here:
		if (jRadioButton0to100.isSelected()) { //ѡ��100Ϊ�������ֵ
			MaxMethylationLevel = 100;
			jRadioButton0to1.setSelected(false);
		} else { //ѡ��1Ϊ�������ֵ
			MaxMethylationLevel = 1;
			jRadioButton0to1.setSelected(true);
		}
		DataInputProcess(InputfilePath);
	}

	private void jRadioButton0to1ActionPerformed(java.awt.event.ActionEvent evt)
			throws Exception {
		// TODO add your handling code here:
		if (jRadioButton0to1.isSelected()) { //ѡ��1Ϊ�������ֵ
			MaxMethylationLevel = 1;
			jRadioButton0to100.setSelected(false);
		} else { //ѡ��100Ϊ�������ֵ
			MaxMethylationLevel = 100;
			jRadioButton0to100.setSelected(true);
		}
		DataInputProcess(InputfilePath);
	}

	private void CheckBoxColumnNamesActionPerformed(
			java.awt.event.ActionEvent evt) throws Exception {
		// TODO add your handling code here:
		if (CheckBoxColumnNames.isSelected())
			FirstLineIsColumnName = true;
		else
			FirstLineIsColumnName = false;
		DataInputProcess(InputfilePath); //��������Ԥ������������ȡǰN�����ݣ��������ݽṹ
	}

	private void DataFileBrowserMouseClicked(java.awt.event.MouseEvent evt)
			throws Exception {
		// TODO add your handling code here:
		JFileChooser chooser = new JFileChooser();
		FileFilter filter1 = new FileNameExtensionFilter("txt files", "txt");
		chooser.addChoosableFileFilter(filter1);
		int result = chooser.showOpenDialog(this); // ��"���ļ�"�Ի���,����1��0��1��ʾѡ���ļ�
		if (result == JFileChooser.APPROVE_OPTION) { //���ѡ�����ļ����Ϳ�ʼ��ȡ
			File Inputfile = chooser.getSelectedFile(); //��ȡ�ļ�ʵ��
			InputfilePath = Inputfile.getAbsolutePath(); //��ȡ�ļ�����·����ַ
			DataInputProcess(InputfilePath); //��������Ԥ������������ȡǰN�����ݣ��������ݽṹ
		}
	}

	private void DataFileLocationKeyPressed(java.awt.event.KeyEvent evt)
			throws Exception {
		// TODO add your handling code here:
		if (evt.getKeyCode() == KeyEvent.VK_ENTER) { //�����û����룬��Enter����������    
			InputfilePath = DataFileLocation.getText(); //��ȡ�ļ�����·��
			//			System.out.println(InputfilePath);    //�������
			DataInputProcess(InputfilePath); //���ļ�����·������Ԥ��������
		}
	}

	private void okButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okButtonActionPerformed
		doClose(RET_OK);
	}//GEN-LAST:event_okButtonActionPerformed

	private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
		doClose(RET_CANCEL);
	}//GEN-LAST:event_cancelButtonActionPerformed

	/** Closes the dialog */
	private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
		doClose(RET_CANCEL);
	}//GEN-LAST:event_closeDialog

	private void doClose(int retStatus) {
		returnStatus = retStatus;
		setVisible(false);
		dispose();
	}

	private void DataInputProcess(String InputfilePath) throws Exception {
		//		System.out.println(InputfilePath);    //�������
		int RowNum = 20; // Ԥ����Ԥ�����ݵ�����
		String line; // ��������ÿ�ж�ȡ������
		String ColumnNameRow = null;
		int RowPreview = 0; // ������¼�����е�����
		BufferedReader buffer = null;
		if (InputfilePath.equals("/data/Example_HEP_Dataset.txt")
				|| InputfilePath.equals("/data/Example_Rakyan_Dataset.txt")) { //���û�ѡ���������ݣ���jar���е�����������
			InputStream is = this.getClass().getResourceAsStream(InputfilePath);
			buffer = new BufferedReader(new InputStreamReader(is)); //������ȡ�෽�����ļ���
		} else { //���û�ѡ��Ĳ����������ݣ���ϵͳ�ļ��е����û��ṩ������
			buffer = new BufferedReader(new FileReader(InputfilePath));//������ȡ�෽�����ļ���
		}
		String[] DataInputProcessArray = new String[RowNum]; //���������ַ�������
		if (FirstLineIsColumnName) {
			ColumnNameRow = buffer.readLine();
		}
		line = buffer.readLine();
		for (int i = 0; (line != null) && (i < RowNum); i++) { //�ж��Ƿ�������ļ���һ��
			DataInputProcessArray[i] = line; //����ǰ�ж�������
			//			System.out.println(DataInputProcessArray[i]); //�������
			RowPreview++; //��������1
			line = buffer.readLine(); //��ȡ��һ��
		}
		if (RowPreview > 0) { //���ļ���������0���������ύ��ʶ��ָ����ĳ���
			String[] InputfilePathArray = new String[15]; //Ԥ����һ�����飬�����洢�ļ���ַ
			InputFileName = InputfilePath; //����һ���ַ������ݴ����·��
			InputFileName = InputFileName.replace("\\", "/"); //������·���е�ת���ַ�ת����"/"
			InputfilePathArray = InputFileName.split("/"); //��"/"Ϊ�ָ����ָ����·��
			InputFileName = InputfilePathArray[InputfilePathArray.length - 1]; //�����������һ����Ϊ�ļ���
			//			System.out.println(InputFileName);    //�������
			DataInputProcessFengefu(DataInputProcessArray, RowPreview,
					ColumnNameRow);
			okButton.setEnabled(true);
		} else { //���ļ�����Ϊ0����ʾ�û�������������
			JOptionPane.showMessageDialog(this, "Your input data is empty, "
					+ "\n" + "please input your data again!!", "Warning",
					JOptionPane.WARNING_MESSAGE);
		}
	}

	/**
	 * ����ǰRowNum�����ݣ�ͨ���ָ������и���ȡÿ���е�����
	 */
	private void DataInputProcessFengefu(String[] DataInputProcessArray,
			int RowPreview, String ColumnNameRow) {
		String[] FirstLine = DataInputProcessArray[0].split(Separator);
		ColumnNum = FirstLine.length;
		//		System.out.println("hh" + DataInputProcessArray.length + "hh"+ FirstLine.length + "hh");  //�������
		String[] ProcessArray = new String[ColumnNum];
		String[][] DataInputProcessDoubleArray = new String[RowPreview][ColumnNum];
		for (int i = 0; i < RowPreview; i++) {
			ProcessArray = DataInputProcessArray[i].split(Separator, ColumnNum);
			for (int j = 0; j < ProcessArray.length; j++) {
				DataInputProcessDoubleArray[i][j] = ProcessArray[j];
				//				System.out.println(DataInputProcessDoubleArray[i][j] + ","); //�������
			}
			//			System.out.println("\n"); //�������
		}
		DataInputProcessPreview(DataInputProcessDoubleArray, ColumnNameRow); //ͨ����������������Ԥ������
		if (!FormatStartColumnTest(DataInputProcessDoubleArray, RowPreview)) { //true��ʾ��ȷ��false��ʾ��ʼ�д�����ʾ�û��޸�
			String message = "Data format is incorrect!\n1.The methylation data maybe start from the "
					+ SampleStartColumn
					+ "th column or subsequent columns.\n"
					+ "2.Please try to tune the start column for methylation data in data definition panel.\n3.Please refer to the data example and then adjust your data format.\n4.Please make sure the max value of methylation is correct!";
			JOptionPane.showMessageDialog(null, message,
					"Warning Message and Suggestions",
					JOptionPane.WARNING_MESSAGE);

		} else if (FormatFirstRowTest(DataInputProcessDoubleArray, RowPreview)) {//��Ϊ�棬��ʾ�û������ύ��ť����Ϊ������
			okButton.setEnabled(false);
			JOptionPane
					.showMessageDialog(
							null,
							"Data format is incorrect!\n1.Please try to transfer the first line as column names in the advanced panel.\n2.OR please try to tune the start column for methylation data in data definition panel.\n3.Please refer to the data example and then adjust your data format.\n4.Please make sure the max value of methylation is correct!",
							"Warning Message and Suggestions",
							JOptionPane.WARNING_MESSAGE);

		} else if (!BigFormatValueRange(DataInputProcessDoubleArray, RowPreview)) {//�ж������Ƿ����û�����ķ�Χ�ڣ���û�У���ʾ�û�����
			okButton.setEnabled(false);
			JOptionPane
					.showMessageDialog(
							null,
							"Methylation value is beyond the prescribed range!\n1.Please try to change the max value of methylation in the advanced panel.\n2.Please refer to the data example and then adjust your data format.",
							"Warning Message and Suggestions",
							JOptionPane.WARNING_MESSAGE);
		} else {
			okButton.setEnabled(true);
		}
	}

	/**
	 * ͨ����������������Ԥ������
	 * @return 
	 */
	private void DataInputProcessPreview(
			String[][] DataInputProcessDoubleArray, String ColumnNameRow) {
		Object[][] rowData = DataInputProcessDoubleArray;
		//		System.out.println("wowo"+rowData[0][0]); //�������
		Object[] columnNames = new Object[DataInputProcessDoubleArray[0].length];
		if (CheckBoxColumnNames.isSelected()) {
			columnNames = ColumnNameRow.split(Separator); //���û�ѡ���һ��Ϊ����������ȡ���һ��
		} else {
			for (int i = 0; i < (SampleStartColumn - 1); i++) {
				columnNames[i] = "RegInfo_" + (i + 1);
			}
			for (int i = (SampleStartColumn - 1); i < ColumnNum; i++) {
				columnNames[i] = "Sample_" + (i - SampleStartColumn + 2);
			}
		}
		DataInputPreviewPanle.setModel(new javax.swing.table.DefaultTableModel(
				rowData, columnNames)); //���ɱ���		
		jTabbedPane1.addTab(InputFileName, jScrollPane1);
		jScrollPane1.setViewportView(DataInputPreviewPanle);
		DataInputPreviewPanle.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); //AUTO_RESIZE_OFF ���Զ������еĿ��ȣ�ʹ�ù�������
		DataInputPreviewPanle.getTableHeader().setReorderingAllowed(false); //�����еı�ͷ�����϶�
	}

	/**
	 * ������һ�����ݣ�����û��������ݵĵ�һ���Ƿ�Ϊ����
	 * @return true ��ʾ��һ����������false��ʾ��һ�в�������
	 */
	private boolean FormatFirstRowTest(String[][] DataInputProcessDoubleArray,
			int RowPreview) {
		//���ȷ�����һ���Ƿ�Ϊ����
		for (int i = (SampleStartColumn - 1); i < ColumnNum; i++) {
			try {
				Double.parseDouble(DataInputProcessDoubleArray[0][i]);
			} catch (Exception e) {
				// TODO: handle exception
				//				System.out.println("��һ��Ϊ����");
				return true;
			}
		}
		//		System.out.println("��һ�в�������");
		return false;
	}

	/**
	 * ����ǰRowNum�����ݣ�����û�����׻������ݿ�ʼ�����Ƿ���ȷ
	 * @return true��ʾ��ȷ��false��ʾ��ʼ�д�����ʾ�û��޸�
	 */
	private boolean FormatStartColumnTest(
			String[][] DataInputProcessDoubleArray, int RowPreview) {
		//�ж��û����õĿ�ʼ���Ƿ���ȷ
		//		double doubletest = 0;
		int StartColumn = SampleStartColumn;
		for (int i = SampleStartColumn; i < ColumnNum - 1; i++) {
			boolean flag = true;
			for (int j = 1; j < RowPreview; j++) {
				try {
					//					doubletest =
					Double.parseDouble(DataInputProcessDoubleArray[j][i]);
					//					if (doubletest < 0 || doubletest > MaxMethylationLevel) { //�жϼ׻���ֵ�Ƿ����û�����ķ�Χ��
					//						flag = false;
					//						break;
					//					}
				} catch (Exception e) {
					// TODO: handle exception
					flag = false;
					break;
				}
			}
			if (!flag)
				StartColumn++;
			//			System.out.println(StartColumn);
		}
		if (StartColumn == SampleStartColumn) {
			//			System.out.println("��ʼ����ȷ");
			return true;
		} else {
			//			System.out.println("��ʼ�д���");
			SampleStartColumn = StartColumn; //�����û�����ĳһ��Ϊ��ʼ��
			jSpinnerSampleStart.setValue(SampleStartColumn);
			return false;
		}
	}

	/**
	 * ����ǰRowNum�����ݣ�����û�����׻��������Ƿ����û�����ķ�Χ��
	 * @return true��ʾ�ڷ�Χ�ڣ�false��ʾ���ڷ�Χ�ڣ���ʾ�û��޸�
	 */
	private boolean BigFormatValueRange(String[][] DataInputProcessDoubleArray,
			int RowPreview) {
		//�ж��û����õĿ�ʼ���Ƿ���ȷ
		double doubletest = 0;
		int StartRow = 0;
		if (FirstLineIsColumnName)
			StartRow = 1;
		for (int i = SampleStartColumn - 1; i < ColumnNum; i++) {
			for (int j = StartRow; j < RowPreview; j++) {
				doubletest = Double
						.parseDouble(DataInputProcessDoubleArray[j][i]);
				if (doubletest < 0 || doubletest > MaxMethylationLevel) { //�жϼ׻���ֵ�Ƿ����û�����ķ�Χ��
					System.out.println(doubletest);
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				final DataInputPreviewNew UserInputData = new DataInputPreviewNew(
						new javax.swing.JFrame(), true);
				UserInputData.okButton
						.addActionListener(new java.awt.event.ActionListener() {
							public void actionPerformed(
									java.awt.event.ActionEvent evt) {
								//						DataGetAndAnalysis(UserInputData);
							}
						});
				UserInputData
						.addWindowListener(new java.awt.event.WindowAdapter() {
							public void windowClosing(
									java.awt.event.WindowEvent e) {
								System.exit(0);
							}
						});
				UserInputData.setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JCheckBox CheckBoxColumnNames;
	private javax.swing.JCheckBox CheckBoxneedadvance;
	private javax.swing.JButton DataFileBrowser;
	private javax.swing.JTextField DataFileLocation;
	private javax.swing.JTable DataInputPreviewPanle;
	private javax.swing.JButton ExempleData1;
	private javax.swing.JButton ExempleData2;
	private javax.swing.JTextArea OperationGuide;
	private javax.swing.JButton cancelButton;
	private javax.swing.JComboBox jComboBoxchrom;
	private javax.swing.JComboBox jComboBoxend;
	private javax.swing.JComboBox jComboBoxspecies;
	private javax.swing.JComboBox jComboBoxstart;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabelchrom;
	private javax.swing.JLabel jLabelend;
	private javax.swing.JLabel jLabelspecies;
	private javax.swing.JLabel jLabelstart;
	private javax.swing.JLabel jLabelstart1;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JPanel jPanel3;
	private javax.swing.JPanel jPanel4;
	private javax.swing.JPanel jPanel5;
	private javax.swing.JPanel jPanel6;
	private javax.swing.JPanel jPanel7;
	private javax.swing.JRadioButton jRadioButton0to1;
	private javax.swing.JRadioButton jRadioButton0to100;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JScrollPane jScrollPane2;
	private javax.swing.JSpinner jSpinnerSampleStart;
	private javax.swing.JTabbedPane jTabbedPane1;
	javax.swing.JButton okButton;
	// End of variables declaration//GEN-END:variables

	private int returnStatus = RET_CANCEL;
}