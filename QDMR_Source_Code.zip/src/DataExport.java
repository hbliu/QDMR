import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

public class DataExport {
	public DataExport(javax.swing.JTable EntropyDataTable,String FileNameAuto) throws IOException{
		double fudu=EntropyDataTable.getRowCount()/100;
		JFileChooser chooser = new JFileChooser();
		FileFilter filter1 = new FileNameExtensionFilter(".txt", "txt");
		FileFilter filter2 = new FileNameExtensionFilter(".xls", "xls");
		chooser.addChoosableFileFilter(filter2);
		chooser.addChoosableFileFilter(filter1);
		chooser.setSelectedFile(new File(FileNameAuto));  //����Ĭ�ϵ��ļ���
		int result=chooser.showSaveDialog(chooser);
		if(result==JFileChooser.APPROVE_OPTION){
		String FileName = chooser.getSelectedFile().getAbsolutePath().trim();  //��ȡ��ַ
		String houzhui=chooser.getFileFilter().getDescription(); //��ȡ��׺
		FileWriter out = new FileWriter(FileName+houzhui);       //�������
		for (int i = 0; i < EntropyDataTable.getColumnCount(); i++) {
			    out.write(EntropyDataTable.getColumnName(i) + "\t");
			   }
			   out.write("\n");
	    for (int i = 0; i < EntropyDataTable.getRowCount(); i++) {
	    	
			for (int j = 0; j < EntropyDataTable.getColumnCount(); j++) {
			     out.write(EntropyDataTable.getValueAt(i, j).toString() + "\t");
			    }
			    out.write("\n");
			    QDMR.ProgressBar((int) (i/fudu));  //��������Ľ���
			   }
			   out.close();
			   QDMR.ProgressBar(100);
			   JOptionPane.showMessageDialog(null, "Data export is successful!");
		  }
	}
}
